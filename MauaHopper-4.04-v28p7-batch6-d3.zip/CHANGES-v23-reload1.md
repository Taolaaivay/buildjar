# MauaHopper 4.04-PATCHED-v23-reload1

Bao gom toan bo cac batch truoc + reload/shutdown safety.

## Reload/shutdown fixes
- saveConfigAsync bay gio duoc tracking bang BukkitTask + snapshot YAML.
- reloadConfiguration() goi flushConfigSave() truoc khi configManager.load(), tranh doc config cu ngay sau command doi config.
- onDisable() goi flushConfigSave() de khong mat config do async task bi cancel khi tat server.
- BigChest async save dung lock wait/notify; saveBlocking cho async writer hien tai hoan tat thay vi sleep poll 500ms.

## Verify
- Brace/paren/bracket balance toan bo Java.
- Grep call-site reload safety.
