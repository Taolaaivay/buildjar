# MauaHopper 4.04-PATCHED-v26-audit1

Batch fix theo full audit moi nhat.

## Da sua
- B1/B2: config save generation chong stale overwrite/revert sau reload.
- B3: foundAny overload don le fast pickup.
- B4: don pacing map khi unregister hopper/dropper.
- B5: crafterPulseCount purge theo timestamp 10 phut.
- B6: insertFrom()/pullInto() Rương To markDirty + version++.
- B8: BigChest load luon saveBlocking, ke ca khi chests rong.
- B9: saveAsync early-return van markDirty.
- B10: shopViewers remove neu openInventory fail.
- B11: ItemStacking merge ca item khong PDC bang amountOf().
- B12: ChestType.autoSellEnabled/collector duoc load tu chests.yml.

## Ghi chu
Chua xu ly het P1-P11/S1-S16 trong dot nay; uu tien data-loss/dupe truoc.
