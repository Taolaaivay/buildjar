# PATCH NOTES v28p7-batch6-engine (2026-09-29)

Chuyen engine transfer sang kieu DonutHopper 3.4 (da phan tich tu jar goc):
flat polling loop, MỌI TICK, khong wheel/khong gate player/khong kill-switch.

## Thay doi
1. config work_queue: true -> false - bat lai polling loop phang (da co san
   trong code tu truoc, chi dung lam fallback).
2. config hopper.transfer_ticks: 2 -> 1 + sua code: cooldown = max(0,
   transfer_ticks-1) - truoc day Math.max(minCascade=2, ...) kep cung
   toi thieu 2-3 tick/batch du config nho.
3. config hopper.max_per_tick: 20 -> 0 - gioi han 20/tick lam 1 hopper
   trong danh sach 1000 cai chi duoc xu ly moi ~2.5 giay (dung bang trieu
   chung "vai giay moi truyen 1 lan").
4. config performance.mspt_throttle_ms: 35.0 -> 0 - tat kill-switch
   (p3d da sua logic nhung mac dinh nen tat han cho nhip deu).
5. Code: bo gate isChunkActive o polling loop (Donut khong gate player
   cho transfer; gate nay chi con cho pickup sweep).
6. Code: wakeHopper khong enqueue vao hotQueue khi work_queue tat (chong
   leak - luc do khong ai drain).

## Rollback
Doi lai config: work_queue: true + xoa plugin/MauaHopper khoi server,
hoac dung lai zip batch5-p3.

## Test
- Chest tren -> hopper -> chest duoi: do chay LIEN TUC moi tick, khong
  con nac.
- Dung /mh toggle + /mh stats de kiem tra.
- Theo doi TPS sau 30 phut farm chay.

## Crafter toc do (so với Donut 3.4)
Donut 3.4 KHONG dung auto-retrigger: no chi feed nguyen lieu (pushItemsTo
Crafter/crafterCanAcceptItem) roi de VANILLA redstone craft lien tuc.
Bản này dang dung chuoi retrigger event-driven bi kep boi:
- throttle recipe lookup 100ms -> 50ms (moi tick).
- crafts_per_pulse: 8 -> 0 = KHÔNG GIOI HAN burst (truoc day 8 craft roi
  dung han cho xung ngoai). An toan van giu: het nguyen lieu / dau ra bi
  chan (canEjectCrafterResult false) thi dung, xung hoac do vao crafter
  se khoi dong lai.

## Tune stacking (batch6-tune)
ITEMS: max-stack 500->1000, radius 1.0->2.0, interval 40->20 tick.
MOBS:  max-stack 7->30, radius 4.0->6.0, interval 150->60 tick.
GIU NGUYEN attract-radius: 0.0 CA HAI - tac gia tung bat mac dinh roi
phai tat (v67.26) vi magnet keo item/mob xa PHA MAY FARM (do bi hut khoi
diem thu, mob bi kéo khoi bang giet). Muon bat magnet: chi nen trong vung
khong co farm, dat nho (item 1-2, mob 2-4).
An toan da co san trong code: attract clamp 32, Y-check chong gop xuyen
tang, xoay cell cap chong starvation, hologram cap 200.

## Review ngoai (p7) - xac minh 7 muc, fix 4
#1 CME khi iterate chunkHoppers trong polling mode: KHONG PHAI LOI - inner
    set da la ConcurrentHashMap.newKeySet() (iterator weakly-consistent).
#2 endTick ngoai try: GAN NHU KHONG PHAI LOI - endTick nam SAU catch nen
    exception body van toi duoc; chi skip khi loi o doan truoc try hoac
    trong catch. Khong sua (bat them Error = nuot OOM, thiet ke co chu y).
#3 STACK_KEY static init bang getInstance(): THẬT -> lazy holder.
#4 packChunkKey khong check world null: THẬT -> sentinel Long.MIN_VALUE.
#5 signature cache phu thuoc thu tu player: THẬT nhung chi gay rebuild
    thua ~1 lan/giay, khong sai ket qua -> chua sua (ghi nhan).
#6 boat/minecart break khi tryLockContainer that bai: THẬT -> break chi
    trong nhanh thanh cong, that bai thu entity tiep trong AABB.
#7 vehicleQueryCache tra mang entity tho: ghi nhan, caller da check isValid.

## Review ngoai 2 (p8) - xac minh 6 muc
#1 HopperTicker:2149 addItem oversized: KHONG PHAI LOI - Paper/Bukkit addItem
    tu split theo maxStackSize, tra leftover; code da tinh added = original -
    leftoverSum va cap nhat PDC du dung. #2 onPlayerPickup: tuong tu.
#3 onItemSpawn cap=128 voi max-stack config 1000: THAT (da du bao tu audit
    dau) -> cap gio ke ca config maxStack. MAT ĐO khi entity respawn da fix.
#4 verifyTransfer bi bo qua ket qua: THAT -> fail = return 0 (rollback da
    chay ben trong).
#5 verify chi cong theo Material: DANH DO CO CHU DINH o P2 (anti-dupe bat
    dupe/loss + hoan doi khac loai; chi miss meta-swap khong doi so luong =
    khong tao mat do). verify_transfers mac dinh false. Chua sua.
#6 death respawn cap 25/tick: THAT -> nang 60 (tuong xung max-stack 30);
    chan chong death-spiral van giu.

## Review ngoai 3 (p9) - xac minh 14 muc
TRUNG LAP da xu ly o p7/p8: #9(=loi#2 cu, endTick sau catch - khong sua),
#10(=p7#4 da fix guard null world), #11(=p7#6 da fix break).
FIX MOI:
#7  cancel vanilla pickup minecart khong gate config -> them dieu kien
    minecartHopperEnabled (config tat thi vanilla van hoat dong).
#8  xoay minecart overflow int -> floorMod + long; minecartScanInterval*180
    nhan long tranh int overflow.
#12 onChunkLoad dang ky hopper cho world bi cam -> them gate isWorldAllowed.
#13 crafts_per_pulse Math.max(1,..) nuot gia tri 0 = unlimited -> Math.max(0).
#14 dispenser max_per_tick 0=unlimited bi clamp -> cho phep 0 o ca Config
    Manager lan cho dung (0 -> Integer.MAX_VALUE).
#15 config.yml BI NUT KEY boi comment cua batch6 (LOI CUA MINH - xin loi):
    4 dong comment khong xuong dong lam pull_ticks / idle_full_hopper_ticks
    bi nuot + 2 comment dinh dong. DA PHUC HOI day du.
#16 cursor expand chi dien slot trong khong gop stack cung loai -> gop truoc.
#17 attractWorld raw isSimilar vs merge stripDisplayName -> dung isMergeable (O ItemStackingManager:789, khong phai HopperTicker).
#19 ghi config.yml truc tiep khong atomic -> ghi temp + ATOMIC MOVE (fallback
    move thuong).
#18 magnet teleport (xuyen tuong/suffocate): da canh bao tu batch6-tune,
    van de tai lieu - KHONG sua code (magnet mac dinh TAT).

## Review ngoai 4 (p10) - xac minh 12 muc
LAP/DA XU LY: #21 (=P1#4 co chu dich, 50ms bounded), #22 (pham vi ±33 trieu
block da ghi chu tu audit dau - world border 30M chua toi), #32 (=p7#3 da
lazy holder), #28 #29 #30 #31 (ghi nhan: cache theo UID la thiet ke; wheel
scan chi khi bat work_queue; marker ✖ la edge dat ten tay; hologram orphan
da duoc cleanup task don theo tick).
FIX: #23 signature XOR giao hoan (2 site - het rebuild thua khi doi thu tu
player), #24 onHopperBreak xoa them crafterPulseAt + crafterRetriggerNextAt
(purge 10 phut van giu lam luoi), #25 reload bat them LinkageError, #26
/mh speed clamp 0-200, /mh amount clamp 1-640, #27 /mh toggle <player>
khong on/off gio toggle dung nguoi choi thay vi nham global.

## Tune mob max-stack 30 -> 500
onMobDeath da kiem chung: loot/XP vanilla x1, respawn 1 entity count-1,
cap 60 stack-death/tick, whitelist damage cause, gearCache chong mat do,
admin killall quiet window. Stack 500 khong tao dupe/mat do.

## Chinh lai theo yeu cau: items 500, mobs 5

## DEBUG build - chuan doan pickup yeu
Them config hopper.pickup.debug_log (mac dinh false). Khi bat true, moi
lan co item spawn se log: spawn-ok (qua duoc gate rate-limit), hopper-ben-
duoi (tim thay hopper khong), hopper day / blacklist. Giu nguyen trong
production, chi bat luc chuan doan.

## batch7 - DIRECT SUCTION (hut xin hon Donut)
Duong hut moi chay MỌI TICK, doc lap hoan toan voi: spawn event,
chunkHasItems hint, cooldown, stagger, rate-limit. Quet truc tiep item
trong ban kinh pickup.radius_ (mat hopper + 0.5 block mo phia) va nhet
qua pickupItemEntityIntoHopper (PDC stack + addItem + leftover day du).
Co config direct_suction (mac dinh true) + debug flag cu. Gia tri mac
dinh radius_horizontal 1.5 / vertical 0.75 (vanilla 0.75/0.5).

## batch7b - suck_ground (magnet quanh chan hopper)
Direct suction them zone 2: quet item tren MAT ĐAT xung quanh chan hopper
(cung ban kinh pickup.radius_horizontal, cao 0.75). Config
hopper.pickup.suck_ground (zip mac dinh true; code default false neu thieu
key = an toan). TAT no di neu farm co dong nuoc mang do di ngang (so hut
nham).

## batch7c - fix suck_ground khong toi do tren san
Hopper nam tren chest -> mat dat xung quanh thap hon 1 block so voi day
hopper, vung 2 (rv 0.75) khong trum. Sua: tam y+0.5, rv 1.5 - phu tu san
lom toi cao hon mat hopper.

## batch7d - suck_ground mac dinh FALSE
Nguoi dung lam farm tren cao: do roi xuong mat dat duoi thap khong duoc
hut. Zone 2 chi bat khi nao thuc su can (khu luu tru dat o mat dat).

## batch7e - pickup zone VE DUNG CHUAN VANILLA
Yeu cau: chi hut item TREN MAT 1x1 cua hopper (nhu hopper vanilla), khong
suck_ground. Direct suction giu toc do moi tick nhung zone 1 sihet:
radius_horizontal 0.6 / vertical 0.8, floor code ha xuong 0 (khong ep
rong). suck_ground mac dinh false.
