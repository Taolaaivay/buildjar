# MauaHopper 4.04-PATCHED-v28p1-hotfix

Hotfix tren v28-audit-final (fix cac loi bat nguon tu chinh cac patch v26-v28).

## Da sua
- F1 (CHAN BUILD): DuplicationProtector - `stackAmountKey = stackAmountKey` tu
  tham chieu -> compile error. Khoi tao dung bang `new NamespacedKey(plugin,
  "stack_amount")`, khai bao SAU field plugin (tranh forward reference).
- F2 (RUNTIME): BigChestManager - `stackAmountKey()` goi de quy chinh no ->
  StackOverflowError ngay lan dau (GUI click, hopper nap/rut Ruong To,
  collector, sell preview). Khoi tao cache dung bang `new NamespacedKey`.
- B4 (du): crafterRetriggerNextAt van khong ai don sau khi fix v28. Bo sung
  purge dinh ky trong runTick: don entry khi block doi kieu / world mat /
  throttle het han (crafter con hoat dong se tu re-add). Mo dieu kien purge
  chay ca khi chi con retrigger map.
- inactiveChunkBackoff: don khi chunk unload (truoc day map moi cua fix P3
  khong duoc don -> leak nho).

## Ghi chu
Khong doi behavior. Chi sua 3 file: DuplicationProtector, BigChestManager,
HopperTicker.
