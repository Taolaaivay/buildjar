# PATCH NOTES v28p7-batch5-p2 (2026-09-29) - build tren p1

Dia chi 5 lỗi MỨC TRUNG BÌNH/NHỎ từ audit tổng hợp.

## Lỗi #7 (TPS) - DuplicationProtector: verifyTransfer O(slots x reps) meta-compare
- TRIỆU CHỨNG: moi transfer co verify_transfers=true: clone THEM 2 snapshot
  (srcAfter/dstAfter) + nhom item bang representative + ItemStack.isSimilar
  cho moi slot ca 4 phia. Double chest = 54+54 slot clone x2 + isSimilar.
- FIX: verify theo TONG SO LUONG theo Material (EnumMap O(1), chi cong so
  nguyen). Dupe/loss/hoan-doi vat pham = tong theo loai BAT BUOC doi ->
  phat hien day du, rollback nguyen ven. Khong con clone/isSimilar nao.
  accumulateDelta xoa, thay accumulateTotals + accumulateTotalsLive
  (doc truc tiep inventory, khong snapshot).

## Lỗi #5 (TPS) - HopperTicker: minecart safety rescan 200 chunk/tick
- TRIỆU CHỨNG: getEntities() 200 chunk/tick trong giai doan rescan
  (~4.000 chunk/giay quet entity array).
- FIX: giam budget 200 -> 60 chunk/tick. Day la SAFETY NET - event-driven
  cache (EntitiesLoad/Unload/VehicleCreate/Destroy) van giu cart tuoi,
  scan cham khong anh huong chuc nang.

## Lỗi #8 - HopperTicker: foundAny dat sai vi tri duong pickup don
- TRIỆU CHỨNG: foundAny=true dat TRUOC blacklist check -> chunk chi chua
  item bi blacklist khong bao gio vao cooldown 10 tick, sweep chay vo ich
  moi pickup pass (duong batch da dung tu truoc).
- FIX: doi foundAny xuong SAU blacklist + line-of-sight, khop 2 duong.

## Lỗi #9 (TPS) - HopperTicker: chunkPickupCooldowns con dung String key
- TRIỆU CHỨNG: map dung key "world:x:z" build moi chunk moi pickup pass
  (string concat + alloc).
- FIX: doi toan bo sang packed-long key (packChunkKey / parseChunkKeyPacked)
  nhu cac map khac. 0 string alloc tren duong nong. Map khac van dung
  String key (chunkHoppers, chunkSpecialBlocks) khong dong vao.

## Lỗi #10 - HopperTicker: monotonicMillis trôi khi plugin inactive
- TRIỆU CHỨNG: dong ho chi tang khi plugin active -> gate thoi gian thay
  khoang cach 0 khi vua bat lai -> transfer o at ngay tick dau tien.
- FIX: tang monotonicMillis TRUOC gate isActive.

## Verify
- Brace balance 0 ca 2 file.
- chunkPickupCooldowns: khai bao Long, ca 4 call site dung packed key.
- accumulateDelta: 0 call site con lai (comment javadoc cap nhat).
- chunkKey(loc) con lai chi dung cho map String-key khac (chunkHoppers).
