# PATCH-NOTES-v28p7-batch2 (2026-09-29) - Dot 2: 4 bug vang

## Loi #4 - Gate pull/push container dung wall-clock gia dinh 20 TPS
File: HopperTicker.java
- Them field monotonicMillis (+50L moi tick ticker chay, dung han khi
  ticker nghi). nextContainerPullAt/nextContainerPushAt (:865/:990) doi tu
  System.currentTimeMillis() sang monotonicMillis. Truoc day khi server lag
  (TPS < 20) wall clock van chay toc do thuc trong khi game tick cham lai ->
  khoang cach pull/push theo game tick thuc te dai gap nhieu lan config.
- Cac map nay in-memory only -> doi co so dong ho an toan, khong migration.

## Loi #5 - Lo hong pickup bien chunk
File: HopperTicker.java
- Them hopperChunks: Set<Long> packed-long mirror cua cac chunk dang co
  hopper, sync tai registerHopper/unregisterHopper/onChunkUnload/stop().
- markChunkHasItems rewrite: danh dau chunk khi BAT KY chunk trong 3x3 lan
  can co hopper (truoc day chi chunk dung item spawn). Fix item roi o chunk
  khong-hopper nhung nam trong tam pickup cua hopper chunk ben canh bi bo sot
  vinh vien khi pickup_radius lon. 0 string alloc cho item spawn.

## Loi #6 - removeQueuedHopperChunk O(queue) moi chunk unload
File: HopperTicker.java :2861
- Chi goi khi chunk tung co hopper dang ky (locs != null). Truoc day moi
  chunk unload deu removeIf tren 64 bucket x toan bo queue. Entry stale tu
  drain sau toi da 4096 tick, vo hai.

## Loi #7 - inactiveChunkBackoff tich luy vo han
File: HopperTicker.java :594
- Merge remapping doi tu Integer::sum sang (a,b) -> min(160, a+b): cap gia
  tri LUU trong map (truoc day cap 160 chi ap cho bien local).

## Verify
- Brace balance 0, parens delta -1 (co san tu ban goc).
- Grep: monotonicMillis 4/4, hopperChunks 7/7, removeQueuedHopperChunk 2/2.
- parseChunkKeyPacked va packChunkKey(Location) cung dinh dang packed-long.
