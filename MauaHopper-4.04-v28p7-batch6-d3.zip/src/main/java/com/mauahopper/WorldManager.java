package com.mauahopper;

import org.bukkit.World;

import java.util.HashSet;
import java.util.Set;

public class WorldManager {

    private final MauaHopper plugin;
    private final Set<String> disabledWorlds = new HashSet<>();
    private final Set<String> enabledWorlds  = new HashSet<>();

    public WorldManager(MauaHopper plugin) {
        this.plugin = plugin;
        reload();
    }


    /** FIX TPS 2026-09-28: cache quyet dinh theo UUID cua world cho duong
     *  nong - tranh world.getName() + String.contains cho MỌI hopper moi
     *  luot drain. Cache bi xoa khi reload; world load sau reload tu duoc
     *  tinh lai dung (khong bi khoa sai nhu cache UUID set thuan). */
    private final java.util.Map<java.util.UUID, Boolean> allowedCache =
            new java.util.concurrent.ConcurrentHashMap<>();

    public void reload() {
        disabledWorlds.clear();
        enabledWorlds.clear();
        allowedCache.clear();
        ConfigManager cfg = plugin.getConfigManager();
        // PATCH v28p7-batch6-d4 (loi #14): chuan hoa ve lowercase khi nap -
        // truoc day HashSet.contains() phan biet hoa thuong nen config ghi
        // "world" khong khop world thuc te ten "World". isWorldAllowed()
        // cung phai lowercase truoc khi contains.
        for (String w : cfg.disabledWorlds) disabledWorlds.add(w.toLowerCase());
        for (String w : cfg.enabledWorlds) enabledWorlds.add(w.toLowerCase());
    }

    public boolean isWorldAllowed(World world) {
        if (world == null) return false;
        if (disabledWorlds.isEmpty() && enabledWorlds.isEmpty()) return true;
        return allowedCache.computeIfAbsent(world.getUID(), u -> {
            String name = world.getName().toLowerCase();
            if (!enabledWorlds.isEmpty()) return enabledWorlds.contains(name);
            return !disabledWorlds.contains(name);
        });
    }

    /** Human-readable description for /dh status. */
    public String describeMode() {
        if (!enabledWorlds.isEmpty()) {
            return "Danh sách trắng (" + enabledWorlds.size() + " thế giới)";
        }
        if (!disabledWorlds.isEmpty()) {
            return "Danh sách đen (" + disabledWorlds.size() + " bị vô hiệu hóa)";
        }
        return "All worlds";
    }
}
