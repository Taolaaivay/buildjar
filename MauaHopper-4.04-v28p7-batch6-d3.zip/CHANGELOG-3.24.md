# MauaHopper 3.24 (v67.16) - CHANGELOG & HUONG DAN MIGRATE

Base: MauaHopper 3.4 (v60). Nang cap boi phien audit 23 vong.
Yeu cau: Paper 1.21.x (build voi paper-api 1.21.11), JDK 21.

## BUILD
mvn clean package  ->  target/MauaHopper-3.24.jar

## MIGRATE TU 3.4
1. Sao luu plugins/MauaHopper/ truoc khi thay jar.
2. Thay jar, restart (khong dung /reload cho lan dau).
3. Xem console 1 lan: phai thay [AC-debug] init reflection OK + DispenserService OK
   (neu server co AdvancedChests). Neu thay "THAT BAI"/"KHONG lay duoc" -> gui log.
4. config.yml cu KHONG can sua - moi default da duoc nang cap trong code.
   Muon dung gia tri moi nhat thi xoa config cu de plugin tao lai (se mat
   chinh sua tay cua ban), hoac doi tay theo muc CONFIG MOI duoi day.
5. /mh reload sau khi chinh config.

## 19 VAN DE DA FIX (xem chi tiet trong tung vong)

Nghiem trong (dupe/mất đồ/compile):
- v67.3  DUPE furnace: transferToFurnace khong setItem lai sau setAmount
         (Inventory#getItem tra CLONE) -> dupe toi 15 item moi nhip khi
         fuel slot con cho. Kich hoat: furnace co fuel san + hopper bơm.
- v67.2  Thieu field requirePlayerRadius -> loi compile o v67.1.
- v67.4  Crafter counter nhay 2 don vi: crafts_per_pulse=8 chi ra 5 craft.
- v67.5  /mh toggle chet: command chay nhung ticker khong doc
         PlayerToggleManager.

Hieu nang (TPS):
- v66.5  scanMinecarts quet full-world moi interval -> dang ky ngay khi
         spawn (VehicleCreateEvent), scan dinh ky 100 tick lam safety net.
- v67.7  chunkHasItems chi set TRUE khong bao gio FALSE -> chunk tung co
         item bi AABB query moi tick vinh vien. Them cooldown 10 tick
         sau lanquet sach; item moi spawn huy cooldown.
- v67.13 Stacking scan full-world (items moi 20 tick, mobs moi 100 tick)
         -> dirty-world: chi quet world co spawn moi + safety scan 10-15s.
- v67.14 max_hoppers_per_tick=0 tra ve total hopper (5000 hopper = 5000
         xu ly/tick) -> cap 500. stop() chi clear 5/14 collection -> clear du.

Tinh nang & do dong nhat:
- v61-65 AdvancedChests 1 item/8 tick (hopper + minecart, 2 chieu) ->
         fast path qua DispenserService.addItemToChest /
         dispenseLastItemFromChest (API noi bo cua AC, tu phan trang,
         giu nut GUI). Co [AC-debug] log chan doan.
- v63     DuplicationProtector.invKey dung identityHashCode (Paper tao
         wrapper moi moi lan getInventory -> lock khong bao gio khop)
         -> doi sang key theo vi tri block.
- v67.6   World bi cam trong allowed_worlds: event handler van cancel
         vanilla -> hopper chet han. Them gate isInvWorldAllowed.
- v67.8   Global toggle (/mh toggle) tat ticker nhung handler van cancel
         -> them gate plugin.isActive() cho 6 handler + 5 guard ISM.
- v67.11  hopper.enabled trong config khong ai doc -> noi vao 5 cho
         (tat = vanilla sach).
- v67.12  Default lệch config mau: crafter items_per_slot 1->16,
         feed_ticks 2->0, pull_amount 1->8, max_feeds_per_tick 3->9,
         transfer_ticks 2->1. 8 key dead (async_processing...) danh dau
         CHUA DUNG trong config.yml.
- v67.10  Composter chance: config viet phan tram (30) nhung code dung
         nhu xac suat 0..1 -> clamp 1.0 = day chac chan sau 7 item.
         Gia tri >1 gio duoc hieu la phan tram.
- v67.15  config.yml bi hong indent (minecart_scan_interval thut 4 space)
         -> SnakeYAML exception, config load fail. Da sua + parse kiem chung.
- v67.16  paper-api 1.21.4 -> 1.21.11; softdepend AdvancedChests; mo ta
         pom chinh xac (bo Folia).

## TINH NANG MOI
- Dispenser burst: shots_per_pulse=8 meal moi pulse redstone (vanilla can
  redstone, dung event burst). auto_burst ton tai nhung TAT mac dinh.
- Crafter: crafts_per_pulse=8, auto retrigger an toan (check recipe +
  cho dau ra).
- Minecart: transfer_amount=8, speed x4, max 50 cart/tick.
- Farm sleep: performance.require_player_radius=128 block - farm tu ngu
  khi khong co nguoi gan, khong dung redstone vanilla, resume sach.
- /mh toggle ca nhan: nguoi tat fast se thay nhip vanilla khi dung gan
  farm (hopper.respect_player_toggle=true).
- Chunk gate: vung khong nguoi choi khong bi xu ly (tiet kiem CPU).

## BO TEST SAU DEPLOY
1. Hopper -> AdvancedChest (nhieu trang, trang 1 day): chuyen nhanh xuyen
   trang, nut GUI khong bi de.
2. AdvancedChest tren -> hopper: hut nhanh, khong hut nut phan trang.
3. Minecart tren AC / duoi AC: 2 chieu nhanh.
4. Dispenser + bone meal + 1 pulse: dung 8 meal.
5. Crafter + pulse: dung 8 san pham.
6. Furnace co fuel san + hopper bơm: tong item khong doi (khong dupe).
7. /mh toggle (ca nhan) roi dung gan farm: nhip vanilla; nguoi khac vao
   gan: nhanh lai.
8. Di xa 150 block: farm ngu; quay lai: chay tiep, khong mat item.
9. /mh toggle global off: toan bo hopper vanilla; on: nhanh lai.
10. /spark profiler 5 phut gio cao diem: khong con method MauaHopper
    nao trong top.

## BO SUNG SAU PHAT HANH 3.24

- v67.17 (3.25): respect_player_toggle doc sai section (hopper. vs performance.)
  -> key yml vo hieu. Da fix + fallback ca 2 vi tri.
- v67.18 (3.26): DispenserService chi lay duoc qua
  AdvancedChestsAPI.getChestDispenser().getDispenserService() (2 duong truoc
  do deu khong ton tai tren ban 45.9). Day la fix quyet dinh cho fast path AC.
- v67.19 (3.27): "nem 1 stack chi vao duoc 2 item" - 2 nguyen nhan:
  (1) addItemToChest cua AC gioi han noi bo ~2 item/lan goi (theo hopper-amount
  trong chests.yml), code cu break sau lan dau tien -> chi chuyen 2. Fix: goi
  LAP LAI API toi khi het cho tiep nhan. (2) acHopperBatchSize lay
  getHopperAmount cua AC lam tran -> bo tran nay, dung max_items_per_tick.

- v67.21 (3.29): FAIRNESS - khi so luong vuot max_*_per_tick, vong lap cu
  break o gioi han -> thuc the CUOI danh sach khong bao gio duoc xu ly
  (starvation). Nghiem trong o quy mo nguoi choi xay 2000 lo + dan minecart
  chay vong. Fix: xoay vong (rotating offset) cho hopper/minecart/dispenser.
  Mo phong: 500 cart / 50 moi tick -> moi con duoc xu ly deu, 0 bo doi.
- Ghi chu: 2000 FURNACE khong phai chi phi cua plugin - lo do Paper tick
  (vanilla). Plugin chi cham lo khi hopper tuong tac. Chi phi tick cua
  plugin la O(xu_ly_moi_tick) bi khoa boi max_hoppers_per_tick, khong phai
  O(tong_block).
