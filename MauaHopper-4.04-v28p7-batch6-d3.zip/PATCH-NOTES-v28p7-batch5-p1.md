# PATCH NOTES v28p7-batch5-p1 (2026-09-29)

Dia chi 4 lỗi MỨC CAO từ audit tổng hợp toàn source (16 file ~7.500 dòng).

## Lỗi #1 (TPS) - HopperTicker: hint `chunkHasItems` chết, quét AABB thừa mọi pickup pass
- TRIỆU CHỨNG: map chỉ set TRUE (ItemSpawnEvent/PlayerDropItem), KHÔNG BAO GIỜ
  FALSE -> check 3x3 lang gieng luon dung -> moi chunk co hopper bi quet AABB
  moi pickup pass (chi nghi 10 tick nho cooldown sau lan quet SACH - con trong
  thi quet mai). Tren server nhieu farm trong = van de TPS nen.
- FIX: quet sach -> set FALSE cho chunk. TRUE duoc set lai ngay khi item spawn.
  Rui ro item TROI vao chunk (nuoc chay day qua bien chunk, piston day) khong
  fire spawn event -> cham dut bang PURGE dinh ky 5 giay (clear toan bo map,
  chunk duoc quet lai). Chunk trong nghi toi da ~5s thay vi quet lien tuc.
- FILE: HopperTicker.java (khai bao chunkHasItemsPurgeAt, runFastPickupPass)

## Lỗi #2 - MobStackingManager: mob thu 257+ trong cell khong bao gio duoc gop
- TRIỆU CHỨNG: cell >256 mob -> subList(0,256) lay DUNG 256 con dau MOI merge
  tick, khong xoay -> mob ngoai cua so bi starvation vinh vien (item stacking
  da fix tuong tu o cap 1000 tu truoc, mob bi sot).
- FIX: xoay cua so theo offset tang dan moi lan cap (mergeCellCapRotate).
- FILE: MobStackingManager.java (mergeWorld)

## Lỗi #3 - ItemStackingManager + MobStackingManager: merge bo quen truc Y
- TRIỆU CHỨNG: isMergeable/nearEnough chi check XZ -> 2 item/2 mob o 2 TANG
  farm chong len nhau bi gop xuyen san (item tang duoi bien mat, hien thi
  nhay len tang tren).
- FIX: them check Y voi tolerance CLAMP: item 2.0, mob 3.0 (KHONG dung full
  radius vi tang farm cach nhau 4-5 block < radius 8 -> full radius van gop
  xuyen tang). Item roi tu hopper / mob nhay knockback van merge binh thuong.
- FILE: ItemStackingManager.java (isMergeable), MobStackingManager.java (nearEnough)

## Lỗi #4 (TPS) - MauaHopper: flushConfigSave busy-wait 300ms tren main thread
- TRIỆU CHỨNG: onDisable/reload cho async writer toi 300ms. Thuc te snapshot
  MOI NHAT da duoc ghi DONG BO truoc do va generation da bump - writer async
  dang chay toi dau cung thay generation lech ma bo qua, khong ghi de file.
  300ms khong bao ve them gi, chi tang lag spike reload/shutdown.
- FIX: giam busy-wait 300ms -> 50ms. saveConfig() fallback van giu.
- FILE: MauaHopper.java (flushConfigSave)

## Verify
- Brace balance 0 cho ca 4 file. Parens lech (-1 HopperTicker, -3
  ItemStackingManager) la san co tu ban goc (ky tu comment), patch khong lam
  thay doi.
- Call site: packChunkKey (20 dong, da ton tai), mergeCellCapRotate (khai bao
  + 1 dung), chunkHasItemsPurgeAt (khai bao + 2 dung), chunkHasItems (13 dong).
