# MauaHopper 4.04-PATCHED-v24-reload2

Bao gom toan bo cac batch truoc + hardening reload/shutdown edge cases.

## Reload hardening
- Async config save failure bay gio schedule fallback sync duoc tracking trong cung configSaveLock, tranh reload doc config cu truoc fallback.
- flushConfigSave tu xu ly snapshot neu cancel task truoc khi task chay, va clear configSaveRunning dung cach.
- BigChest saveBlocking tra false neu async writer van treo sau deadline; load() huy reload thay vi doc khi writer cu con chay.
- ItemStacking reload clear hologram ngay lap tuc khi config display doi.

## Verify
- Brace/paren/bracket balance toan bo Java.
- Grep call-site reload hardening.
