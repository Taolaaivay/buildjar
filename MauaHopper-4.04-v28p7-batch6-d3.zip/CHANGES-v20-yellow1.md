# MauaHopper 4.04-PATCHED-v20-yellow1

Bao gom red1 + orange1 + yellow batch 1.

## Yellow fixes
- Pickup foundAny chi dat voi item candidate hop le, giam scan lap khi item delay/blacklist.
- Mob spawn ton trong world blacklist.
- Chunk load chi danh dau dirty khi co mob candidate.
- saveBlocking cho shutdown/reload <=500ms thay vi 2000ms.
- Doi/xoa password vo hieu session mo khoa cu.
- Don hologram BigChest legacy va ItemStacking khi plugin tat.
- Cache lore marker ItemStacking de giam translate/pattern lap.

## Ghi chu
- PBKDF2 van chay tren main thread; neu muon hardening sau co the dua hash async.
- Maven compile/runtime test chua chay trong moi truong nay.
