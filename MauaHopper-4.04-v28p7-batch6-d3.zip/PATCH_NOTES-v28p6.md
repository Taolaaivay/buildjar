================================================================================
MauaHopper 4.04 - v28p6 PATCH NOTES
Tu v28p5 FINAL -> v28p6 FINAL
33 loi duoc fix qua 4 dot | 8 file thay doi | ~380 dong diff
================================================================================

TOM TAT THEO MUC DO
--------------------
🔴 Nghiem trong (hanh vi sai / mat du lieu) ........ 7
🟡 Trung binh (leak / race / TPS) .................. 17
🟢 Nho / dead code ................................. 9
Loi rut khoi danh sach sau khi doc lai ky ......... 2 (#6, #21 - khong phai loi)


================================================================================
DOT 1 - HANH VI SAI RO RANG
================================================================================

#11 🔴 Dispenser fast-burst "dong bang" ~10 phut sau moi 10 phut chay
   File: HopperTicker.java
   Nguyen nhan: gate dung `tickCounter` lam clock, nhung tickCounter bi reset
   ve 0 moi 12000 tick -> hieu (tickCounter - lastFastDispenserBurstTick) am
   lon -> gate khoa burst, khong bao gio cap nhat lai -> dispenser dung dinh
   ky, khong co loi nao in ra.
   Fix: them bo dem monotonic RIENG `dispenserGateTick` (khong bao gio reset),
   tang canh tickCounter, gate + luu lastFastDispenserBurstTick theo bo dem
   moi. Farm dispenser gio chay deu, het chu ky 10 phut chay / 10 phut dung.

#12 🔴 Blacklist pickup bi bypass o duong nhat ngay
   File: HopperTicker.java (tryImmediateGroundPickup)
   Nguyen nhan: so sanh `hopperBlock.getType().name()` (luon la "HOPPER") voi
   `blacklistedBlocksForPickup` (chua ten ITEM nhu COBBLESTONE) -> hai tap
   khong giao nhau -> check vo nghia. Duong sweep runFastPickupForChunk check
   dung loai item, duong ngay (onItemSpawn/onPlayerDrop) bo qua -> blacklist
   chi co hieu luc mot nua.
   Fix: doi sang check `item.getItemStack().getType().name()` - dung loai
   item nhu duong sweep. Blacklist gio co hieu luc o ca 2 duong.

#22 🔴 Budget merge mob bi tieu ton sai -> bo sot cell
   File: MobStackingManager.java (mergeCell + mergeWorld)
   Nguyen nhan: mergeCell tra ve so TARGET da duyet qua (processed), khong
   phai so merge thuc hien. Cell toan mob khong merge duoc (khac loai/khac
   variant) van tieu 500 budget/tick -> cac cell sau trong cung tick bi bo
   qua hoan toan -> merge phan bo cuc lech, mot so chunk mob khong bao gio
   duoc gop.
   Fix: mergeCell dem `merged++` chi khi merge thuc su xay ra, tra ve merged.
   mergeWorld: moi cell VISITED ton 1 don vi budget + cong them so merge thuc
   te - tranh tieu sai dong thoi van gioi han duoc cell + merge/tick.

#32 🔴 Verify chong dup gan nhu vo hieu (gom nham meta)
   File: DuplicationProtector.java (accumulateDelta + signatureKey)
   Nguyen nhan: comment mo ta sai - `ItemStack.hashCode()` KHONG chua meta
   (chi type + amount), ma normalized() da set amount=1 -> chu ky thuc te =
   loai item + hang so -> MOI item cung loai (du khac enchant/durability/PDC)
   gop thanh 1 nhom. Delta so sanh theo tong nhom da tron lan -> verify vua
   false-negative (bo sot dup that) vua false-positive (rollback oan item
   hop le). Lop bao ve cho cam giac an toan gia.
   Fix: bo signatureKey/groupIndex, doi sang nhom bang isSimilar voi
   representative (cung pattern countByType). Snapshot inventory <=54 slot
   nen linear scan du nhanh. Xoa luon method signatureKey() vi comment cua
   no chinh la tuyen bo sai.


================================================================================
DOT 2 - MAT DU LIEU / RACE / KHOA
================================================================================

#1 🔴 Race mat config khi async write dung luc flush
#2 🔴 configSaveRunning khet true khi sync fallback bi cancel
   File: MauaHopper.java (saveConfigAsync / writePendingConfigSave /
   flushConfigSave - viet lai toan bo pipeline)
   Nguyen nhan:
   - Co che cu "gen khop moi ghi": writer da nhan snapshot ra khoi queue,
     flush capture duoc null + bump gen -> writer thay gen lech bo qua ghi,
     ma flush khong giu snapshot nao -> MAT CONFIG (khong can exception nao,
     race window nho nhung that).
   - Flag configSaveRunning chi duoc clear trong finally cua fallback task -
     flush cancel task -> finally khong chay -> flag khet true vinh vien,
     moi lan flush doi du 300ms + warning.
   Fix:
   - Them `configSaveLastWritten`: snapshot chi bi bo qua khi DA CO NGUOI ghi
     dung no (hoac moi hon) - thay vi so sanh gen hien tai.
   - Them `pendingConfigSaveGen`: snapshot di kem the he de flush biet minh
     dang ghi snapshot thu may.
   - Catch block: giai phong configSaveRunning + notifyAll NGAY, truoc khi
     schedule fallback.
   - Scheduler da dong (server tat): retry ghi truc tiep tren luong async
     (file I/O thuan, khong can scheduler) cho het mat snapshot.

#34 🟡 Preset protection nuot config tung key
   File: ConfigManager.java (applyProtectionPreset)
   Nguyen nhan: mode safe/balanced/performance hardcode gan het cac key
   (anti_duplication, per_hopper_transfer_lock, ...) - nguoi dung dat
   protection.per_hopper_transfer_lock: false o mode safe bi bo qua IM LANG,
   khong warning. Chi mode default doc du key.
   Fix: helper boolOr(cfg, key, presetDefault) - preset chi lam DEFAULT, key
   nao nguoi dung tu dat trong config deu duoc ton trong o MOI mode. Backward
   compatible: server khong dat key nao -> hanh vi y het cu.

#14 🟡 Dropper khong lock destination qua DuplicationProtector
   File: HopperTicker.java (tickDropperAt)
   Nguyen nhan: duong hopper luon tryLockContainer destination, duong cart
   cung lock, rieng dropper goi transferBatchBetweenInventories /
   transferToFurnace tran - thieu nhat quan voi co che chong re-entrant,
   plugin khac hook cung container co the double-transfer.
   Fix: ca 2 nhanh (furnace + container thuong) boc tryLockContainer /
   unlockContainer trong finally. tryLockContainer tra true ngay khi config
   tat block_concurrent_container_access - khong phat sinh chi phi khi khong
   dung.


================================================================================
DOT 3 - LEAK MAP / TPS
================================================================================

#3/#13-residual 🟡 Map keyed chunk song sau khi chunk het hopper
   File: HopperTicker.java (unregisterHopper)
   Ghi chú: v28p5 DA don 2 map nay khi chunk unload (dung la co o do) - phan
   con sot: hopper bi PHA khi chunk van loaded -> entry nam lai toi khi
   unload. Fix: khi chunk het hopper (locs.isEmpty()), don luon
   chunkHasItems + inactiveChunkBackoff entry cua chunk do.

#26 🟡 updateDisplay chay cho moi item spawn (hotspot farm)
   File: ItemStackingManager.java (updateDisplay)
   Nguyen nhan: moi item spawn deu rewrite lore + setItemMeta + setItemStack
   (broadcast metadata) - farm nem hang ngan item/tick, moi cai bi merge 2
   tick sau van tra gia day du lan dau.
   Fix: total <= 64 va lore CHUA CO marker -> bo qua rewrite lore (surface
   vanilla da hien DUNG so that). Van setAmount + cache + updateHologram.
   Marker REGEX: di duong day du cho an toan. Hanh vi hien thi khong doi.

#25 🟡 mergeWorld dung String key + split/parseInt
   File: ItemStackingManager.java (mergeWorld + mergeCross)
   Nguyen nhan: bucket key "cx,cz" concat string cho moi item moi merge tick,
   cross lai split(",") + parseInt. attractWorld da doi packed long o loi #15
   nhung mergeWorld quen chua doi - inconsistent.
   Fix: packed long ((long)cx << 32) | (cz & 0xffffffffL) - 0 alloc string,
   decode O(1), so am dung nho mask 32 bit.

#35 🟡 lastTickMs stale khi ticker nghi - quyet dinh throttle sai
   File: PerformanceOptimizer.java (shouldThrottle)
   Nguyen nhan: runTick early-return truoc endTick khi plugin inactive ->
   lastTickMs giu gia tri cu bao lau -> con so tick rieng cu van duoc dem vao
   quyet dinh throttle.
   Fix: chi tinh instant khi vua do trong ~2 tick gan nhat
   (nanoTime - lastTickNs < 100ms), nguoc lai chi tinh uoc luong TPS server.


================================================================================
DOT 4 - NHO / DEAD CODE / VE SINH
================================================================================

#4 🟡 runTick catch Exception bo sot Error
   File: HopperTicker.java
   Fix: catch (Exception | LinkageError) - bat NoClassDefFoundError tu NMS
   reflection. KHONG dung Throwable tho (khong nuot OOM/ThreadDeath).

#5 🟡 Cooldown 1 tick thanh 2 tick o polling mode (khong canh bao)
   File: ConfigManager.java
   Fix: clamp min 2 + comment cho slowChunkCooldownTicks, idleCooldownTicks,
   dropperChainTransferTicks, minCascadeCooldownTicks - dung voi hanh vi thuc
   te cua bo decimate thay vi im lang lech 1 tick.

#7 🟡 Flush 300ms roi van doc config co the cu/nua voi
   File: MauaHopper.java (flushConfigSave)
   Fix: sau warning timeout, last-resort saveConfig() (ghi dong bo snapshot
   moi nhat tu bo nho) truoc khi nguoi goi doc lai config - bao dam disk co
   du lieu moi nhat tren duong hop I/O bat thuong.

#15 🟡 Dropper rotate offset dem lan, cua so quet lech
   File: HopperTicker.java (processDropperChains)
   Fix: tien offset theo max(skipped, budget) thay vi max(processed, budget)
   - khi cua so dap vao cum dropper dang cooldown (processed thap), cua so
   van roi khoi vung vua quet, khong co cum nao bi quet lai 2 lan lien tiep.
   (Ban dau dinh doi thu tu dem skipped nhung tu phat hien nguy co starvation
   - chot phuong an chi doi cach tien offset, giu nguyen thu tu dem.)

#16 🟢 Dead code onDispense (tinh target/targetState khong dung)
   File: HopperTicker.java
   Fix: xoa block "AC integration con do" gay hieu nham con gate.

#28 🟢 Dead branch count == null (2 cho)
   File: MobStackingManager.java (splitStack + mount handler)
   Fix: getStackCount tra int primitive (auto-box) khong bao gio null - doi
   Integer -> int, bo dead branch.

#29 🟢 Stream trong onPlayerPickup
   File: ItemStackingManager.java
   Fix: leftover.values().stream().mapToInt(...).sum() -> vong lap - dung
   pattern da toi uu o cac cho khac, cat alloc IntStream moi lan pickup.

#33 🟢 VIRTUAL_KEYS dead field
   File: DuplicationProtector.java
   Fix: xoa field (snapshot() khong con dung, chi con 1 comment tham chieu) +
   sua comment cu mo ta sai "van duoc dung boi snapshot path".

#36 🟢 PlayerToggleManager timer khong luu handle
   File: PlayerToggleManager.java + MauaHopper.java (onDisable)
   Fix: luu cleanupTask, them shutdown(), goi tu onDisable - phong PlugMan/
   manager khong cancel task cua plugin cu, timer cu chay mai tren instance cu.


================================================================================
LOI RUT KHOI DANH SACH (doc lai ky, khong phai loi)
================================================================================

#6  Fallback sync task schedule luc shutdown nem ngoai le tho
    -> DA DUOC FIX GIAN TIEP boi dot 2: runTask duoc boc
       try/catch (IllegalPluginAccessException | IllegalStateException).

#21 expandNextAt leak UUID
    -> KHONG phai leak: map <= 1 entry/player, bi ghi de moi lan click,
       remove khi quit. Kich thuoc bi chan boi so player online.


================================================================================
KHUYEN NGHI TEST
================================================================================
1. Farm dispenser nhieu item + dispenser_fast_interval_ticks > 1 - chay deu
   30 phut, khong con chu ky 10 phut dung (kiem tra #11).
2. Dat COBBLESTONE vao hopper.blacklisted_blocks_for_pickup, nem cobble len
   hopper - khong bi hut ngay tuc khac (kiem tra #12).
3. Farm mob nhieu loai gan nhau (bo + ga + lon cung chuong) - merge phan bo
   deu, khong con loai nao bi bo doi (kiem tra #22).
4. /reload hoac PlugMan reload khi dang co config save pending - khong mat
   thay doi config, khong warning "van dang chay sau 300ms" lap lai
   (kiem tra #1, #2, #7).
5. Bat protection.mode: safe + dat protection.per_hopper_transfer_lock:
   false - reload, kiem tra log khong con bi nuot (kiem tra #34).
6. Server chay 24h+ voi nhieu nguoi choi di lai - heap on dinh, khong tang
   dan (kiem tra #3/#13, #21 - leak map).
7. Farm spawn hang ngan item/tick - MSPT giam so voi v28p5 (kiem tra #26,
   #25).
8. Mob sat thuong (fall damage / entity attack) chet tren mob chong tang -
   khong dup, khong mat item, PDC don sach (regression check sau cac dot
   patch).

Regression check chung: hopper/dropper/furnace/minecart chuyen item 2 chieu,
item stacking + mob stacking + hologram, crafter 1.21, composter/cauldron.
================================================================================
