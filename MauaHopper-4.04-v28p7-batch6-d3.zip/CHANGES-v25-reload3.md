# MauaHopper 4.04-PATCHED-v25-reload3

Bao gom toan bo cac batch truoc + final reload handshake hardening.

## Reload hardening
- flushConfigSave chi clear configSaveRunning khi BukkitTask.cancel() tra true, tuc task bi huy truoc khi chay.
- Neu task da bat dau chay, flush giu nguyen running va cho writer hoan tat, tranh ghi de snapshot trong luc writer dang active.

## Verify
- Brace/paren/bracket balance toan bo Java.
- Grep call-site reload hardening.
