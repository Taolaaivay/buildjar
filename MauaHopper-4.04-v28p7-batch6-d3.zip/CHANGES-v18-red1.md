# MauaHopper 4.04-PATCHED-v18-red1

Patch batch red 1 - 12 loi muc do.

## Da sua
1. BigChest insert(): bo quet page 0 moi lan, dung insertPage/insertIdx cursor wrap-around.
2. BigChest compress: them cooldown-ms mac dinh 3000 cho nut GUI va compress.on-close.
3. BigChest Collector: check World.isChunkLoaded(bx,bz) truoc khi getChunkAt, khong sync-load chunk.
4. MobStacking mergeTick: bo world.getLivingEntities() full-world, doi sang getNearbyEntities quanh player.
5. Hopper batch pickup: adaptive - workload lon hon 256 thi query hep tung hopper, tranh O(hopper × item).
6. Chunk unload: don hotQueue/tickWheel/hotKeys cho hopper thuoc chunk bi unload.
7. destroyBigChest: gom isSimilar thanh stack toi da truoc khi spawn item entity.
8. Vault deposit: check EconomyResponse.transactionSuccess() bang reflection.
9. flushAndClear: markDirty() moi khi GUI ghi vao pages.
10. Nut BigChest: validate GUI truoc flush, chan whitelist bypass qua next/prev/close/sell/sort/compress/settings.
11. DuplicationProtector verify: nhom signature serialized O(N), bo vong isSimilar O(N²) thong thuong.

## Verify da chay
- Brace/paren/bracket balance cho toan bo file Java.
- Grep call-site cho cac ham/thuat toan moi.

## Ghi chu
- compress.cooldown-ms co the cau hinh trong chests.yml; mac dinh 3000ms.
