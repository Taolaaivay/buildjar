# PATCH-NOTES-v28p7-batch3 (2026-09-29) - Dot 3: alloc tren duong nong + log spam

## Loi #8 - Pickup pass build string roi parse lai
HopperTicker.java :1856-1890
- Bo chunkKey string build + parse lastIndexOf/substring/parseInt. Tinh
  packed-long truc tiep tu Location cho 3x3 neighbor lookup. 0 string alloc
  them, xoa nhanh catch fallback.

## Loi #9 - Blacklist pickup bang String.name() + khong nhat quan
ConfigManager.java :125, :276-280 + HopperTicker.java :1989, :2060, :3592
- Them blacklistedMaterialsForPickup (EnumSet<Material>, build 1 lan o load(),
  Material.matchMaterial cho ca legacy name).
- 2 sweep path: contains String.name() -> contains enum, O(1), 0 alloc.
- Immediate path (:3592): BO vong equalsIgnoreCase O(n) - truoc day immediate
  path so khop KHONG phan biet hoa thuong con sweep path EXACT -> config viet
  thuong chi chan 1 trong 2 duong. Bay gio ca 2 duong dung chung 1 EnumSet.

## Loi #10 - Alloc le tren duong nong
HopperTicker.java
- :601 ckLoc chi build khi chunk THUC SU inactive (truoc day moi hopper/
  luot).
- :3393 anyPlayerNear: p.getLocation() -> toa do primitive, 0 alloc.
- 5 site getLocation().add() (:887, :912, :1012, :2306, :2352) -> 1 alloc
  new Location(world, x+0.5, y+.., z+0.5).

## Loi #11 - vehicleQueryCache churn voi cart
HopperTicker.java :2169, :2177, :2193
- cartCachePurge(): remove 3 slot key theo UUID khi EntitiesUnload +
  VehicleDestroy. Truoc day entry song toi 60s, chi bi age-purge khi map >20k.

## Loi #12 - crafterPulseAt phinh trong window 10 phut
HopperTicker.java :3057, :3082
- Dat entry SAU throttle check - moi lan craft bi throttle khong con ghi.

## Loi #13 - Log WARNING moi tick khi loi lap
HopperTicker.java :362-371, :2999
- lastTickErrorLogMs: full stack trace lan dau + toi da 1 lan/phut.

## Verify
- Brace balance 0 (parens delta -1 co san tu goc).
- Grep: blacklistedMaterialsForPickup 3HT+3CM, cartCachePurge 2+1,
  lastTickErrorLogMs 2+1, crafterPulseAt.put 1, getLocation().add 0,
  old blacklist patterns 0, typeName 0, ckLoc 2 (trong nhanh inactive),
  monotonicMillis 4.
