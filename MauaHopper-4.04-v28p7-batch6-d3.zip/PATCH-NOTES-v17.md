# MauaHopper 4.04-PATCHED-v17 - Patch Notes

Nang cap tu v16. Da ra soat 100% source (13 file Java ~15.000 dong) truoc khi patch.
Patch chia 4 dot, uu tien nang -> nhe. Tat ca patch deu co comment "PATCH v17" trong code.

## Dot 1 - Nang (TPS / data)

1. **MobStackingManager.mergeWorld O(n^2) -> bucket chunk** (+ reach = ceil(radius/16),
   forward-half dedup, cap 500 target/tick, cell cap 256). Mob farm lon khong con
   quet n^2 moi dot merge.
2. **ItemStackingManager mergeTick**: dirty tick chi quet getNearbyEntities quanh
   nguoi choi (dedupe UUID, scanR = max(32, radius, attractRadius)+8). Idle safety
   scan 10s van quet toan world de don stack mo coi. Vanilla merge VAN bi cancel
   khi item co PDC (bat buoc - vanilla merge 2 stack PDC bang nhau cung mat do).
3. **BigChestManager ghi atomic**: saveYamlAtomic() - ghi .tmp roi ATOMIC_MOVE
   (fallback REPLACE). Crash giua luc save khong con lam bigchests.yml rong.
4. **config.yml**: hopper.pickup.interval_ticks 1 -> 2 (giam tan so sweep).
5. **HopperTicker fallback work_queue:false**: processed++ dem MOI hopper duoc tick
   (truoc day chi dem khi moved>0 -> max_per_tick khong chan duoc hopper rong).
6. **writeSnapshot khong con doc config tu thread async** (duoc giai quyet triet de
   o patch #13 bang cach xoa luon SQL).
7. **Ledger PDC <= 0 (corrupt) khong con xoa lang item**: go PDC, giu surface
   amount, o 3 cho (transfer batch / furnace / crafter feed). Chu y: site
   "remaining <= 0 sau khi feed" la cleanup DUNG - khong sua.

## Dot 2 - Trung binh

8. (Khong phai loi - ConfigManager.put() da co try/catch tu dau.)
9. **max_per_chunk duoc ENFORCE that**: handler BlockPlaceEvent HIGHEST cancel khi
   chunk dat gioi han (truoc day chi log warning). Hopper cu duoc grandfathered.
10. **ConfigManager.messageCache**: getMessage() doc cache, nap lai o load/reload.
11. **AC lookup chi goi khi moved == 0** (du phong neu bat -Dmauahopper.ac=true).

## Dot 3 - Nhe / dead code

12. **Xoa dead code hologram**: refreshHologram + 8 call site + holoPct. Giu lai
    holos + removeHologram de don armor stand cua ban cu.
13. **XOÁ TRỌN SQL layer**: 10 method + 4 field, load() chi con YAML,
    writeSnapshot thang vao atomic save. **DU LIEU: v17 khong con doc SQL -
    storage chi YAML. Neu dang dung storage: mysql/sqlite phai chuyen ve
    bigchests.yml TRUOC khi update.**
14. **XOÁ TRỌN AdvancedChests integration**: 487 dong block (reflection helpers,
    push/pull AC, busy check) + 14 call site o hopper/minecart/dropper/
    onInventoryMove/dispenser. Plugin khong con phu thuoc AC o bat ky dang nao.
    Chuc nang migrate YAML migrate-from-ac trong BigChestManager giu nguyen.
15. **Xoa 9 key config dead ("CHUA DUNG")** + block storage/sqlite/mysql trong
    config.yml + 9 field tuong ung trong ConfigManager (verify khong file nao
    dung truoc khi xoa).

## Dot 4 - Regression tu tim duoc khi check lai (v17b)

16. Mob bucket gia dinh radius <= 16 co the SOT cap neu admin cau hinh
    stacking.mobs.radius > 16 -> reach = ceil(radius/16) (v17b).

## Bien doi file (v16 -> v17)

- HopperTicker: 3603 -> 3093 dong
- BigChestManager: 2889 -> 2730 dong
- ConfigManager: 547 -> 537 dong
- ItemStackingManager: 840 -> 859 dong
- MobStackingManager: 596 -> 653 dong
- config.yml: 325 -> 303 dong
- pom.xml: version 4.04-PATCHED-v17

## Checklist test sau khi deploy

1. mvn package -> deploy.
2. Dat >120 hopper trong 1 chunk -> bi chan + thong bao (#9).
3. /mh reload -> message van hien thi dung (#10).
4. Kill server dung luc Rương To dang autosave/save -> bigchests.yml nguyen,
   co the con file .tmp roi la binh thuong (#3).
5. Mob farm tap trung -> MSPT giam; mob cach >16 block van gop du neu radius
   cau hinh lon (#1 + v17b).
6. Item roi xa nguoi choi khong bi quet moi dirty tick; item gan nguoi gop ngay (#2).
7. Farm nhieu hopper rong + work_queue:false -> khong con quet vo han (#5).
8. Neu tung dung storage: sql -> xac nhan da chuyen du lieu ve YAML TRUOC khi
   chay v17 (#13 - quan trong nhat ve du lieu).
