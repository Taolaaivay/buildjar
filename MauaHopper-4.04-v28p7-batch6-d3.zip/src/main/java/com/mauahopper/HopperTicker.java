package com.mauahopper;

import org.bukkit.scheduler.BukkitTask;
import org.bukkit.*;
import org.bukkit.block.*;
import org.bukkit.block.data.BlockData;
import org.bukkit.block.data.Directional;
import org.bukkit.block.data.Levelled;
import org.bukkit.block.data.type.Crafter;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Item;
import org.bukkit.entity.minecart.HopperMinecart;
import org.bukkit.event.*;
import org.bukkit.event.EventPriority;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.ItemSpawnEvent;
import org.bukkit.event.inventory.*;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.world.ChunkLoadEvent;
import org.bukkit.event.world.ChunkUnloadEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.util.BoundingBox;
import org.bukkit.util.Vector;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;
import java.util.logging.Level;

public class HopperTicker implements Listener {

    // FIX TPS: 4 loai rail - tranh getType().name().contains("RAIL") cap
    // phat string cho moi hopper moi luot xu ly.
    private static final java.util.Set<Material> RAIL_BLOCKS = java.util.Set.of(
            Material.RAIL, Material.POWERED_RAIL,
            Material.DETECTOR_RAIL, Material.ACTIVATOR_RAIL);

    // FIX TPS: NamespacedKey khong doi - tao 1 lan (truoc day cap phat moi
    // lan goi cleanMovedStack/countSimilar/realAmount, rat nhieu lan/tick).
    // p7 FIX: doi sang lazy holder - truoc day khoi tao static bang
    // MauaHopper.getInstance() co nguy co NPE neu class bi cham truoc khi
    // instance gan (init-order hazard). Lazy holder chi khoi tao o LAN DAU
    // GOI RUNTIME (luc do plugin da onEnable lau).
    private static NamespacedKey stackKey() {
        return StackKeyHolder.KEY;
    }
    private static final class StackKeyHolder {
        static final NamespacedKey KEY = new NamespacedKey(MauaHopper.getInstance(), "stack_amount");
    }

    private final MauaHopper plugin;

    // Registered hopper locations per world:chunk key → set of locations
    private final Map<String, Set<Location>> chunkHoppers = new ConcurrentHashMap<>();
    // PATCH 2026-09-29 (batch 2, loi #5): packed-long mirror cua tap key chunk
    // dang co >= 1 hopper. Dung cho markChunkHasItems check 3x3 LAN CAN bang
    // long lookup O(1) (khong string alloc). Sync tai 4 diem: registerHopper,
    // unregisterHopper, onChunkUnload, stop().
    private final java.util.Set<Long> hopperChunks = ConcurrentHashMap.newKeySet();

    // Composter/cauldron/crafter blocks a hopper has actually fed, tracked per chunk
    // key so they can count toward max_per_chunk without ever scanning a whole chunk.
    private final Map<String, Set<Location>> chunkSpecialBlocks = new ConcurrentHashMap<>();

    // Registered dropper locations
    private final Map<String, Set<Location>> chunkDroppers = new ConcurrentHashMap<>();

    // v66: Registered dispenser locations (auto burst - tu ban khong can redstone)
    private final Map<String, Set<Location>> chunkDispensers = new ConcurrentHashMap<>();
    private final Map<Location, Integer> dispenserCooldowns = new ConcurrentHashMap<>();

    // v67: cache chunk dang "active" (co nguoi choi gan), tinh lai moi 20 tick
    private final java.util.Set<Long> activeChunks = new java.util.HashSet<>();
    private long lastActiveChunkScan = 0;
    // PATCH 2026-09-28 (loi #5): signature tap chunk cua nguoi choi - chi
    // rebuild khi co nguoi doi chunk, server AFK o farm khong mat alloc.
    private long lastActiveChunkSig = Long.MIN_VALUE;

    // v67.21: offset xoay vong - tranh bo doi (starvation) khi so luong vuot
    // max_*_per_tick: truoc day vong lap break o gioi han, cac thuc the cuoi
    // danh sach khong bao gio duoc xu ly (nghiem trong voi 2000 lo + dan
    // minecart chay vong cua nguoi choi).
    private int cartRotateOffset = 0;
    private int hopperRotateOffset = 0;
    private int dropperRotateOffset = 0;
    private int dispenserRotateOffset = 0;
    private java.util.List<Map.Entry<String, Set<Location>>> hopperEntriesSnapshot;
    private long lastHopperEntrySnapshotMs = 0;
    private java.util.List<Map.Entry<String, Set<Location>>> dispenserEntriesSnapshot;
    private long lastDispenserEntrySnapshotMs = 0;
    // PATCH v28p7-batch6-d1 (loi #1): snapshot + offset xoay vong cho
    // directSuctionPass - pattern dong bo voi hopper/dispenser o tren.
    private int suctionRotateOffset = 0;
    private java.util.List<Map.Entry<String, Set<Location>>> suctionEntriesSnapshot;
    private long lastSuctionEntrySnapshotMs = 0;

    // Per-location cooldown counters (ticks remaining before next transfer)
    private final Map<Location, Integer> hopperCooldowns   = new ConcurrentHashMap<>();
    private int pickupTickCounter = 0;
    private final Map<Location, Integer> dropperCooldowns  = new ConcurrentHashMap<>();

    // Full-idle skip tracking: location → ticks remaining in idle skip
    private final Map<Location, Integer> hopperFullIdle    = new ConcurrentHashMap<>();

    // Item entity lock set (prevents double-pickup)
    private final Set<UUID> lockedItems = ConcurrentHashMap.newKeySet();

    // Chunk item presence hint (skip pickup scan if false)
    // FIX 2026-09-28 (loi #12 - TPS): doi key String "world:x:z" -> packed
    // long (packChunkKey). Lookup 3x3 lang gieng truoc day concat 9 string
    // moi chunk moi luot pickup scan - bay gio 0 string alloc.
    // FIX (loi #13): scratch Location dung lai cho minecart chunk check.
    private final org.bukkit.Location scratchCartLoc = new org.bukkit.Location(null, 0, 0, 0);

    private final Map<Long, Boolean> chunkHasItems = new ConcurrentHashMap<>();
    // PATCH v28p7-batch5 (loi #1 - TPS): hint TRUOC DAY chi set TRUE (spawn
    // event) nen khong bao gio FALSE duoc -> check 3x3 luon dung, chunk trong
    // van bi quet AABB vo ich moi pickup pass. Bay gio: quet sach -> set
    // FALSE cho chunk, skip AABB cho den khi co item spawn lai. Rui ro item
    // TRÔI vào chunk (nuoc chay day qua bien chunk, piston...) khong fire
    // spawn event -> cham dut bang PURGE dinh ky 5 giay: het FALSE, chunk
    // duoc quet lai it nhat moi 5s. Chunk trong: giam ~stagger x 10 (cooldown)
    // x 5s so lan quet AABB; chunk co item: khong doi hanh vi nao.
    private long chunkHasItemsPurgeAt = 0L;
    private final Map<Long, Long> nextContainerPullAt = new ConcurrentHashMap<>();
    private final Map<Long, Long> nextContainerPushAt = new ConcurrentHashMap<>();
    // v67.7: chunk vua quet sach (khong thay item nao) duoc nghi 10 tick
    // truoc khi quet lai - tranh AABB query moi tick mai mai cho chunk tung
    // co item roi (chunkHasItems chi set TRUE, khong bao gio FALSE duoc).
    private final Map<Long, Integer> chunkPickupCooldowns = new ConcurrentHashMap<>();

    // Minecart hopper cache
    private List<HopperMinecart> cachedMinecarts = new ArrayList<>();
    // PATCH 2026-09-28 (loi #1/#2/#19): companion set - add/contains O(1).
    // List.contains tren ArrayList la O(n) cho MOI entity o EntitiesLoadEvent
    // (500 cart -> moi chunk load mob phai duyet chuoi 500 phan tu), va
    // VehicleCreateEvent add KHONG check trung -> cart vao cache 2 lan,
    // bi xu ly 2 lan moi pass (double AABB query + double transfer).
    private final java.util.Set<HopperMinecart> cachedMinecartSet = new java.util.LinkedHashSet<>();
    // PATCH v28p3 (loi #7 - TPS): safety-scan minecart chay TUNG PHAN
    // 200 chunk/tick thay vi toan bo world trong 1 tick. Truoc day lan
    // scan (30 phut/lan, nhung van la spike) duyet MỌI loaded chunk x
    // getEntities() trong 1 tick - server 3k+ chunk lag ngay tuc khac.
    private List<HopperMinecart> minecartRescanResult = new ArrayList<>();
    private int rescanWorldIdx = 0;
    private int rescanChunkIdx = 0;
    private boolean minecartRescanActive = false;
    // PERF (2026-09-27): da scan seed lan dau chua - safety rebuild phia sau
    // chay rat thua vi cache duoc giu tuoi bang event.
    private boolean minecartSeeded = false;
    private int minecartScanCountdown = 0;

    // PATCH 2026-09-28 (loi #1/#2/#19): 2 cau truc LUON dong bo voi nhau.
    private void cartAdd(HopperMinecart cart) {
        if (cachedMinecartSet.add(cart)) cachedMinecarts.add(cart);
    }
    private void cartRemove(HopperMinecart cart) {
        if (cachedMinecartSet.remove(cart)) cachedMinecarts.remove(cart);
    }
    private void cartClear() {
        cachedMinecartSet.clear();
        cachedMinecarts.clear();
    }

    // Stats
    private final AtomicLong readyHoppers      = new AtomicLong(0);
    // PATCH 2026-09-27 (check perf): cache debug.log_transfers - 4 cho doc
    // parse YAML moi lan composter/cauldron transfer (cung pattern loi #14).
    private boolean logTransfersCached = false;
    private int logTransfersTick = 0;
    private final AtomicLong registeredHoppers = new AtomicLong(0);

    // Special-block stats (composter/cauldron), shown in /dh stats
    private final AtomicLong composterFeeds    = new AtomicLong(0);
    private final AtomicLong bonemealCollected = new AtomicLong(0);
    private final AtomicLong cauldronFills     = new AtomicLong(0);
    private final AtomicLong cauldronDrains    = new AtomicLong(0);

    private BukkitTask tickTask;

    public HopperTicker(MauaHopper plugin) {
        this.plugin = plugin;
    }

    // =========================================================================
    // Lifecycle
    // =========================================================================

    public void start() {
        plugin.getServer().getPluginManager().registerEvents(this, plugin);
        scanAllLoadedHoppers();
        scheduleTick();
    }

    public void stop() {
        if (tickTask != null) tickTask.cancel();
        HandlerList.unregisterAll(this);
        chunkHoppers.clear();
        hopperChunks.clear(); // PATCH batch 2 (loi #5)
        chunkDroppers.clear();
        // AUDIT FIX 2026-09-28: reset bo dem tuong ung - khong sau reload
        // counter cao hon thuc te (processDropperChains skip nham).
        dropperTotal = 0;
        chunkDispensers.clear();
        hopperCooldowns.clear();
        dropperCooldowns.clear();
        dispenserCooldowns.clear();
        lockedItems.clear();
        hopperFullIdle.clear();
        chunkHasItems.clear();
        chunkPickupCooldowns.clear();
        crafterPulseCount.clear();
        lastFastDispenserBurstTick.clear();
        crafterRetriggerNextAt.clear();
        activeChunks.clear();
        slowChunks.clear();
        cartClear();
        // PATCH v28p3 (loi #11): cac map con lai truoc day khong ai don -
        // reload ma khong recreate ticker thi du lieu cu song sot, vinh vien
        // chan/pull sai theo state cu.
        chunkSpecialBlocks.clear();
        nextContainerPullAt.clear();
        nextContainerPushAt.clear();
        vehicleQueryCache.clear();
        spawnImmediateNextAt.clear();
        crafterPulseAt.clear();
        inactiveChunkBackoff.clear();
        minecartRescanResult.clear();
        fullRefreshPending.clear();
        hopperEntriesSnapshot = null;
        dispenserEntriesSnapshot = null;
        hotKeys.clear();
        hotQueue.clear();
        for (java.util.ArrayDeque<Location> bucket : tickWheel) bucket.clear();
    }

    private void scheduleTick() {
        // 1-tick repeating task on the main thread — required since runTick()
        // touches Bukkit world/block/entity APIs throughout (hoppers, minecarts,
        // droppers, item pickup). Server is Paper-only (no Folia), so the plain
        // Bukkit scheduler is used directly instead of FoliaLib. Per-tick cost is
        // already bounded by PerformanceOptimizer/maxHoppersPerTick/maxMinecartsPerTick,
        // so sync scheduling is safe.
        tickTask = plugin.getServer().getScheduler().runTaskTimer(plugin, this::runTick, 1L, 1L);
    }

    // =========================================================================
    // Main tick
    // =========================================================================

    private void runTick() {
        // PATCH (check perf): refresh cache debug flag moi 20 tick
        if (++logTransfersTick >= 20) {
            logTransfersTick = 0;
            logTransfersCached = plugin.getConfig().getBoolean("debug.log_transfers", false);
        }
        // PATCH v28p7-batch5-P2 (loi #10): tang monotonicMillis TRUOC gate
        // active. Truoc day dong ho dung khi plugin inactive -> cac gate
        // thoi gian (pull/push container) thay khoang cach 0 khi vua bat
        // lai -> transfer o at ngay tick dau tien sau khi bat lai.
        monotonicMillis += 50L; // PATCH batch 2 (loi #4)
        if (plugin.isShuttingDown() || !plugin.isActive()) return;

        PerformanceOptimizer perf = plugin.getPerformanceOptimizer();
        perf.startTick();

        if (perf.shouldThrottle()) {
            perf.endTick();
            return;
        }

        try {
            decrementAllCooldowns();

            // v4.04m FIX LEAK: crafterPulseCount giu entry mai mai khi crafter
            // het nguyen lieu giua pulse (put() o tryRetrigger khong co ai
            // remove). Moi crafter tung craft = 1 Location key ket vinh vien.
            // Purge dinh ky: block khong con la crafter thi bo.
            tickCounter++;
            // FIX: reset counter NGAY CA KHI khong co gi de purge - truoc
            // day tickCounter tang mai mai khi 2 map rong (int overflow sau
            // ~3 nam uptime, logic lech).
            if (tickCounter >= 12000) tickCounter = 0;
            // v28p6 FIX (loi #11): tickCounter bi reset ve 0 moi 12000 tick
            // lam hieu (tickCounter - lastFastDispenserBurstTick) am lon ->
            // gate dispenser khoa burst ~10 phut sau moi chu ky. Bo dem RIENG
            // khong bao gio reset cho gate dispenser.
            dispenserGateTick++;
            // AUDIT PATCH: purge ca khi chi con retrigger throttle de don noi dung.
            if (tickCounter == 0 && (!crafterPulseCount.isEmpty() || !crafterRetriggerNextAt.isEmpty())) {
                long now = System.currentTimeMillis();
                crafterPulseCount.keySet().removeIf(loc -> {
                    try {
                        Long at = crafterPulseAt.get(loc);
                        return loc.getWorld() == null
                                || loc.getBlock().getType() != Material.CRAFTER
                                || (at != null && now - at > 10 * 60 * 1000L);
                    } catch (Throwable t) {
                        return true;
                    }
                });
                crafterPulseAt.keySet().removeIf(loc -> !crafterPulseCount.containsKey(loc));
                // AUDIT PATCH B4 (du): crafterRetriggerNextAt truoc day khong ai don
                // -> leak 1 entry/crafter da tung retrigger. Don khi block doi kieu,
                // world mat, hoac throttle da het han (crafter con nong se tu re-add).
                crafterRetriggerNextAt.entrySet().removeIf(en -> {
                    try {
                        Location loc = en.getKey();
                        Long nextAt = en.getValue();
                        return loc.getWorld() == null
                                || loc.getBlock().getType() != Material.CRAFTER
                                || (nextAt != null && nextAt < now);
                    } catch (Throwable t) {
                        return true;
                    }
                });
            }

            // ===== v4.04s WORK QUEUE ENGINE =====
            wheelTick++;
            // 1. Cooldown het han -> rot vao hot queue (ring buffer O(1))
            java.util.ArrayDeque<Location> dueNow = tickWheel[(int)(wheelTick & WHEEL_MASK)];
            if (!dueNow.isEmpty()) {
                Location l;
                while ((l = dueNow.poll()) != null) {
                    if (hotKeys.add(packKey(l))) hotQueue.addLast(l);
                }
            }
            // 2. Full refresh dinh ky: luoi an toan cho nguon kep ben
            // ngoai (nguoi choi bo do vao chest tren hopper ma khong ai
            // danh thuc). FIX TPS: tuy chinh performance.full_refresh_ticks
            // (mac dinh 40 tick = 2 giay) - truoc day hardcode 10 tick nen
            // server nhieu hopper bi nhet NGUYEN danh sach vao queue moi
            // 0.5s, queue phinh vo han + budget AIMD khong theo kip.
            ConfigManager cfgW = plugin.getConfigManager();
            if (cfgW.workQueueEnabled && wheelTick - lastFullRefreshTick >= cfgW.fullRefreshTicks) {
                lastFullRefreshTick = wheelTick;
                // FIX TPS 2026-09-28: khong nhet NGUYEN danh sach hopper vao
                // queue trong 1 tick (server 5k+ hopper = 5k enqueue spike).
                // Gom vao pending roi nhet dan theo tung tick cho toi het.
                fullRefreshPending.clear();
                for (java.util.Set<Location> locs : chunkHoppers.values()) {
                    fullRefreshPending.addAll(locs);
                }
            }
            if (!fullRefreshPending.isEmpty()) {
                int n = Math.min(fullRefreshPending.size(), Math.max(200, adaptiveBudget * 4));
                for (int i = 0; i < n; i++) {
                    Location l = fullRefreshPending.remove(fullRefreshPending.size() - 1);
                    if (hotKeys.add(packKey(l))) hotQueue.addLast(l);
                }
            }

            if (plugin.getConfigManager().minecartHopperEnabled) {
                processHopperMinecarts();
            }

            processHopperTransfers();

            if (plugin.getConfigManager().dropperChainEnabled) {
                processDropperChains();
            }

            // v66: dispenser tu ban theo nhip ticker, khong can redstone kich hoat
            if (plugin.getConfigManager().dispenserAutoBurst) {
                processDispenserAutoBurst();
            }

            if (plugin.getConfigManager().pickupEnabled && plugin.getConfigManager().hopperEnabled) { // v67.11
                // Sweep item entity đắt đỏ (getNearbyEntities). Vanilla hopper
                // cũng chỉ quét vài tick 1 lần - throttle tương tự, giảm ~75% tải
                // phần này (spark: 6.6% tick server) mà người chơi không nhận ra.
                // v67.28: nhip pickup cau hinh duoc (mac dinh MOI TICK = hut
                // ngay, khac phuc nem do vao nuoc ma phai cho 4 tick). Chunk sach
                // van duoc bao ve boi cooldown 10 tick (v67.7) - chi phi thuc te
                // chi o chunk dang co do roi. Muon nhe CPU: interval_ticks 2-4.
                if ((++pickupTickCounter % Math.max(1, plugin.getConfigManager().pickupIntervalTicks)) == 0) {
                    runFastPickupPass();
        directSuctionPass(); // batch7: hut truc tiep, bao dam pickup hoat dong
                }
            }

        // v28p6 FIX (loi #4): bat them LinkageError - NMS reflection
        // (dispenseOnceNMS/primeCrafterNMS) co the nem NoClassDefFoundError
        // (la Error, khong phai Exception) khi version server khong tuong
        // thich -> truoc day loi thoat khoi catch, spam stack trace tho moi
        // tick. KHONG dung Throwable tho: khong nuot OOM/ThreadDeath.
        } catch (Exception | LinkageError e) {
            // PATCH 2026-09-29 (batch 3, loi #13): in FULL stack trace lan
            // dau + toi da 1 lan/phut. Truoc day loi lap lai (vd NMS mismatch
            // o duong con lai ngoai dispenser) in stack trace cho MOI tick =
            // spam log + I/O dung luc server dang yeu.
            long errNow = System.currentTimeMillis();
            if (errNow - lastTickErrorLogMs > 60000L) {
                lastTickErrorLogMs = errNow;
                plugin.getLogger().log(Level.WARNING, "[HopperTicker] lỗi tick", e);
            }
        }

        perf.endTick();
    }

    private int cooldownDecimateCounter;
    private int lockedItemsCleanupCounter;
    private int pickupScanRotate;
    private final java.util.ArrayList<Location> fullRefreshPending = new java.util.ArrayList<>();
    /** Gate nho chong spam immediate-pickup tren event spawn/drop (FIX TPS 2026-09-28). */
    // PATCH 2026-09-29 (batch 4, loi #A): doi key String "world:x:z" sang
    // packed-long (packChunkKey). Truoc day MOI item spawn event deu build 1
    // string concat - farm mob hang nghin item/giay alloc lien tuc.
    private final java.util.Map<Long, Long> spawnImmediateNextAt = new java.util.concurrent.ConcurrentHashMap<>();

    /** Cho phep immediate pickup cho chunk nay chua? Toi thieu 100ms/lan - bao
     *  ve event spawn hang loat khoi chay full pickup cho MOI item roi. */
    private boolean trySpawnImmediateGate(Location loc) {
        long key = packChunkKey(loc); // PATCH batch 4 (loi #A): packed-long
        long now = System.currentTimeMillis();
        Long next = spawnImmediateNextAt.get(key);
        if (next != null && now < next) return false;
        // PATCH v28p3 (loi #10): qua 50k chi don entry HET HAN (qua 30s),
        // khong clear() toan bo nhu truoc - clear-all lam loat item spawn
        // ngay sau do duoc immediate-pickup DONG LOAT = spike pickup vo
        // ich ngay dung luc server dang ban.
        if (spawnImmediateNextAt.size() > 50_000) {
            long cutoff = now - 30_000L;
            spawnImmediateNextAt.entrySet().removeIf(en -> en.getValue() < cutoff);
        }
        spawnImmediateNextAt.put(key, now + 100L);
        return true;
    }
    private void decrementAllCooldowns() {
        // FIX TPS 2026-09-28: duyet map cooldown giam NUA chi phi bang cach
        // chay moi 2 tick, decrement 2 de cooldown het DUNG HAN (granularity
        // 100ms thay vi 50ms - khong ai dat cooldown < 2 tick). Voi map
        // nghin entry day la khoan tiet kiem lon tren moi tick.
        if ((++cooldownDecimateCounter & 1) == 0) return;
        decrementMap(hopperCooldowns, 2);
        decrementMap(dropperCooldowns, 2);
        decrementMap(dispenserCooldowns, 2);
        decrementMap(hopperFullIdle, 2);
        // PATCH v28p3 (loi #12): cooldown nghi chunk sau quet sach DUOC
        // GIAM TAP TRUNG O DAY (moi 2 tick) thay vi giam dan tai cho theo
        // stagger - truoc day chunk chi duoc giam khi stagger chon toi, nen
        // cooldown 10 tick thuc te keo dai gap `stagger` lan (40 tick voi
        // stagger=4): item roi vao chunk dang nghi bi pickup tre bat thuong.
        decrementMap(chunkPickupCooldowns, 2);
    }

    /**
     * Giảm cooldown mà KHÔNG gọi Map.Entry.setValue().
     * setValue() trên entry của map bất biến ném
     * UnsupportedOperationException message=null tại hàm "setValue" -
     * đúng bằng chứng "tick error: null at setValue)" trong log.
     * Dùng Map.replace/remove(key, value) an toàn trên mọi Map implementation.
     */
    // PATCH v28p3 (loi #12): generic <K> de dung chung cho Location-key va
    // packed-long key (chunkPickupCooldowns - doi tu String o P2 loi #9) -
    // khong can 2 ban gan trung nhau.
    private static <K> void decrementMap(Map<K, Integer> map, int dec) {
        if (map.isEmpty()) return;
        map.forEach((key, oldValue) -> {
            int v = oldValue - dec;
            if (v <= 0) {
                map.remove(key, oldValue);
            } else {
                map.replace(key, oldValue, v);
            }
        });
    }

    // =========================================================================
    // Hopper transfer loop
    // =========================================================================

    // =====================================================================
    // PLAYER RADIUS GATE (v67) - farm tu ngu khi khong co nguoi choi gan.
    // Tinh tap chunk active 1 lan moi 20 tick (moi world), dung chung cho
    // hopper/dropper/minecart/pickup. require_player_radius <= 0 = tat gate.
    // =====================================================================
    /** FIX TPS 2026-09-28: key chunk dang long packed (hash ten world + toa do
     *  chunk 21 bit/truc = ±33 trieu block) - rebuild moi giay khong con cap
     *  chuoi "world:x:z" nua (radius 96 = 169 chunk x N nguoi choi). */
    private static long packChunkKey(String worldName, int cx, int cz) {
        // PATCH 2026-09-28 (loi #9): worldName.hashCode() << 42 chi giu 22
        // bit CAO - 2 world ten khac nhau co the trung 22 bit cao -> chunk
        // nham lan giua cac world (hopper world A bi coi "co nguoi gan" nho
        // nguoi choi o world B). Tron bang murmur fmix32 truoc khi cat.
        return (worldBits(worldName) << 42) | ((cx & 0x1FFFFFL) << 21) | (cz & 0x1FFFFFL);
    }

    /** murmur fmix32 - tron hashCode ten world ve 22 bit, giu 21 bit/truc. */
    private static long worldBits(String worldName) {
        int h = worldName.hashCode();
        h ^= h >>> 16;
        h *= 0x85ebca6b;
        h ^= h >>> 13;
        return (long) (h & 0x3FFFFF);
    }

    private static long packChunkKey(Location loc) {
        // p7 FIX: world co the null voi location tu event/unload - sentinel
        // MIN_VALUE khong trung chunk that nao -> caller chi miss hint, an toan.
        if (loc.getWorld() == null) return Long.MIN_VALUE;
        return packChunkKey(loc.getWorld().getName(), loc.getBlockX() >> 4, loc.getBlockZ() >> 4);
    }

    private static long parseChunkKeyPacked(String key) {
        int sep1 = key.lastIndexOf(':');
        int sep2 = sep1 > 0 ? key.lastIndexOf(':', sep1 - 1) : -1;
        if (sep1 <= 0 || sep2 <= 0) return Long.MIN_VALUE;
        try {
            return packChunkKey(key.substring(0, sep2),
                    Integer.parseInt(key.substring(sep2 + 1, sep1)),
                    Integer.parseInt(key.substring(sep1 + 1)));
        } catch (NumberFormatException e) {
            return Long.MIN_VALUE;
        }
    }

    private boolean isChunkActive(String key, ConfigManager cfg, long now) {
        return isChunkActivePacked(parseChunkKeyPacked(key), cfg, now);
    }

    private boolean isChunkActive(Location loc, ConfigManager cfg, long now) {
        return isChunkActivePacked(packChunkKey(loc), cfg, now);
    }

    private boolean isChunkActivePacked(long packedKey, ConfigManager cfg, long now) {
        // CAM FIX: khong cho require_player_radius config phong qua lon.
        double radius = Math.min(cfg.requirePlayerRadius, 96.0);
        if (radius <= 0) return true;
        if (now - lastActiveChunkScan >= 1000) {
            lastActiveChunkScan = now;
            // PATCH 2026-09-28 (loi #5): chi rebuild khi vi tri chunk cua
            // nguoi choi THAY DOI - server AFK o farm khong con mat ~17k
            // Long alloc/giay cho clear+rebuild y het.
            long sig = Bukkit.getOnlinePlayers().size();
            // PATCH v28p7-batch6-d3 (loi #6): them UUID on dinh cua tung
            // nguoi choi vao sig - 2 nguoi CUNG chunk cung di chuyen sang
            // chunk moi (X^X = Z^Z = 0) truoc day khong doi sig -> activeChunks
            // khong rebuild -> chunk moi bi coi inactive vo thoi han. UUID mix
            // lam sig doi bat ke 2 nguoi co dung chunk nhau hay khong.
            for (var p : Bukkit.getOnlinePlayers())
                sig ^= packChunkKey(p.getLocation()) ^ p.getUniqueId().getLeastSignificantBits();
            if (sig == lastActiveChunkSig) return activeChunks.contains(packedKey);
            lastActiveChunkSig = sig;
            activeChunks.clear();
            int rr = ((int) Math.ceil(radius)) >> 4;
            for (var p : Bukkit.getOnlinePlayers()) {
                Location l = p.getLocation();
                int cx = l.getBlockX() >> 4, cz = l.getBlockZ() >> 4;
                long w = worldBits(l.getWorld().getName()) << 42;
                for (int dx = -rr; dx <= rr; dx++) {
                    for (int dz = -rr; dz <= rr; dz++) {
                        activeChunks.add(w | (((cx + dx) & 0x1FFFFFL) << 21) | ((cz + dz) & 0x1FFFFFL));
                    }
                }
            }
        }
        return activeChunks.contains(packedKey);
    }

    // v67.13: cache chunk "slow" (co nguoi choi da /mh toggle trong 24
    // block) - tinh lai moi 20 tick, thay the vong lap player cho TUNG
    // hopper moi tick (v67.5 lam the nay rat ton CPU tren server dong nguoi).
    // Nguoi choi da tat fast hopper duoc uu tien: chunk do chay nhip vanilla.
    private final java.util.Set<Long> slowChunks = new java.util.HashSet<>();
    private long lastSlowScan = 0;
    // PATCH 2026-09-28 (loi #5): signature cho slowChunks - dong ly do.
    private long lastSlowChunkSig = Long.MIN_VALUE;

    private boolean isSlowChunk(String key, ConfigManager cfg, long now) {
        return isSlowChunkPacked(parseChunkKeyPacked(key), cfg, now);
    }

    private boolean isSlowChunk(Location loc, ConfigManager cfg, long now) {
        return isSlowChunkPacked(packChunkKey(loc), cfg, now);
    }

    private boolean isSlowChunkPacked(long packedKey, ConfigManager cfg, long now) {
        if (!cfg.respectPlayerToggle) return false;
        if (now - lastSlowScan >= 1000) {
            lastSlowScan = now;
            // PATCH 2026-09-28 (loi #5): chi rebuild khi danh sach nguoi
            // choi da /mh toggle (hoac vi tri chunk cua ho) thay doi.
            long sig = Bukkit.getOnlinePlayers().size();
            for (var p : Bukkit.getOnlinePlayers()) {
                if (plugin.getPlayerToggleManager().isEnabledFor(p.getUniqueId())) continue;
                // PATCH v28p7-batch6-d3 (loi #6): mix UUID nhu isChunkActivePacked.
                sig ^= packChunkKey(p.getLocation()) ^ p.getUniqueId().getLeastSignificantBits();
            }
            if (sig == lastSlowChunkSig) return slowChunks.contains(packedKey);
            lastSlowChunkSig = sig;
            slowChunks.clear();
            int rr = Math.max(1, 24 >> 4);
            for (var p : Bukkit.getOnlinePlayers()) {
                if (plugin.getPlayerToggleManager().isEnabledFor(p.getUniqueId())) continue;
                Location l = p.getLocation();
                int cx = l.getBlockX() >> 4, cz = l.getBlockZ() >> 4;
                long w = worldBits(l.getWorld().getName()) << 42;
                for (int dx = -rr; dx <= rr; dx++) {
                    for (int dz = -rr; dz <= rr; dz++) {
                        slowChunks.add(w | (((cx + dx) & 0x1FFFFFL) << 21) | ((cz + dz) & 0x1FFFFFL));
                    }
                }
            }
        }
        return slowChunks.contains(packedKey);
    }

    /** v4.04s: rut gon work queue - chi xu ly nhung hopper CO VIEC.
     *  Backpressure: queue phinh qua 2x budget -> tang budget gap 2x, dam
     *  bao cam trieu item truyen lien tuc khong bao gio tac nghen. */
    private void drainWorkQueue(ConfigManager cfg) {
        SpeedManager speed = plugin.getSpeedManager();
        // v4.04t AIMD: budget tu hoc tu thoi gian tick thuc te.
        int maxBudget = resolveMaxHoppersPerTick(cfg);
        if (adaptiveBudget < 0 || adaptiveBudget > maxBudget * 2) adaptiveBudget = maxBudget;
        // backpressure: queue phinh -> ep len gap 2x ngay
        if (hotQueue.size() > adaptiveBudget * 2) adaptiveBudget = Math.min(adaptiveBudget * 2, maxBudget * 2);
        int budget = adaptiveBudget;
        int processedCtr = 0; // PATCH 2026-09-27 (loi #18): dem hopper duoc xu ly cho /mh stats
        long t0 = System.nanoTime();
        long nowMs = System.currentTimeMillis();
        while (budget > 0) {
            Location loc = hotQueue.poll();
            if (loc == null) break;
            hotKeys.remove(packKey(loc));
            budget--;
            if (loc.getWorld() == null) { unregisterHopper(loc); continue; }
            if (!plugin.getWorldManager().isWorldAllowed(loc.getWorld())) continue;
            // chunk khong active -> hoan lai sau 20 tick, KHONG mat viec.
            // v4.04v: chi hoan neu hopper VAN con registered - neu da bi
            // unregister (chunk unload, block vo) thi bo luon, khong de
            // phantom entry song mai trong wheel.
            // FIX TPS: chunkKey dung string "world:x:z".
            // PATCH 2026-09-29 (batch 3, loi #10): chi build KHI chunk
            // thuc su inactive (truoc day build cho MOI hopper moi luot du
            // chi dung trong nhanh hiem nay).
            if (!isChunkActive(loc, cfg, nowMs)) {
                String ckLoc = chunkKey(loc);
                java.util.Set<Location> reg = chunkHoppers.get(ckLoc);
                if (reg != null && reg.contains(loc)) {
                    // AUDIT FIX P3: backoff chunk inactive 20 -> 40 -> 80 -> 160
                    // thay vi re-queue co dinh 20 tick cho farm khong nguoi.
                    // PATCH 2026-09-29 (batch 2, loi #7): cap GIA TRI LUU trong
                    // map (truoc day Math.min chi ap cho bien local - gia tri
                    // trong map tich luy vo han toi khi chunk active).
                    int backoff = inactiveChunkBackoff.merge(packChunkKey(loc), 20, (a, b) -> Math.min(160, a + b));
                    tickWheel[(int)((wheelTick + backoff) & WHEEL_MASK)].addLast(loc);
                }
                continue;
            }
            inactiveChunkBackoff.remove(packChunkKey(loc));
            boolean slowMode = isSlowChunk(loc, cfg, nowMs);
            int moved = tickHopperAt(loc, cfg, speed, slowMode);
            processedCtr++;
            if (moved > 0) {
                plugin.getPerformanceOptimizer().recordHopperItemsMoved(moved);
                plugin.getPerformanceOptimizer().recordTransfer();
                int cooldown = Math.max(cfg.minCascadeCooldownTicks, speed.getTransferTicks());
                if (slowMode) cooldown = Math.max(cooldown, cfg.slowChunkCooldownTicks);
                scheduleHopperProcess(loc, cooldown); // chuoi tu noi duy tri
            }
            // PATCH v28p7-batch5-p3h (sua loi cua p3g - xin loi): p3g them
            // "else scheduleHopperProcess" o day da gay BUNG NO ban sao hopper
            // trong timing wheel theo cap so nhan: tickHopperAt DA tu len
            // lich o dong 798 (hopper trong) va 816 (totalMoved==0) roi
            // return 0, else lai them 1 ban sao nua -> 1->2->4->8... trong
            // chuc giay wheel ngap ban sao rong, drain bi ban sao ngap ->
            // hopper that bi chon -> "khong chuyen nua". HUY else nay.
            // Truong hop roi wheel THUC SU chi con: tryLockHopper that bai
            // (dong 803) - duoc xu ly o FIX 2 ben duoi.
        }
        // v4.04t AIMD (TCP-style): do thoi gian drain thuc te - nhanh thi
        // tang budget dan (+1/tick), cham hon 4ms thi giam phan 2 ngay
        // lap tuc. Bao dam luon chay SAT ngong ma khong bao gio vuot.
        long drainMs = (System.nanoTime() - t0) / 1_000_000;
        if (drainMs > 4) adaptiveBudget = Math.max(16, adaptiveBudget / 2);
        else if (adaptiveBudget < maxBudget * 2) adaptiveBudget++;
        // PATCH 2026-09-27 (loi #18): cap nhat stats cho CA HAI mode.
        // Truoc day chi nhanh polling cu set readyHoppers -> /mh stats luon
        // hien 0 khi work_queue: true (mac dinh).
        readyHoppers.set(processedCtr);
    }

    private void processHopperTransfers() {
        ConfigManager cfg   = plugin.getConfigManager();
        // v67.11: hopper.enabled=false -> bo qua toan bo xu ly, vanilla da
        // duoc mo lai o cac event handler
        if (!cfg.hopperEnabled) return;
        // v4.04s: WORK QUEUE MODE - chi xu ly hopper co trong hot queue.
        // Polling loop ben duoi chi chay khi work_queue: false (fallback).
        if (cfg.workQueueEnabled) {
            drainWorkQueue(cfg);
            return;
        }
        SpeedManager speed  = plugin.getSpeedManager();
        int maxPerTick      = resolveMaxHoppersPerTick(cfg);
        int processed       = 0;

        // v67.21: snapshot (lam moi moi 10 tick, tranh alloc moi tick) + xoay
        // vong. Truoc day break o gioi han -> chunk cuoi map KHONG BAO GIO
        // duoc xu ly khi so chunk vuot maxPerTick - nghiem trong o quy mo
        // farm 2000 lo / hang nghin hopper.
        long nowMs = System.currentTimeMillis();
        if (hopperEntriesSnapshot == null || nowMs - lastHopperEntrySnapshotMs > 500) {
            lastHopperEntrySnapshotMs = nowMs;
            hopperEntriesSnapshot = new java.util.ArrayList<>(chunkHoppers.entrySet());
        }
        int entryCount = hopperEntriesSnapshot.size();
        if (entryCount == 0) return;
        int entryStart = hopperRotateOffset % entryCount;
        hopperRotateOffset = (hopperRotateOffset + Math.max(1, maxPerTick)) % entryCount;

        for (int ei = 0; ei < entryCount && (processed < maxPerTick || maxPerTick <= 0); ei++) {
            Map.Entry<String, Set<Location>> entry = hopperEntriesSnapshot.get((entryStart + ei) % entryCount);
            // PATCH v28p7-batch6: KHÔNG gate player-cho-transfer nua (engine
            // Donut khong gate - hopper chay moi tick du nguoi choi o dau).
            // isChunkActive chi con dung cho pickup sweep.
            for (Location loc : entry.getValue()) {
                if (processed >= maxPerTick && maxPerTick > 0) break;
                if (hopperCooldowns.containsKey(loc)) continue;
                // Full-idle: bỏ qua trong thờI gian idle. EXPIRE do decrementMap
        // (trong decrementAllCooldowns, chạy mỗi tick) đảm nhận - KHÔNG cần
        // decrement thêm ở đây (tránh double-decrement làm idle còn nửa thờI gian).
        if (hopperFullIdle.containsKey(loc)) continue;
                if (!plugin.getWorldManager().isWorldAllowed(loc.getWorld())) continue;

                // v67.13: chunk co nguoi da /mh toggle gan do -> nhip vanilla
                boolean slowMode = isSlowChunk(entry.getKey(), cfg, System.currentTimeMillis());
                int moved = tickHopperAt(loc, cfg, speed, slowMode);
                // PATCH v17: dem MỌI hopper da xu ly (ke ca rong/idle) - truoc
                // day chi dem khi moved>0 nen max_per_tick khong chan duoc vong
                // quet tren server nhieu hopper rong.
                processed++;
                if (moved > 0) {
                    plugin.getPerformanceOptimizer().recordHopperItemsMoved(moved);
                    plugin.getPerformanceOptimizer().recordTransfer();
                    // PATCH v28p7-batch6: nhip Donut goc - MỌI TICK khi
                    // transfer_ticks=1 (truoc day Math.max(minCascade=2, ...)
                    // kep cứng toi thieu 2 tick du config 1). Chi nghi khi
                    // nguoi dung chu dong dat transfer_ticks > 1.
                    int cooldown = Math.max(0, speed.getTransferTicks() - 1);
                    // slow mode phai ton trong du ca khi transfer_ticks=0, neu khong
                    // nguoi da /mh toggle van thay hopper chay toc do cao.
                    if (slowMode) hopperCooldowns.put(loc, cfg.slowChunkCooldownTicks);
                    else if (cooldown > 0) hopperCooldowns.put(loc, cooldown);
                }
            }
        }

        readyHoppers.set(processed);
    }

    /** v4.04q: inventory khong co item nao (hopper = 5 slot, quet rat re). */
    private boolean isInventoryEmpty(Inventory inv) {
        for (ItemStack it : inv.getStorageContents()) {
            if (it != null && !it.getType().isAir()) return false;
        }
        return true;
    }

    /** v4.04q: phia tren hopper co nguon de hut khong. instanceof Container
     *  tu dong bao phu moi loai container (ke ca block tuong lai); WATER =
     *  chest boat; RAIL = minecart; composter/cauldron check rieng. */
    private boolean canPullFromAbove(Block above, ConfigManager cfg) {
        Material at = above.getType();
        if (at == Material.AIR) return false;
        if (above.getState(false) instanceof Container) return true;
        String tn = at.name();
        if (at == Material.WATER) return true;            // chest boat noi
        if (RAIL_BLOCKS.contains(at)) return true;        // minecart tren rail
        if (at == Material.COMPOSTER || tn.contains("CAULDRON")) return true;
        return false; // PATCH v17: removed legacy block path
    }

    /** v4.04s: len lich cho hopper chay lai sau n tick. Queue mode:
     *  vao timing wheel O(1), den han tu rot vao hot queue. Polling mode:
     *  fallback cooldown map nhu cu. */
    private void scheduleHopperProcess(Location loc, int ticks) {
        if (!plugin.getConfigManager().workQueueEnabled) {
            if (ticks > 0) hopperCooldowns.put(loc, ticks);
            return;
        }
        // v4.04w: cooldown >= WHEEL_SIZE (4096 tick) khong the nam trong
        // 1 vong wheel - clamp xuong WHEEL_SIZE-1. Fire SOM 1 chut la VO HAI
        // (hopper thuc day, thay khong co viec, tu len lich lai - tu chuan).
        if (ticks >= WHEEL_SIZE) ticks = WHEEL_SIZE - 1;
        long dueTick = wheelTick + Math.max(1, ticks);
        // v4.04t: ring buffer index = dueTick & MASK (bitmask, khong modulo)
        tickWheel[(int)(dueTick & WHEEL_MASK)].addLast(loc);
    }

    private int resolveMaxHoppersPerTick(ConfigManager cfg) {
        if (cfg.maxHoppersPerTick > 0) return cfg.maxHoppersPerTick;
        // v67.14: che dong "0 = khong gioi han" truoc day tra ve total hopper
        // (server 5000 hopper -> xu ly 5000/tick -> chet TPS). Gio cap 500.
        int total = (int) registeredHoppers.get();
        return Math.min(Math.max(total, 50), 500);
    }

    /**
     * Process one hopper for this tick.
     * Returns the number of items moved (0 = nothing happened).
     */
    private int tickHopperAt(Location loc, ConfigManager cfg, SpeedManager speed, boolean slowMode) {
        Block block = loc.getBlock();
        if (block.getType() != Material.HOPPER) {
            unregisterHopper(loc);
            return 0;
        }

        BlockState state = block.getState(false);
        if (!(state instanceof org.bukkit.block.Hopper hopper)) return 0;

        // v4.04q PERF (port DonutHopper shouldSkipHopperProcessing): hopper
        // RONG va phia tren khong co nguon nao de hut -> khong chay transfer
        // scan, chi dat cooldown ngan. Farm 3000 hopper dang cho: chi phi
        // tu ~3000 full-scan/tick xuong ~750 check-re/tick. Tu wake sau
        // idleCooldownTicks khi co do duoc day vao (dropper/sweep) hoac
        // block phia tren thay doi. instanceof Container bao phu MỌI loai
        // container ke ca block moi cua cac ban MC sau nay.
        if (cfg.idleCooldownTicks > 1 && isInventoryEmpty(hopper.getInventory())
                && !canPullFromAbove(block.getRelative(BlockFace.UP), cfg)) {
            scheduleHopperProcess(loc, cfg.idleCooldownTicks);
            return 0;
        }

        DuplicationProtector dupe = plugin.getDuplicationProtector();
        if (!dupe.tryLockHopper(loc)) {
            // PATCH v28p7-batch5-p3h: lock bi giu (contention minecart task)
            // TRUOC DAY return 0 khong len lich -> hopper ROI WHEEL, chi
            // duoc full refresh don (200 tick ~ 10s - dung trieu chung
            // "vai giay moi truyen 1 lan"). Len lich nhe 1 tick sau thu lai.
            scheduleHopperProcess(loc, 1);
            return 0;
        }

        try {
            int totalMoved = 0;

            // Cascade rounds: attempt pull+push up to cascade_rounds times per tick
            // PATCH v28p7-batch6-d1 (loi #9): slow mode (nguoi choi /mh toggle)
            // phai dung nhip vanilla - amountCap=1 chi cap MOI VONG cascade,
            // cascade_rounds=8 van truyen 8 item/tick. Slow mode chi chay 1 vong.
            int rounds = slowMode ? 1 : cfg.cascadeRounds;
            for (int round = 0; round < rounds; round++) {
                int moved = runHopperTransfer(hopper, loc, cfg, speed, dupe, slowMode ? 1 : 0);
                totalMoved += moved;
                if (moved == 0) break;
                if (totalMoved >= cfg.maxItemsPerTick) break;
            }

            // v4.04u: MỌI truong hop totalMoved==0 deu tu len lich chay lai
            // qua timing wheel - KHONG phu thuoc full refresh. Bao dam khong
            // mat item/latency khi truyen nhanh lien tuc:
            // - output day        -> nghi dai idleFullHopperTicks roi tu thu
            // - co nguon tren rong -> thu lai sau idleCooldownTicks (4 tick)
            // - khong len lich duoc nao -> full refresh 10 tick la luoi cuoi
            if (totalMoved == 0) {
                Block below = block.getRelative(BlockFace.DOWN);
                BlockState belowState = below.getState(false);
                if (belowState instanceof Container container
                        && isInventoryFull(container.getInventory())) {
                    scheduleHopperProcess(loc, cfg.getIdleFullHopperTicks());
                } else {
                    scheduleHopperProcess(loc, cfg.idleCooldownTicks);
                }
            }

            return totalMoved;
        } finally {
            dupe.unlockHopper(loc);
        }
    }

    // =====================================================================
    // VEHICLE QUERY CACHE (FIX TPS 2026-09-28) - pull/push_ticks=1 mac dinh
    // khien MỌI hopper co boat/minecart lan can chay 1 AABB query GAN NHU
    // MOI TICK (vanilla hopper 8 tick moi transfer 1 lan). Cache ket qua
    // query theo vi tri, TTL vai tick: boat/minecart/item roi khong doi kip
    // trong khoang do, delay pickup toi da TTL tick - van nhanh gap 2-4x
    // vanilla. Moi lan dung lai KIEM TRA lai ent.isValid() - cache co the
    // giu entity vua chet.
    // =====================================================================
    private static final class CachedVehicleQuery {
        final Entity[] entities;
        final long tick;
        CachedVehicleQuery(Entity[] entities, long tick) { this.entities = entities; this.tick = tick; }
    }
    private final java.util.Map<Long, CachedVehicleQuery> vehicleQueryCache =
            new java.util.concurrent.ConcurrentHashMap<>();

    /** Key cache cho hopper block: 3 slot (boat tren / minecart tren / boat duoi). */
    private static long hopperCacheKey(long packKey, int slot) { return (packKey << 2) | slot; }

    /** Key cache cho minecart entity (UUID xor slot - 3 slot: boat tren / boat duoi / ground pickup). */
    private static long cartCacheKey(Entity cart, int slot) {
        java.util.UUID u = cart.getUniqueId();
        return (u.getMostSignificantBits() ^ u.getLeastSignificantBits() ^ (slot * 0x9E3779B97F4A7C15L));
    }

    private Entity[] queryVehiclesCached(Location center, double rx, double ry, double rz,
                                         java.util.function.Predicate<Entity> filter,
                                         long cacheKey, int ttlTicks) {
        CachedVehicleQuery cached = vehicleQueryCache.get(cacheKey);
        if (cached != null && wheelTick - cached.tick < ttlTicks) return cached.entities;
        java.util.List<Entity> found = new java.util.ArrayList<>(2);
        for (Entity e : center.getWorld().getNearbyEntities(center, rx, ry, rz, filter)) found.add(e);
        Entity[] arr = found.toArray(new Entity[0]);
        // PATCH v28p3 (loi #9 - leak): truoc day cho toi 100k entry moi
        // clear() TOAN BO - vua de leak ca phut, vua gay dot re-query AABB
        // hang loat cung luc (thundering herd). Bay gio: qua 20k thi chi
        // don entry CU HON 60s (1200 tick) - cache dang nong giu nguyen.
        if (vehicleQueryCache.size() > 20_000) {
            long cutoff = wheelTick - 1200;
            vehicleQueryCache.entrySet().removeIf(en -> en.getValue().tick < cutoff);
            // PATCH 2026-09-28 (loi #6): hard cap - entry dang NONG khong bi
            // removeIf theo tuoi xoa duoc -> map van phinh qua 20k khong
            // gioi han cung. Server cuc dong thi thinh thoang clear 1 lan
            // (thundering herd 1 lan la chap nhan duoc so voi OOM).
            if (vehicleQueryCache.size() > 40_000) vehicleQueryCache.clear();
        }
        vehicleQueryCache.put(cacheKey, new CachedVehicleQuery(arr, wheelTick));
        return arr;
    }

    private int runHopperTransfer(
            org.bukkit.block.Hopper hopper, Location loc,
            ConfigManager cfg, SpeedManager speed, DuplicationProtector dupe, int amountCap) {

        int moved = 0;
        // YELLOW FIX: dung pull_ticks de giam tan so pull container.
        int pullTicks = cfg.pullTicks > 0 ? cfg.pullTicks : speed.getTransferTicks();
        long pullKey = packKey(loc);
        long nowPull = monotonicMillis; // PATCH batch 2 (loi #4): thay vi System.currentTimeMillis()
        boolean canPull = nowPull >= nextContainerPullAt.getOrDefault(pullKey, 0L);
        if (canPull && pullTicks > speed.getTransferTicks()) {
            nextContainerPullAt.put(pullKey, nowPull + pullTicks * 50L);
        }

        // --- Pull from above ---
        Block above = loc.getBlock().getRelative(BlockFace.UP);
        BlockState aboveState = above.getState(false);

        // khai bao pull amount SOM (v4.03) - o MUC pull section, truoc tat
        // ca nhanh dung no (thuyen/minecart/container/composter/cauldron)
        int amount = cfg.getEffectivePullAmount();
        if (amountCap > 0 && amount > amountCap) amount = amountCap; // v67.5 slow mode
        // v67.100: RƯƠNG THUYỀN (Boat with Chest) phía trên hopper -> hut nhanh.
        // AABB query nho (nhu minecart duoi), khong scan world. Thuyen cho do
        // tren nuoc + hopper duoi = bang chuyen van chuyen. Vanilla khong co
        // tuong tac nay - day la tinh nang moi theo yeu cau.
        // FIX TPS: ChestBoat KHONG THE cung ton tai voi block Container -
        // bo qua AABB query khi block tren la chest/furnace/hopper...
        if (canPull && moved == 0 && !(aboveState instanceof Container)) {
            for (Entity ent : queryVehiclesCached(
                    new Location(above.getWorld(), above.getX() + 0.5, above.getY() + 0.5, above.getZ() + 0.5), 1.0, 1.0, 1.0,
                    en -> en instanceof org.bukkit.entity.ChestBoat && en.isValid(),
                    hopperCacheKey(packKey(loc), 0), Math.max(2, pullTicks))) {
                if (!ent.isValid()) continue; // cache co the giu entity vua chet
                org.bukkit.inventory.Inventory boatInv =
                        ((org.bukkit.entity.ChestBoat) ent).getInventory();
                if (boatInv.isEmpty()) continue;
                // FIX C1: lock entity inventory nhu container block (chong
                // re-entrant transfer qua hook cua plugin khac).
                if (dupe.tryLockContainer(boatInv)) {
                    try {
                        moved += transferBatchBetweenInventories(boatInv,
                                hopper.getInventory(), amount, cfg, dupe, loc, null);
                    } finally {
                        dupe.unlockContainer(boatInv);
                    }
                    // p7 FIX: break chi sau khi da chuyen - truoc day lock
                    // bi giu la break luon, bo qua boat khac cung AABB.
                    break;
                }
                // lock bi giu: thu boat tiep theo trong AABB thay vi bo qua.
            }
        }

        // FIX v59: minecart TREN RAIL phía trên -> hút nhanh theo config
        // (trước đây nhường vanilla = 1 item/8 tick rat cham).
        if (canPull && moved == 0 && RAIL_BLOCKS.contains(above.getType())) {
            for (Entity ent : queryVehiclesCached(
                    new Location(above.getWorld(), above.getX() + 0.5, above.getY() + 0.7, above.getZ() + 0.5), 1.0, 1.0, 1.0,
                    en -> en instanceof org.bukkit.entity.minecart.StorageMinecart,
                    hopperCacheKey(packKey(loc), 1), Math.max(2, pullTicks))) {
                if (!ent.isValid()) continue; // cache co the giu entity vua chet
                org.bukkit.inventory.Inventory cartInv =
                        ((org.bukkit.entity.minecart.StorageMinecart) ent).getInventory();
                if (cartInv.isEmpty()) continue;
                // FIX v60: tốc độ minecart = hopper × speed_multiplier (mặc định 3x)
                int amt = cfg.minecartTransferAmount > 0
                        ? cfg.minecartTransferAmount
                        : Math.min(64, (int) Math.ceil(
                                cfg.getEffectivePullAmount() * cfg.minecartSpeedMultiplier));
                // FIX C1: lock entity inventory.
                if (dupe.tryLockContainer(cartInv)) {
                    try {
                        moved += transferBatchBetweenInventories(
                                cartInv, hopper.getInventory(), amt, cfg, dupe, loc, null);
                    } finally {
                        dupe.unlockContainer(cartInv);
                    }
                    break; // p7: chi break khi da chuyen
                }
                // lock bi giu: thu cart tiep theo.
            }
        }


        // v4.04 FIX: gate moved == 0 cho doi xung cac nhanh pull khac - tranh
        // double-pull cung tick khi boat/minecart phia tren da chuyen.
        if (canPull && moved == 0 && aboveState instanceof Container srcContainer) {
            Inventory src = srcContainer.getInventory();

            // PERF: src rỗng -> bỏ qua pull, tránh snapshot toàn bộ slot vô ích.
            // Vẫn tiếp tục push phía dưới bình thường (hopper có thể còn đồ).
            if (!src.isEmpty()) {
                Inventory hopperInv = hopper.getInventory();

                // Shulker check
                if (aboveState instanceof ShulkerBox && !cfg.shulkerAllowPulling) {
                    // skip
                } else if (dupe.tryLockContainer(src)) {
                    try {
                        moved += transferBatchBetweenInventories(src, hopperInv, amount, cfg, dupe, loc, null);
                    } finally {
                        dupe.unlockContainer(src);
                    }
                }
            }
        }

        // --- Special: composter directly above (auto-collect bone meal once it's ready) ---
        // AUDIT FIX P4: cac pull dac biet cung phai ton trong pull_ticks.
        if (canPull && moved == 0 && cfg.composterEnabled && cfg.composterAutoCollectBonemeal
                && above.getType() == Material.COMPOSTER) {
            moved += pullBonemealFromComposter(hopper.getInventory(), above);
        }

        // --- Special: cauldron directly above (scoop it out with an empty bucket) ---
        if (canPull && moved == 0 && cfg.cauldronEnabled && isCauldronBlock(above.getType())) {
            moved += pullFromCauldron(hopper.getInventory(), above, cfg);
        }

        // --- Special: check if a crafter is above facing into the hopper ---
        if (canPull && moved == 0 && cfg.crafterEnabled) {
            org.bukkit.block.Crafter crafterAbove = getCrafterFacingHopper(hopper);
            if (crafterAbove != null) {
                // PATCH v28p7-batch6-d3 (loi #13): truoc day pullFromCrafter
                // doc/ghi crafterInv KHONG tryLockContainer - moi nguon pull
                // khac (boat/minecart/container/composter/furnace) deu co
                // lock. Dong bo pattern :1029 de tranh double-transfer khi
                // crafter bi nhieu path cham cung luc (multi-thread/paper
                // region hien tai, Folia sau nay).
                if (dupe.tryLockContainer(crafterAbove.getInventory())) {
                    try {
                        moved += pullFromCrafter(hopper.getInventory(), crafterAbove, cfg);
                    } finally {
                        dupe.unlockContainer(crafterAbove.getInventory());
                    }
                }
            }
        }

        // --- Push to output ---
        // PERF: sau khi pull xong mà hopper vẫn rỗng -> không có gì để push.
        // Bỏ qua toàn bộ lookup output + snapshot + transfer (phần đắt nhất).
        // Pull phía trên đã chạy xong ở trên nên không ảnh hưởng thu thập đồ.
        if (hopper.getInventory().isEmpty()) return moved;

        // GREEN FIX: push_ticks config bay gio co tac dung that.
        int pushTicks = cfg.pushTicks > 0 ? cfg.pushTicks : speed.getTransferTicks();
        long pushKey = packKey(loc);
        long nowPush = monotonicMillis; // PATCH batch 2 (loi #4): thay vi System.currentTimeMillis()
        boolean canPush = nowPush >= nextContainerPushAt.getOrDefault(pushKey, 0L);
        if (canPush && pushTicks > speed.getTransferTicks()) {
            nextContainerPushAt.put(pushKey, nowPush + pushTicks * 50L);
        }
        if (!canPush) return moved;

        Block output = getHopperOutput(loc.getBlock(), hopper);
        if (output == null) return moved;

        // khai bao som (v4.03): fix "cannot find symbol: amount" :539/:604 -
        // truoc day amount duoc khai bao SAU nhanh thuyen/lo
        int pushAmt = cfg.getEffectivePushAmount();
        if (amountCap > 0 && pushAmt > amountCap) pushAmt = amountCap; // v67.5 slow mode

        // v67.100: hopper tren RƯƠNG THUYỀN -> day xuong boat (Boat with Chest).
        // AABB query nho nhu pull - khong scan world.
        // FIX TPS: thuyen chi noi duoc trong AIR hoac WATER - block duoi la
        // chest/furnace... thi khong co thuyen, bo qua query.
        Material outType = output.getType();
        if (moved == 0 && (outType == Material.AIR || outType == Material.WATER)) {
            for (Entity ent : queryVehiclesCached(
                    new Location(output.getWorld(), output.getX() + 0.5, output.getY() + 0.5, output.getZ() + 0.5), 1.0, 1.0, 1.0,
                    en -> en instanceof org.bukkit.entity.ChestBoat && en.isValid(),
                    hopperCacheKey(packKey(loc), 2), Math.max(2, pushTicks))) {
                if (!ent.isValid()) continue; // cache co the giu entity vua chet
                org.bukkit.inventory.Inventory boatInv =
                        ((org.bukkit.entity.ChestBoat) ent).getInventory();
                // FIX C1: lock entity inventory.
                if (dupe.tryLockContainer(boatInv)) {
                    try {
                        moved += transferBatchBetweenInventories(hopper.getInventory(),
                                boatInv, pushAmt, cfg, dupe, loc, null); // v4.03
                    } finally {
                        dupe.unlockContainer(boatInv);
                    }
                }
                break;
            }
            if (moved > 0) return moved;
        }


        BlockState outputState = output.getState(false);

        // Crafter phải xử lý RIÊNG và TRƯỚC: Crafter implements Container trong
        // Bukkit API, nếu để sau thì item sẽ đi qua path container chung và
        // nhét vào cả slot đã bị vô hiệu hóa trên crafter.
        if (outputState instanceof org.bukkit.block.Crafter crafterOut && cfg.crafterEnabled) {
            // v67.98: slow mode -> chi feed 1 slot/luot (truoc day van feed 9
            // du nguoi choi da /mh toggle)
            int feeds = amountCap > 0 ? Math.min(1, cfg.crafterMaxFeedsPerTick) : cfg.crafterMaxFeedsPerTick;
            int perSlot = amountCap > 0 ? 1 : cfg.crafterItemsPerSlot; // v67.99: slow mode = 1 item/ô
            moved += pushItemsToCrafter(hopper.getInventory(), crafterOut, cfg, loc, feeds, perSlot);
            return moved;
        }

        if (!(outputState instanceof Container destContainer)) {
            // Special push blocks: composter, cauldron
            if (output.getType() == Material.COMPOSTER && cfg.composterEnabled) {
                moved += pushItemsToComposter(hopper.getInventory(), output, cfg);
            } else if (isCauldronBlock(output.getType()) && cfg.cauldronEnabled) {
                moved += pushItemsToCauldron(hopper.getInventory(), output, cfg);
            }
            return moved;
        }

        Inventory dest = destContainer.getInventory();

        // Shulker check
        if (outputState instanceof ShulkerBox && !cfg.shulkerAllowPushing) return moved;

        // Furnace special logic - LUON bat (bo config gate v43): furnace bat
        // BUOC qua transferToFurnace de tach fuel/nung. Neu de generic
        // transferBatch, blaze rod bi nhet vao o nung. Vanilla dat fuel dung
        // o - day la behavior dung, khong phai tuy chon.
        // v4.09 FIX #61: instanceof AbstractFurnace (cha chung cua Furnace +
        // Smoker + BlastFurnace) - truoc day instanceof Furnace CHI match lo
        // thuong, Smoker/BlastFurnace roi xuong generic transferBatch = do bi
        // nhet sai slot = KHONG NUNG DUOC.
        if (isAnyFurnace(outputState)) {
            org.bukkit.block.Container furnace = (org.bukkit.block.Container) outputState;
            // FIX v67.23a: org.bukkit.block.Hopper (BlockState) KHONG co getFacing()
            // - facing nam o BlockData. Cast Directional de lay.
            BlockFace facing = facingOf(hopper.getBlockData());
            if (facing == null) return moved;
            // FIX C1: lock furnace inventory (truoc day chay khong lock du
            // transferToFurnace mutate slot fuel/result).
            if (dupe.tryLockContainer(furnace.getInventory())) {
                try {
                    moved += transferToFurnace(hopper.getInventory(), furnace, cfg, dupe, loc,
                            facing == BlockFace.DOWN, pushAmt); // v67.84: truyen amountCap
                } finally {
                    dupe.unlockContainer(furnace.getInventory());
                }
            }
            return moved;
        }

        if (dupe.tryLockContainer(dest)) {
            try {
                moved += transferBatchBetweenInventories(hopper.getInventory(), dest, pushAmt, cfg, dupe, loc,
                        outputState instanceof org.bukkit.block.Crafter oc ? oc : null);
            } finally {
                dupe.unlockContainer(dest);
            }
        }

        return moved;
    }

    // =========================================================================
    // Inventory transfer utilities
    // =========================================================================


    // =====================================================================
    // PDC stacking ledger helpers (v4.06)
    // =====================================================================

    /** Số THẬT của ItemStack có PDC stack_amount (bề mặt có thể chỉ 64). */
    private int stackRealAmount(ItemStack stack) {
        if (stack == null || stack.getType().isAir()) return 0;
        int surface = stack.getAmount();
        try {
            var meta = stack.getItemMeta();
            if (meta != null) {
                Integer v = meta.getPersistentDataContainer().get(
                        stackKey(),
                        org.bukkit.persistence.PersistentDataType.INTEGER);
                if (v != null && v > surface) return v;
            }
        } catch (Exception ex) {
            MauaHopper.fineSafe("Safe catch in HopperTicker", ex);
        }
        return surface;
    }

    /** Ghi lại ledger còn lại cho source stack; tự gỡ PDC khi <=64. */
    private void setStackRealAmount(ItemStack stack, int remaining) {
        if (stack == null) return;
        remaining = Math.max(0, remaining);
        stack.setAmount(remaining <= 0 ? 0 : Math.min(64, remaining));
        try {
            var meta = stack.getItemMeta();
            if (meta == null) return;
            var pdc = meta.getPersistentDataContainer();
            var key = stackKey();
            if (remaining > 64) pdc.set(key, org.bukkit.persistence.PersistentDataType.INTEGER, remaining);
            else pdc.remove(key);
            stack.setItemMeta(meta);
        } catch (Exception ex) {
            MauaHopper.fineSafe("Safe catch in HopperTicker", ex);
        }
    }

    /** Tiêu thụ ĐÚNG 1 đơn vị ledger từ 1 slot inventory đặc biệt
     *  (composter/cauldron). Không dùng surface trừ thẳng với stack PDC. */
    private void consumeOneFromSlot(Inventory inv, int slot, ItemStack item) {
        int real = stackRealAmount(item);
        int remaining = real - 1;
        setStackRealAmount(item, remaining);
        inv.setItem(slot, remaining <= 0 ? null : item);
    }

    /** True nếu stack có ledger stack_amount (kể cả giá trị không hợp lệ). */
    private boolean hasStackLedger(ItemStack stack) {
        try {
            var meta = stack.getItemMeta();
            return meta != null && meta.getPersistentDataContainer().has(
                    stackKey(),
                    org.bukkit.persistence.PersistentDataType.INTEGER);
        } catch (Exception ex) {
            MauaHopper.fineSafe("Safe catch in HopperTicker", ex);
            return false;
        }
    }

    /** Stack sạch để đặt/merge vào inventory đích. CHỈ strip display/PDC với
     *  item thật sự mang ledger stack_amount. Item thường (kể cả đã đổi tên
     *  bằng đe) phải giữ nguyên meta. Không bao giờ clone ledger sang đích. */
    private ItemStack cleanMovedStack(ItemStack src, int amount) {
        boolean stacked = hasStackLedger(src);
        ItemStack out = stacked ? stripStackDisplayName(src) : src.clone();
        out.setAmount(Math.max(0, amount));
        if (stacked) {
            try {
                var meta = out.getItemMeta();
                if (meta != null) {
                    meta.getPersistentDataContainer().remove(stackKey());
                    out.setItemMeta(meta);
                }
            } catch (Exception ex) {
                MauaHopper.fineSafe("Safe catch in HopperTicker", ex);
            }
        }
        return out;
    }

    /**
     * Move up to `amount` items from src to dest.
     * Respects smooth_transfers stack size. Returns actual items moved.
     */
    /**
     * FIX chiếm ô - slot ĐÍCH được phép nhận đồ theo loại block:
     * - Furnace/Smoker/BlastFurnace: chỉ slot 0 (smelting) + 1 (fuel). Slot 2
     *   (result/đồ đã nung) TUYỆT ĐỐI không được ghi - vanilla cũng cấm.
     * - BrewingStand: slot 0-2 (chai), 3 (blaze powder). Không có slot "result"
     *   riêng nhưng không nhét đồ lung tung.
     * - Các block còn lại: toàn bộ slot.
     */
    private java.util.List<Integer> allowedDestSlots(Inventory inv, org.bukkit.block.Crafter crafter) {
        java.util.List<Integer> slots = new java.util.ArrayList<>();
        if (inv instanceof org.bukkit.inventory.FurnaceInventory) {
            slots.add(0); // smelting input
            slots.add(1); // fuel
            // slot 2 = result: KHÔNG bao giờ ghi
            return slots;
        }
        for (int i = 0; i < inv.getSize(); i++) slots.add(i);
        return slots;
    }

    /**
     * FIX chiếm ô - slot NGUỒN được phép rút theo loại block:
     * - Furnace/Smoker/BlastFurnace: CHỈ slot 2 (result). Rút từ slot 0/1 sẽ
     *   ăn mất đồ đang nung / fuel - vanilla chỉ cho lấy từ ô result.
     * - BrewingStand: chỉ slot 0-2 (thuốc hoàn thành), không rút blaze powder.
     * - Các block còn lại: toàn bộ slot.
     */
    // v67.85: cache static - ham nay duoc goi MỖI transfer (hang nghin lan/
    // tick), tao ArrayList moi moi lan la rac vo ich. Slot chi phu thuoc LOẠI
    // inventory + kich thuoc.
    private final Map<String, java.util.List<Integer>> srcSlotCache = new ConcurrentHashMap<>();

    private java.util.List<Integer> allowedSrcSlots(Inventory inv) {
        if (inv instanceof org.bukkit.inventory.FurnaceInventory) {
            return srcSlotCache.computeIfAbsent("furnace", k ->
                    java.util.List.of(2)); // result - ô đồ đã nung
        }
        if (inv instanceof org.bukkit.inventory.BrewerInventory) {
            // PATCH 2026-09-27 (loi #20): them slot 3 - vanilla hopper RUT
            // DUOC ca blaze powder/nguyen lieu o slot 3 cua brewing stand.
            return srcSlotCache.computeIfAbsent("brewer", k ->
                    java.util.List.of(0, 1, 2, 3)); // potion bottles + blaze powder
        }
        return srcSlotCache.computeIfAbsent("all_" + inv.getSize(), k -> {
            java.util.List<Integer> slots = new java.util.ArrayList<>();
            for (int i = 0; i < inv.getSize(); i++) slots.add(i);
            return java.util.Collections.unmodifiableList(slots);
        });
    }

    private int transferBatchBetweenInventories(
            Inventory src, Inventory dest, int amount,
            ConfigManager cfg, DuplicationProtector dupe, Location hopperLoc,
            org.bukkit.block.Crafter destCrafter) {

        // FIX TPS: snapshot (clone toi 54+54 slot) CHI duoc verifyTransfer
        // su dung - ma verifyTransfer no-op khi verify_transfers=false
        // (MAC DINH). Chup anh moi transfer roi bo di la overhead lon nhat
        // con sot lai. antiDuplication van giu y nghia khi verify bat.
        boolean needSnap = cfg.antiDuplication && cfg.verifyTransfers;
        Map<Integer, ItemStack> srcSnap = needSnap ? dupe.snapshot(src) : null;
        Map<Integer, ItemStack> dstSnap = needSnap ? dupe.snapshot(dest) : null;

        int moved = 0;
        int maxPerSlot = cfg.smoothTransfers ? cfg.smoothStackSize : cfg.maxStackPerTransfer;

        java.util.List<Integer> srcSlots = allowedSrcSlots(src);
        java.util.List<Integer> destSlots = allowedDestSlots(dest, destCrafter);

        outer:
        for (int siIdx = 0; siIdx < srcSlots.size() && moved < amount; siIdx++) {
            int si = srcSlots.get(siIdx);
            ItemStack srcItem = src.getItem(si);
            if (srcItem == null || srcItem.getType() == Material.AIR) continue;

            // v4.06: với stack PDC, tồn kho thật nằm ở ledger, không phải surface.
            int srcReal = stackRealAmount(srcItem);
            if (srcReal <= 0) {
                // PATCH v17: ledger hong (<=0) - KHONG xoa item. Go PDC, giu
                // nguyen surface amount. Truoc day xoa lang = mat do am tham.
                setStackRealAmount(srcItem, srcItem.getAmount());
                src.setItem(si, srcItem);
                continue;
            }

            int toMove = Math.max(1, Math.min(srcReal,
                    Math.min(Math.max(1, maxPerSlot),
                    Math.min(amount - moved, srcItem.getMaxStackSize()))));
            ItemStack cleanProbe = cleanMovedStack(srcItem, 1);

            for (int diIdx = 0; diIdx < destSlots.size(); diIdx++) {
                int di = destSlots.get(diIdx);
                if (destCrafter != null && destCrafter.isSlotDisabled(di)) continue;
                if (isShulkerBox(srcItem.getType())
                        && dest.getHolder() instanceof org.bukkit.block.ShulkerBox) continue;
                if (!canInsertInto(dest, di, cleanProbe)) continue;

                ItemStack destItem = dest.getItem(di);
                if (destItem == null || destItem.getType() == Material.AIR) {
                    // Đặt stack SẠCH vào ô trống; source giảm theo ledger thật.
                    dest.setItem(di, cleanMovedStack(srcItem, toMove));
                    int remaining = srcReal - toMove;
                    setStackRealAmount(srcItem, remaining);
                    if (remaining <= 0) src.setItem(si, null);
                    else src.setItem(si, srcItem);
                    moved += toMove;
                    continue outer;
                } else if (destItem.isSimilar(cleanProbe)) {
                    // Chỉ merge vào stack sạch cùng meta. Stack dơ mang PDC không merge.
                    if (isShulkerBox(srcItem.getType())
                            && dest.getHolder() instanceof org.bukkit.block.ShulkerBox) continue;
                    int space = destItem.getMaxStackSize() - destItem.getAmount();
                    if (space <= 0) continue;
                    int fitting = Math.min(toMove, space);
                    destItem.setAmount(destItem.getAmount() + fitting);
                    dest.setItem(di, destItem);

                    int remaining = srcReal - fitting;
                    setStackRealAmount(srcItem, remaining);
                    if (remaining <= 0) src.setItem(si, null);
                    else src.setItem(si, srcItem);

                    moved += fitting;
                    toMove -= fitting;
                    srcReal = remaining;
                    if (toMove <= 0 || srcReal <= 0) continue outer;
                }
            }
        }

        if (moved > 0 && srcSnap != null && dstSnap != null) {
            // p8 FIX: ket qua verify BI BO QUA truoc day - verify fail da
            // ROLLBACK ben trong nhung moved van duoc tinh -> thong ke ao,
            // wake hopper dich, cascade theo so item khong ton tai.
            if (!dupe.verifyTransfer(src, srcSnap, dest, dstSnap, moved, hopperLoc)) {
                return 0;
            }
        }

        if (moved > 0 && dest.getHolder() instanceof org.bukkit.block.Hopper destHopper) {
            wakeHopper(destHopper.getLocation());
        }

        return moved;
    }

    private boolean isInventoryFull(Inventory inv) {
        for (ItemStack item : inv.getStorageContents()) {
            if (item == null || item.getType() == Material.AIR) return false;
            if (item.getAmount() < item.getMaxStackSize()) return false;
        }
        return true;
    }

    // =========================================================================
    // Furnace special logic
    // =========================================================================

    /** v4.09: nhan dien ca 3 loai lo (Furnace/Smoker/BlastFurnace). */
    private boolean isAnyFurnace(BlockState state) {
        return state instanceof org.bukkit.block.Furnace
                || state instanceof org.bukkit.block.Smoker
                || state instanceof org.bukkit.block.BlastFurnace;
    }

    private int transferToFurnace(Inventory hopper, org.bukkit.block.Container furnace, ConfigManager cfg,
                                   DuplicationProtector dupe, Location loc, boolean topInsert,
                                   int amountCap) { // v67.84: ton trong slow mode
        org.bukkit.inventory.FurnaceInventory inv = (org.bukkit.inventory.FurnaceInventory) furnace.getInventory();
        int moved = 0;
        int limit = amountCap > 0 ? Math.min(cfg.getEffectivePushAmount(), amountCap)
                                   : cfg.getEffectivePushAmount();

        outer:
        for (int si = 0; si < hopper.getSize() && moved < limit; si++) {
            ItemStack srcItem = hopper.getItem(si);
            if (srcItem == null || srcItem.getType() == Material.AIR) continue;

            // v4.06: furnace cũng phải tôn trọng ledger PDC, không clone PDC vào lò.
            int srcReal = stackRealAmount(srcItem);
            if (srcReal <= 0) {
                // PATCH v17: repair ledger hong thay vi xoa item.
                setStackRealAmount(srcItem, srcItem.getAmount());
                hopper.setItem(si, srcItem);
                continue;
            }
            int toMove = Math.min(srcReal,
                    Math.min(limit - moved, srcItem.getMaxStackSize()));
            ItemStack cleanProbe = cleanMovedStack(srcItem, 1);

            int[] slotOrder = (cfg.furnaceUseVanillaRouting && topInsert)
                    ? FURNACE_SLOT_SMELT
                    : furnaceSlotOrder(srcItem.getType());

            for (int slot : slotOrder) {
                if (toMove <= 0 || srcReal <= 0) break;
                ItemStack destItem = inv.getItem(slot);
                if (destItem == null || destItem.getType() == Material.AIR) {
                    inv.setItem(slot, cleanMovedStack(srcItem, toMove));
                    int remaining = srcReal - toMove;
                    setStackRealAmount(srcItem, remaining);
                    hopper.setItem(si, remaining <= 0 ? null : srcItem);
                    moved += toMove;
                    toMove = 0;
                    continue outer;
                } else if (destItem.isSimilar(cleanProbe)) {
                    int space = destItem.getMaxStackSize() - destItem.getAmount();
                    if (space <= 0) continue;
                    int give = Math.min(toMove, space);
                    destItem.setAmount(destItem.getAmount() + give);
                    inv.setItem(slot, destItem);

                    int remaining = srcReal - give;
                    setStackRealAmount(srcItem, remaining);
                    hopper.setItem(si, remaining <= 0 ? null : srcItem);
                    moved += give;
                    toMove -= give;
                    srcReal = remaining;
                    if (toMove <= 0 || srcReal <= 0) continue outer;
                }
            }
        }
        if (moved > 0) trackSpecialBlock(furnace.getLocation());
        return moved;
    }

    /** Cache kiểm tra "item có nung được không" theo Material. */
    private static final java.util.Map<Material, Boolean> SMELTABLE_CACHE =
            new java.util.HashMap<>();

    /**
     * Vanilla slot rules khi push vào từng loại inventory đặc biệt:
     * - Lectern: chỉ sách (BookMeta), 1 ô.
     * - Chiseled Bookshelf: chỉ sách, 6 ô.
     * - Brewing Stand: chỉ chai/potion ở ô 0-2; blaze powder + nguyên liệu
     *   đổ thủ công (tránh nhét sai ô tắc máy pha thuốc).
     * Còn lại: cho phép.
     */
    private boolean canInsertInto(Inventory dest, int slot, ItemStack item) {
        if (dest instanceof org.bukkit.inventory.LecternInventory) {
            return slot == 0 && isBook(item);
        }
        if (dest instanceof org.bukkit.inventory.ChiseledBookshelfInventory) {
            return isBook(item);
        }
        if (dest instanceof org.bukkit.inventory.BrewerInventory) {
            if (slot >= 0 && slot <= 2) return isPotionLike(item);
            // v67.30: vanilla cho phep hopper tren bo nguyen lieu vao o 3 -
            // may brew tu dong bi TAC vi bi tu choi truoc day.
            // O 4 (fuel blaze powder) van chi nap tay nhu vanilla, giu nguyen.
            if (slot == 3) return isBrewingIngredient(item);
            return false;
        }
        return true;
    }

    /** Sách (book/written/writable - có BookMeta). */
    private boolean isBook(ItemStack item) {
        return item.getItemMeta() instanceof org.bukkit.inventory.meta.BookMeta;
    }

    /** Chai/potion (đổ vào brewing stand). */
    /** Nguyen lieu pha thuoc hop le cho o ingredient (slot 3) cua brewing stand. */
    private boolean isBrewingIngredient(ItemStack item) {
        switch (item.getType()) {
            case NETHER_WART: case GLOWSTONE_DUST: case REDSTONE: case GUNPOWDER:
            case DRAGON_BREATH: case SPIDER_EYE: case FERMENTED_SPIDER_EYE:
            case MAGMA_CREAM: case SUGAR: case GLISTERING_MELON_SLICE:
            case GHAST_TEAR: case BLAZE_POWDER: case GOLDEN_CARROT:
            case PUFFERFISH: case RABBIT_FOOT: case PHANTOM_MEMBRANE:
                return true;
            default:
                return false;
        }
    }

    private boolean isPotionLike(ItemStack item) {
        var m = item.getType().name();
        return m.equals("POTION") || m.equals("SPLASH_POTION")
                || m.equals("LINGERING_POTION") || m.equals("GLASS_BOTTLE");
    }

    /** Shulker box (mọi màu) - kiểm tra theo Material name suffix. */
    private boolean isShulkerBox(Material type) {
        return type.name().endsWith("SHULKER_BOX");
    }

    /**
     * Item nung được không: có CookingRecipe nào DÙNG item làm nguyên liệu
     * (input) không. QUAN TRỌNG: phải check getInputChoice().test() - dùng
     * Bukkit.getRecipesFor() ở đây là SAI vì nó tìm recipe có KẾT QUẢ là item
     * (vd getRecipesFor(kelp) tim recipe tạo kelp -> không có -> kelp bị
     * phân loại fuel-only -> nhét nhầm ô fuel, dù thực tế kelp nung được).
     */
    private boolean isSmeltable(Material type) {
        return SMELTABLE_CACHE.computeIfAbsent(type, t -> {
            try {
                ItemStack probe = new ItemStack(t);
                var it = org.bukkit.Bukkit.recipeIterator();
                while (it.hasNext()) {
                    org.bukkit.inventory.Recipe r = it.next();
                    if (r instanceof org.bukkit.inventory.CookingRecipe) {
                        var choice = ((org.bukkit.inventory.CookingRecipe<?>) r).getInputChoice();
                        if (choice != null && choice.test(probe)) return true;
                    }
                }
                return false;
            } catch (Exception ex) {
                MauaHopper.fineSafe("Safe catch in HopperTicker", ex);
                return false;
            }
        });
    }

    /**
     * Phân loại slot cho item:
     * - fuel-only (Material#isFuel, không nung được) -> CHỈ ô fuel {1}
     *   (blaze rod, coal, tre, que...)
     * - nung được (kể cả vừa fuel vừa nung: kelp, gỗ...) -> CHỈ ô nung {0}
     * - không fuel không nung (đá, cát...) -> ô nung {0} (như vanilla:
     *   hopper trên đầu lò luôn vào ô nung)
     */
    // PATCH 2026-09-28 (loi #23): ham nam tren duong nong (moi transfer vao
    // lo) - hoan ket qua thanh static final, khong cap phat moi lan goi.
    // Caller da kiem tra: chi iterate, khong ghi vao mang tra ve.
    private static final int[] FURNACE_SLOT_SMELT = new int[]{0};
    private static final int[] FURNACE_SLOT_FUEL  = new int[]{1};
    private static final int[] FURNACE_SLOT_NONE  = new int[]{};

    private int[] furnaceSlotOrder(Material type) {
        boolean fuel = type.isFuel();
        boolean smeltable = isSmeltable(type);
        // Kelp/gỗ (vừa fuel vừa nung): CHỈ ô nung {0} - KHÔNG cho làm fuel,
        // KHÔNG tự nuôi. Nung xong lấy dried kelp, ô fuel để dành cho
        // blaze rod/coal thật.
        if (fuel && smeltable)  return FURNACE_SLOT_SMELT;
        // Fuel-only (blaze rod, coal, tre...): CHỈ ô fuel - nhét lên ô nung
        // là bỏ phí vì không nung được.
        if (fuel)               return FURNACE_SLOT_FUEL;
        // Nung được (thịt, quặng...): CHỈ ô nung {0}.
        if (smeltable)          return FURNACE_SLOT_SMELT;
        // FIX v58: Không fuel KHÔNG nung được (đất, cát, sỏi, rác...) ->
        // TỪ CHỐI vào lò (mảng rỗng = không slot nào). Trước đây nhét vào
        // ô nung theo vanilla -> rác chặn ô, đồ thật không vào được.
        // Config furnace.reject_junk=false để về vanilla (nhét ô nung).
        if (plugin.getConfigManager().furnaceRejectJunk) return FURNACE_SLOT_NONE;
        return FURNACE_SLOT_SMELT; // vanilla: rác vào ô nung
    }

    // =========================================================================
    // Composter logic (vanilla-accurate: 1 item consumed per cycle, chance roll
    // decides whether the level goes up — exactly like a player's hand does it)
    // =========================================================================

    /**
     * Pushes items from a hopper into the composter below it, vanilla-style.
     * Cheap by design: one HashMap lookup per candidate item, no NBT/tile-entity
     * access, no events fired — just direct BlockData reads/writes.
     */
    private int pushItemsToComposter(Inventory hopperInv, Block composterBlock, ConfigManager cfg) {
        BlockData data = composterBlock.getBlockData();
        if (!(data instanceof Levelled level)) return 0;

        // Already "ready" (full) — vanilla refuses more input until emptied.
        if (level.getLevel() >= level.getMaximumLevel()) return 0;

        Map<Material, Float> chances = cfg.composterChances;
        if (chances.isEmpty()) return 0;

        int fed = 0;
        int maxFeeds = cfg.composterMaxFeedsPerTick;

        for (int i = 0; i < hopperInv.getSize() && fed < maxFeeds; i++) {
            ItemStack item = hopperInv.getItem(i);
            if (item == null || item.getType() == Material.AIR) continue;

            Float chance = chances.get(item.getType());
            if (chance == null) continue; // not compostable — leave it untouched, like vanilla

            if (level.getLevel() >= level.getMaximumLevel()) break; // filled mid-loop

            // v4.04 FIX: dung vanilla - roll xac suat ngay ca khi composter
            // dang trong. Kieu cu "level 0 luon thanh cong" lam bonemeal farm
            // nhanh ~2-3x vanilla (comment "vanilla quirk" cu la sai).
            boolean success = Math.random() < chance;

            consumeOneFromSlot(hopperInv, i, item);
            fed++;

            if (success) {
                level.setLevel(level.getLevel() + 1);
                composterBlock.setBlockData(level);
            }
        }

        if (fed > 0) {
            composterFeeds.addAndGet(fed);
            trackSpecialBlock(composterBlock.getLocation());
            if (logTransfersCached) {
                plugin.getLogger().info("[MauaHopper] Composter tại " + formatLoc(composterBlock.getLocation())
                        + " đã nhận " + fed + " item, cấp hiện tại " + level.getLevel() + "/" + level.getMaximumLevel());
            }
        }
        return fed;
    }

    /** A hopper sitting under a "ready" composter collects the bone meal, exactly like a right-click. */
    private int pullBonemealFromComposter(Inventory hopperInv, Block composterBlock) {
        BlockData data = composterBlock.getBlockData();
        if (!(data instanceof Levelled level)) return 0;
        if (level.getLevel() < level.getMaximumLevel()) return 0; // not ready yet

        Map<Integer, ItemStack> leftover = hopperInv.addItem(new ItemStack(Material.BONE_MEAL, 1));
        if (!leftover.isEmpty()) return 0; // hopper full — try again next cycle, item stays untouched

        level.setLevel(0);
        composterBlock.setBlockData(level);

        bonemealCollected.incrementAndGet();
        trackSpecialBlock(composterBlock.getLocation());
        if (logTransfersCached) {
            plugin.getLogger().info("[MauaHopper] Đã thu bonemeal từ composter tại "
                    + formatLoc(composterBlock.getLocation()));
        }
        return 1;
    }

    // =========================================================================
    // Cauldron logic (extension beyond vanilla hopper behavior — mirrors how a
    // dispenser fills/empties a cauldron with a bucket; hoppers normally can't)
    // =========================================================================

    private static final Map<Material, Material> CAULDRON_FILL_BUCKETS = Map.of(
            Material.WATER_BUCKET, Material.WATER_CAULDRON,
            Material.LAVA_BUCKET, Material.LAVA_CAULDRON,
            Material.POWDER_SNOW_BUCKET, Material.POWDER_SNOW_CAULDRON
    );

    private static final Map<Material, Material> CAULDRON_DRAIN_BUCKETS = Map.of(
            Material.WATER_CAULDRON, Material.WATER_BUCKET,
            Material.LAVA_CAULDRON, Material.LAVA_BUCKET,
            Material.POWDER_SNOW_CAULDRON, Material.POWDER_SNOW_BUCKET
    );

    private boolean isCauldronBlock(Material type) {
        return type == Material.CAULDRON || type == Material.WATER_CAULDRON
                || type == Material.LAVA_CAULDRON || type == Material.POWDER_SNOW_CAULDRON;
    }

    private int occupiedSlots(Inventory inv) {
        int n = 0;
        for (ItemStack it : inv) if (it != null && it.getType() != Material.AIR) n++;
        return n;
    }

    /** Hopper above an EMPTY cauldron pours a bucket into it, like a dispenser would. */
    private int pushItemsToCauldron(Inventory hopperInv, Block cauldronBlock, ConfigManager cfg) {
        // Vanilla dispensers can't top up or mix liquids either — only an empty cauldron accepts a bucket.
        if (cauldronBlock.getType() != Material.CAULDRON) return 0;

        int maxFeeds = cfg.cauldronMaxFeedsPerTick;
        int fed = 0;

        for (int i = 0; i < hopperInv.getSize() && fed < maxFeeds; i++) {
            ItemStack item = hopperInv.getItem(i);
            if (item == null || item.getType() == Material.AIR) continue;

            Material fillResult = CAULDRON_FILL_BUCKETS.get(item.getType());
            if (fillResult == null) continue;

            // GREEN FIX: 1-slot inventory van dung duoc bang cach thay bucket tai
            // cho thay vi can tim them 1 slot trong truoc.
            if (item.getAmount() == 1 && occupiedSlots(hopperInv) == 1) {
                hopperInv.setItem(i, new ItemStack(Material.BUCKET, 1));
            } else {
                Map<Integer, ItemStack> leftover = hopperInv.addItem(new ItemStack(Material.BUCKET, 1));
                if (!leftover.isEmpty()) continue; // no room — skip, nothing consumed, no item loss
                consumeOneFromSlot(hopperInv, i, item);
            }

            cauldronBlock.setType(fillResult);
            if (fillResult != Material.LAVA_CAULDRON) { // lava cauldrons have no level — always just "full"
                BlockData data = cauldronBlock.getBlockData();
                if (data instanceof Levelled level) {
                    level.setLevel(level.getMaximumLevel()); // a bucket always fills to max, unlike bottles
                    cauldronBlock.setBlockData(level);
                }
            }

            fed++;
            break; // one bucket action per cycle, like a dispenser firing once
        }

        if (fed > 0) {
            cauldronFills.incrementAndGet();
            trackSpecialBlock(cauldronBlock.getLocation());
            if (logTransfersCached) {
                plugin.getLogger().info("[MauaHopper] Đã đổ đầy vạc tại " + formatLoc(cauldronBlock.getLocation())
                        + " -> " + cauldronBlock.getType());
            }
        }
        return fed;
    }

    /** Hopper below a FULL cauldron scoops it out with an empty bucket, like a dispenser would. */
    private int pullFromCauldron(Inventory hopperInv, Block cauldronBlock, ConfigManager cfg) {
        Material filledBucket = CAULDRON_DRAIN_BUCKETS.get(cauldronBlock.getType());
        if (filledBucket == null) return 0; // empty cauldron — nothing to take

        int maxFeeds = cfg.cauldronMaxFeedsPerTick;
        int pulled = 0;

        for (int i = 0; i < hopperInv.getSize() && pulled < maxFeeds; i++) {
            ItemStack item = hopperInv.getItem(i);
            if (item == null || item.getType() != Material.BUCKET) continue;

            // GREEN FIX: 1-slot bucket-only inventory thay bucket tai cho.
            if (item.getAmount() == 1 && occupiedSlots(hopperInv) == 1) {
                hopperInv.setItem(i, new ItemStack(filledBucket, 1));
            } else {
                Map<Integer, ItemStack> leftover = hopperInv.addItem(new ItemStack(filledBucket, 1));
                if (!leftover.isEmpty()) continue; // no room for the filled bucket — try again next cycle
                consumeOneFromSlot(hopperInv, i, item);
            }

            cauldronBlock.setType(Material.CAULDRON); // a bucket always fully empties it, regardless of level

            pulled++;
            break;
        }

        if (pulled > 0) {
            cauldronDrains.incrementAndGet();
            trackSpecialBlock(cauldronBlock.getLocation());
            if (logTransfersCached) {
                plugin.getLogger().info("[MauaHopper] Đã hút cạn vạc tại " + formatLoc(cauldronBlock.getLocation()));
            }
        }
        return pulled;
    }

    private String formatLoc(Location loc) {
        return loc.getWorld().getName() + " " + loc.getBlockX() + "," + loc.getBlockY() + "," + loc.getBlockZ();
    }

    // =========================================================================
    // Crafter logic
    // =========================================================================

    private int pushItemsToCrafter(Inventory hopper, org.bukkit.block.Crafter crafter,
                                    ConfigManager cfg, Location loc, int maxFeeds, int itemsPerSlot) {
        Inventory crafterInv = crafter.getInventory();
        int fed = 0;
        int movedItems = 0;

        for (int i = 0; i < hopper.getSize() && fed < maxFeeds; i++) {
            ItemStack item = hopper.getItem(i);
            if (item == null || item.getType() == Material.AIR) continue;

            int itemReal = stackRealAmount(item);
            if (itemReal <= 0) {
                // PATCH v17: repair ledger hong thay vi xoa item.
                setStackRealAmount(item, item.getAmount());
                hopper.setItem(i, item);
                continue;
            }

            for (int ci = 0; ci < crafterInv.getSize() && fed < maxFeeds; ci++) {
                if (crafter.isSlotDisabled(ci)) continue;
                ItemStack slot = crafterInv.getItem(ci);
                if (slot != null && slot.getType() != Material.AIR) continue;

                int give = Math.min(itemsPerSlot,
                        Math.min(itemReal, item.getMaxStackSize()));
                crafterInv.setItem(ci, cleanMovedStack(item, give));
                int remaining = itemReal - give;
                setStackRealAmount(item, remaining);
                movedItems += give; // GREEN FIX: tra ve so item, khong phai so slot
                fed++;
                itemReal = remaining;
                if (itemReal <= 0) {
                    hopper.setItem(i, null);
                    break;
                }
                hopper.setItem(i, item);
            }
        }
        if (fed > 0) trackSpecialBlock(crafter.getLocation());
        return movedItems;
    }

    private int pullFromCrafter(Inventory hopper, org.bukkit.block.Crafter crafter, ConfigManager cfg) {
        Inventory crafterInv = crafter.getInventory();
        int pulled = 0;
        for (int i = 0; i < crafterInv.getSize() && pulled < cfg.crafterPullAmount; i++) {
            ItemStack item = crafterInv.getItem(i);
            if (item == null || item.getType() == Material.AIR) continue;

            // v4.06: không mang PDC từ crafter sang hopper; trừ source theo ledger thật.
            int itemReal = stackRealAmount(item);
            ItemStack clean = cleanMovedStack(item, item.getAmount());
            int original = clean.getAmount();
            Map<Integer, ItemStack> leftover = hopper.addItem(clean);
            int added = original;
            if (!leftover.isEmpty()) {
                added = original - leftoverSum(leftover);
            }
            if (added <= 0) continue;
            int remaining = itemReal - added;
            setStackRealAmount(item, remaining);
            if (remaining <= 0) crafterInv.setItem(i, null);
            else crafterInv.setItem(i, item);
            pulled += added;
        }
        if (pulled > 0) trackSpecialBlock(crafter.getLocation());
        return pulled;
    }

    private org.bukkit.block.Crafter getCrafterFacingHopper(org.bukkit.block.Hopper hopper) {
        Block hopperBlock = hopper.getBlock();
        Block above = hopperBlock.getRelative(BlockFace.UP);
        if (above.getType() != Material.CRAFTER) return null;
        BlockState state = above.getState(false);
        if (!(state instanceof org.bukkit.block.Crafter crafter)) return null;
        // Check facing
        // p3f: qua facingOf - phong Crafter blockdata mat Directional.
        BlockFace facing = facingOf(above.getBlockData());
        if (facing == BlockFace.DOWN) return crafter;
        return null;
    }

    // =========================================================================
    // Ground item pickup
    // =========================================================================

    // ==== PATCH batch7: DIRECT SUCTION ====
    // Duong hut MOI khong phu thuoc spawn event / chunkHasItems hint /
    // cooldown / stagger / rate-limit. Moi tick quet TRUC TIEP item quanh
    // mat moi hopper da dang ky va nhet vao bang pickupItemEntityIntoHopper
    // (xuli PDC stack + addItem + leftover day du). Bao dam pickup hoat dong
    // du bat ky duong cu co van de o moi truong nao. Ban kinh doc theo
    // pickup.radius_horizontal/vertical - voi 1.5/0.75 phu kin mat tren
    // hopper + 0.5 block mo phia (hut rong hon vanilla, "xịn" nhu yeu cau).
    /** batch7: quet + nhet item trong 1 vung box quanh diem cho truoc. */
    private void suckItemsAround(World world, double cx, double cy, double cz,
                                 double r, double rv, org.bukkit.block.Hopper hopper, ConfigManager cfg) {
        for (Entity entity : world.getNearbyEntities(new Location(world, cx, cy, cz), r, rv, r, en -> en instanceof Item)) {
            if (!entity.isValid() || entity.isDead()) continue;
            Item item = (Item) entity;
            ItemStack stack = item.getItemStack();
            if (stack == null || stack.getType().isAir()) continue;
            if (cfg.blacklistedMaterialsForPickup.contains(stack.getType())) continue;
            if (cfg.pickupRespectDelay && item.getPickupDelay() > 0) continue;
            pickupItemEntityIntoHopper(item, hopper, cfg);
            if (isInventoryFull(hopper.getInventory())) return;
        }
    }

    private void directSuctionPass() {
        ConfigManager cfg = plugin.getConfigManager();
        if (!cfg.pickupEnabled || !cfg.directSuction) return;
        // Cho phep config nho toi vanila nguyen ban (mat 1x1) - floor chi
        // la chan an toan tren 0, khong ep rong nhu truoc.
        double r = Math.max(cfg.pickupRadiusHorizontal, 0.0);
        double rv = Math.max(cfg.pickupRadiusVertical, 0.0);
        // PATCH v28p7-batch6-d1 (loi #1 - CRITICAL TPS): truoc day duyet TOAN
        // BO hopper moi pickupIntervalTicks (mac dinh 1 = MOI TICK), moi hopper
        // toi 2 lan getNearbyEntities - bypass tat ca guard cua engine (work
        // queue, adaptive budget, chunkActive gate, xoay vong). Server 2000
        // hopper = 2000-4000 AABB query/tick. Bay gio: snapshot 500ms + xoay
        // vong + chunkActive gate + gioi han theo max_hoppers_per_tick nhu
        // processHopperTransfers.
        long nowMs = System.currentTimeMillis();
        int maxPerTick = resolveMaxHoppersPerTick(cfg);
        int processed = 0;
        if (suctionEntriesSnapshot == null || nowMs - lastSuctionEntrySnapshotMs > 500) {
            lastSuctionEntrySnapshotMs = nowMs;
            suctionEntriesSnapshot = new java.util.ArrayList<>(chunkHoppers.entrySet());
        }
        int entryCount = suctionEntriesSnapshot.size();
        if (entryCount == 0) return;
        int entryStart = suctionRotateOffset % entryCount;
        suctionRotateOffset = (suctionRotateOffset + Math.max(1, maxPerTick)) % entryCount;

        for (int ei = 0; ei < entryCount && (processed < maxPerTick || maxPerTick <= 0); ei++) {
            Map.Entry<String, Set<Location>> entry = suctionEntriesSnapshot.get((entryStart + ei) % entryCount);
            for (Location loc : entry.getValue()) {
                if (processed >= maxPerTick && maxPerTick > 0) break;
                World world = loc.getWorld();
                if (world == null) continue;
                // chunkActive gate giong pickup sweep - khong quet chunk
                // nguoi choi khong toi (radius<=0 -> true, khong doi han).
                if (!isChunkActive(loc, cfg, nowMs)) continue;
                Block block = loc.getBlock();
                if (block.getType() != Material.HOPPER) continue;
                BlockState state = block.getState(false);
                if (!(state instanceof org.bukkit.block.Hopper hopper)) continue;
                if (isInventoryFull(hopper.getInventory())) continue;
                double cx = loc.getX() + 0.5, cz = loc.getZ() + 0.5;
                // zone 1: mat tren hopper (dung nhu cu)
                suckItemsAround(world, cx, loc.getY() + 1.0, cz, r, rv, hopper, cfg);
                if (isInventoryFull(hopper.getInventory())) { processed++; continue; }
                // zone 2 (batch7b): mat dat xung quanh chan hopper - magnet.
                // Tat neu so no hut nham do o farm co dong nuoc/ke chua qua.
                if (cfg.pickupSuckGround) {
                    // FIX: hopper thuong nam TREN chest/dong co - mat dat
                    // xung quanh thap hon day hopper ~1 block. Vung quet
                    // phai trum tu san (y-1) toi tren mat (y+2).
                    suckItemsAround(world, cx, loc.getY() + 0.5, cz, r, 1.5, hopper, cfg);
                }
                processed++;
            }
        }
    }

    private void runFastPickupPass() {
        ConfigManager cfg = plugin.getConfigManager();
        // v4.04: don UUID khoa cua entity da mat - tranh leak Set theo thoi gian.
        // FIX TPS 2026-09-28: cleanup sparse - 1 lan/20 tick, toi da 40 lookup
        // Bukkit.getEntity (truoc day CHAY MOI TICK voi toi 200 lookup/tick).
        // lockedItems la CHM key set - KHONG dung iterator().remove(), go
        // truc tiep qua Set.remove (an toan tren ConcurrentHashMap).
        if ((++lockedItemsCleanupCounter % 20) == 0 && lockedItems.size() > 200) {
            int checked = 0;
            java.util.Iterator<UUID> it = lockedItems.iterator();
            while (it.hasNext() && checked < 40) {
                checked++;
                UUID u = it.next();
                Entity en = Bukkit.getEntity(u);
                if (en == null || en.isDead() || !en.isValid()) lockedItems.remove(u);
            }
        }

        // FIX TPS 2026-09-28: stagger quet theo chunk - moi luot chi quet
        // 1/stagger so chunk (xoay vong), moi chunk van duoc quet du moi
        // `stagger` tick. Giam so AABB query/tick xuong gap `stagger` lan.
        int stagger = Math.max(1, cfg.pickupScanStaggerTicks);
        // PATCH v28p7-batch5 (loi #1): purge FALSE dinh ky 5 giay - xem
        // comment o khai bao chunkHasItemsPurgeAt.
        long nowPurgeMs = System.currentTimeMillis();
        if (nowPurgeMs >= chunkHasItemsPurgeAt) {
            chunkHasItems.clear();
            chunkHasItemsPurgeAt = nowPurgeMs + 5000L;
        }
        int chunkIdx = 0;
        for (Set<Location> locs : chunkHoppers.values()) {
            if (stagger > 1 && ((chunkIdx++ + pickupScanRotate) % stagger) != 0) continue;
            // v4.04 FIX: cac gate o MUC CHUNK (world/active/hasItems/cooldown)
            // chi ap dung 1 lan - truoc day cooldown 10 tick duoc dat theo ket
            // qua quet cua HOPPER DAU TIEN, item tren cac hopper khac cung
            // chunk bi tre nhac vo co.
            Location any = null;
            for (Location loc : locs) { any = loc; break; }
            if (any == null) continue;
            if (!plugin.getWorldManager().isWorldAllowed(any.getWorld())) continue;
            long chunkKey = packChunkKey(any);
            // v67: bo qua chunk khong co nguoi choi gan
            if (!isChunkActive(any, plugin.getConfigManager(), System.currentTimeMillis())) continue;
            // v4.04p FIX: check item o ca 3x3 chunk lang gieng - truoc day
            // chi check chunk cua hopper, item roi sat RIA chunk (van trong
            // tam hut 1 block) bi bo sot nam mai tren dat (DonutHopper goc
            // dung chunkOrNeighborHasItems). Chi phi: 9 lookup thay vi 1.
            boolean hasAnyNearby = false;
            // PATCH 2026-09-29 (batch 3, loi #8): truoc day build string
            // "world:x:z" (chunkKey) roi parse lastIndexOf/substring/parseInt
            // de lay lai dung world/cx/cz vua nhet vao. Tinh truc tiep tu
            // Location bang packed-long - 0 string alloc them, khong can
            // nhanh catch fallback.
            {
                long wBits = worldBits(any.getWorld().getName()) << 42;
                int bcx = any.getBlockX() >> 4, bcz = any.getBlockZ() >> 4;
                for (int dx = -1; dx <= 1 && !hasAnyNearby; dx++) {
                    for (int dz = -1; dz <= 1 && !hasAnyNearby; dz++) {
                        long nKey = wBits | ((((long) bcx + dx) & 0x1FFFFFL) << 21)
                                | (((long) bcz + dz) & 0x1FFFFFL);
                        if (!Boolean.FALSE.equals(chunkHasItems.get(nKey))) hasAnyNearby = true;
                    }
                }
            }
            if (!hasAnyNearby) continue;
            // v67.7: chunk dang trong thoi gian nghi sau lan quet sach.
            // PATCH v28p3 (loi #12): chi CHECK, khong giam tai cho - viec
            // giam do decrementAllCooldowns dam nhiem (giong hopperFullIdle).
            if (chunkPickupCooldowns.containsKey(chunkKey)) continue;
            // ===== v4.06 PERF: batch pickup theo CHUNK - 1 entity query
            // cho ca chunk thay vi tung hopper. 10000 hopper ~ 625 chunk =
            // giam ~16 lan chi phi quet. Chi ap dung khi chunk co nhieu
            // hopper (nguong 4) de tranh overhead hop nho.
            boolean found = false;
            if (locs.size() >= 4) {
                double minX = Double.MAX_VALUE, minY = Double.MAX_VALUE, minZ = Double.MAX_VALUE;
                double maxX = -Double.MAX_VALUE, maxY = -Double.MAX_VALUE, maxZ = -Double.MAX_VALUE;
                for (Location l : locs) {
                    minX = Math.min(minX, l.getX()); maxX = Math.max(maxX, l.getX() + 1);
                    minY = Math.min(minY, l.getY()); maxY = Math.max(maxY, l.getY() + 2);
                    minZ = Math.min(minZ, l.getZ()); maxZ = Math.max(maxZ, l.getZ() + 1);
                }
                if (!cfg.pickupSurfaceOnly) {
                    // PATCH 2026-09-28 (loi #12): XZ inflate theo ban kinh
                    // NGANG, Y theo ban kinh DOC - truoc day Y bi phong theo
                    // max(ngang, doc) keo vung query khong lien quan vao
                    // AABB scan (nhieu entity + alloc hon moi luot).
                    double rXZ = cfg.pickupRadiusHorizontal + 1;
                    double rY = cfg.pickupRadiusVertical + 1;
                    minX -= rXZ; minZ -= rXZ; maxX += rXZ; maxZ += rXZ;
                    // AUDIT FIX 2026-09-28: KHONG inflate minY - hopper chi
                    // nhat item TU TREN xuong, ban goc cung khong co minY.
                    maxY += rY;
                }
                Collection<Entity> chunkItems = any.getWorld().getNearbyEntities(
                        new BoundingBox(minX, minY, minZ, maxX, maxY, maxZ),
                        e -> e instanceof Item);
                // RED FIX: batch path O(hopper × item). Neu workload qua lon,
                // doi sang query hep tung hopper de tranh spike main-thread.
                long workload = (long) locs.size() * (long) chunkItems.size();
                if (workload > 256L) {
                    for (Location loc : locs) {
                        if (runFastPickupForChunk(loc, cfg)) found = true;
                    }
                } else {
                    for (Location loc : locs) {
                        if (runFastPickupForChunk(loc, cfg, chunkItems)) found = true;
                    }
                }
            } else {
                for (Location loc : locs) {
                    if (runFastPickupForChunk(loc, cfg)) found = true;
                }
            }
            if (!found) {
                chunkPickupCooldowns.put(chunkKey, 10);
                // PATCH v28p7-batch5 (loi #1): danh dau chunk trong de
                // 3x3 hint check skip AABB o cac luot sau. TRUE se duoc
                // set lai ngay khi co item spawn vao chunk (ItemSpawnEvent/
                // PlayerDropItem). FALSE tu het hieu luc sau 5s (purge).
                chunkHasItems.put(packChunkKey(any), Boolean.FALSE);
            }
        }
        if (stagger > 1) pickupScanRotate = (pickupScanRotate + 1) % stagger;
    }

    // ===== v4.06: overload nhan san item list da query theo chunk =====
    private boolean runFastPickupForChunk(Location hopperLoc, ConfigManager cfg,
                                          Collection<Entity> chunkItems) {
        Block block = hopperLoc.getBlock();
        if (block.getType() != Material.HOPPER) return false;

        BlockState state = block.getState(false);
        if (!(state instanceof org.bukkit.block.Hopper hopper)) return false;

        Inventory inv = hopper.getInventory();
        if (isInventoryFull(inv)) return false;

        BoundingBox box;
        if (cfg.pickupSurfaceOnly) {
            box = new BoundingBox(
                    hopperLoc.getX(), hopperLoc.getY() + 1, hopperLoc.getZ(),
                    hopperLoc.getX() + 1, hopperLoc.getY() + 2, hopperLoc.getZ() + 1);
        } else {
            double rx = cfg.pickupRadiusHorizontal;
            double ry = cfg.pickupRadiusVertical;
            // PATCH 2026-09-28 (loi #15): clone().add() cap phat Location
            // moi cho moi hopper moi luot pickup. Dung BoundingBox ctor
            // truc tiep tu toa do primitive - 0 alloc.
            double cx = hopperLoc.getX() + 0.5, cy = hopperLoc.getY() + 0.5 + ry, cz = hopperLoc.getZ() + 0.5;
            box = new BoundingBox(cx - rx, cy - ry, cz - rx, cx + rx, cy + ry, cz + rx);
        }

        boolean foundAny = false;
        for (Entity entity : chunkItems) {
            // PATCH 2026-09-28 (loi #3): contains(toVector()) cap phat
            // Location + Vector cho MOI item x MOI hopper moi luot quet.
            // So sanh toa do primitive truc tiep - 0 alloc, cung nghia
            // inclusive cua BoundingBox.contains.
            Location el = entity.getLocation();
            if (el.getX() < box.getMinX() || el.getX() > box.getMaxX()
                    || el.getY() < box.getMinY() || el.getY() > box.getMaxY()
                    || el.getZ() < box.getMinZ() || el.getZ() > box.getMaxZ()) continue;
            Item itemEntity = (Item) entity;
            if (!itemEntity.isValid()) continue;
            if (cfg.pickupRespectDelay && itemEntity.getPickupDelay() > 0) continue;
            if (lockedItems.contains(itemEntity.getUniqueId())) continue;

            // PATCH 2026-09-29 (batch 3, loi #9): check enum Material O(1) -
            // khong con String alloc tu .name() cho moi item moi pass.
            if (cfg.blacklistedMaterialsForPickup.contains(itemEntity.getItemStack().getType())) continue;

            if (cfg.pickupRequireLineOfSight) {
                if (!canReachItemFrom(hopperLoc, itemEntity)) continue;
            }

            // AUDIT FIX S2: chi giu chunk nong khi item thuc su co the pickup.
            foundAny = true;

            if (!tryLockGroundItem(itemEntity)) continue;
            try {
                pickupItemEntityIntoHopper(itemEntity, hopper, cfg);
            } finally {
                unlockGroundItem(itemEntity);
            }
        }
        return foundAny;
    }

    private boolean runFastPickupForChunk(Location hopperLoc, ConfigManager cfg) {
        Block block = hopperLoc.getBlock();
        if (block.getType() != Material.HOPPER) return false;

        BlockState state = block.getState(false);
        if (!(state instanceof org.bukkit.block.Hopper hopper)) return false;

        Inventory inv = hopper.getInventory();
        if (isInventoryFull(inv)) return false;

        // Pickup zone - v67.35: mac dinh CHI hut item dung TREN MAT hopper
        // (dung chuan vanilla, hopper khong hut do ben canh). Dat
        // pickup.surface-only: false de dung lai ban kinh pickup_radius.
        BoundingBox box;
        if (cfg.pickupSurfaceOnly) {
            // v67.77: box Y CHANG VANILLA - DUNG chinh xac khoi phia tren
            // hopper (x..x+1, y+1..y+2, z..z+1), KHONG inflate. Do vanilla
            // (HopperBlockEntity.SUCK) chi quet block-space tren hopper -
            // do ben canh/ep sat hong KHONG bi hut. v67.37 tung inflate 0.5
            // la LECH vanilla theo yeu cau "y chang vanilla" cua chu server.
            box = new BoundingBox(
                    hopperLoc.getX(), hopperLoc.getY() + 1, hopperLoc.getZ(),
                    hopperLoc.getX() + 1, hopperLoc.getY() + 2, hopperLoc.getZ() + 1);
        } else {
            double rx = cfg.pickupRadiusHorizontal;
            double ry = cfg.pickupRadiusVertical;
            // PATCH 2026-09-28 (loi #15): clone().add() cap phat Location
            // moi cho moi hopper moi luot pickup. Dung BoundingBox ctor
            // truc tiep tu toa do primitive - 0 alloc.
            double cx = hopperLoc.getX() + 0.5, cy = hopperLoc.getY() + 0.5 + ry, cz = hopperLoc.getZ() + 0.5;
            box = new BoundingBox(cx - rx, cy - ry, cz - rx, cx + rx, cy + ry, cz + rx);
        }

        Collection<Entity> nearby = hopperLoc.getWorld()
                .getNearbyEntities(box, e -> e instanceof Item);

        boolean foundAny = false;
        for (Entity entity : nearby) {
            Item itemEntity = (Item) entity;
            if (!itemEntity.isValid()) continue;
            // v67.27: mac dinh KHONG check pickupDelay (dung vanilla: nem vao la
        // hopper hut ngay). Do nem tay co delay 40 tick, trong 2s do do chay
        // nuoc troi mat. Bat respect_pickup_delay neu muon choi co kieu kho.
        if (cfg.pickupRespectDelay && itemEntity.getPickupDelay() > 0) continue;
            if (lockedItems.contains(itemEntity.getUniqueId())) continue;
            // Blacklist check
            // PATCH 2026-09-29 (batch 3, loi #9): check enum Material O(1) -
            // khong con String alloc tu .name() cho moi item moi pass.
            if (cfg.blacklistedMaterialsForPickup.contains(itemEntity.getItemStack().getType())) continue;

            if (cfg.pickupRequireLineOfSight) {
                if (!canReachItemFrom(hopperLoc, itemEntity)) continue;
            }

            // PATCH v28p7-batch5-P2 (loi #8): foundAny dat SAU blacklist +
            // line-of-sight cho KHOP voi duong batch (truoc day dat truoc
            // blacklist -> chunk chi chua item bi blacklist khong bao gio
            // vao cooldown 10 tick, sweep chay vo ich moi pickup pass).
            // AUDIT FIX B3: overload don le phai dat foundAny, neu khong chunk
            // <4 hopper bi cooldown vo co du co item hop le trong vung.
            foundAny = true;

            if (!tryLockGroundItem(itemEntity)) continue;

            try {
                pickupItemEntityIntoHopper(itemEntity, hopper, cfg);
            } finally {
                unlockGroundItem(itemEntity);
            }
        }
        return foundAny;
    }

    private boolean canReachItemFrom(Location hopperLoc, Item item) {
        Location itemLoc = item.getLocation();
        // PATCH 2026-09-28 (loi #33): item trung TAM block hopper -> vector
        // zero -> normalize() ra NaN -> rayTraceBlocks nhan direction NaN
        // (throw hoac ket qua vo nghia). dist == 0 = khong gi che giua ->
        // coi nhu nhin thay.
        if (hopperLoc.equals(itemLoc)) return true;
        Vector dir = itemLoc.toVector().subtract(hopperLoc.toVector()).normalize();
        double dist = hopperLoc.distance(itemLoc);
        var result = hopperLoc.getWorld().rayTraceBlocks(
                hopperLoc.clone().add(0.5, 0.5, 0.5), dir, dist,
                FluidCollisionMode.NEVER, false);
        return result == null || result.getHitBlock() == null;
    }

    private void pickupItemEntityIntoHopper(Item itemEntity, org.bukkit.block.Hopper hopper, ConfigManager cfg) {
        // ItemStackingManager nội bộ: đọc số lượng THẬT từ PDC (item gộp
        // nhiều stack thành 1 - bề mặt chỉ 64, PDC stack_amount mới là tổng).
        // Nhặt ĐỦ số thật vào hopper, cập nhật PDC khi còn dư - không mất đồ.
        Integer polyTotal = getStackTotal(itemEntity);
        // Chỉ strip tên hiển thị stack khi item ĐÃ gộp - item thường (kể cả
        // đặt tên bằng đe) phải giữ nguyên tên.
        ItemStack stack = polyTotal != null
                ? stripStackDisplayName(itemEntity.getItemStack())
                : itemEntity.getItemStack().clone();
        if (polyTotal != null) {
            stack.setAmount(polyTotal);
        }
        int original = stack.getAmount();
        Inventory inv = hopper.getInventory();
        Map<Integer, ItemStack> leftover = inv.addItem(stack);
        // addItem MUTATE stack - tính số thực nhận bằng hiệu, không dựa vào object
        int added = original - (leftover.isEmpty() ? 0 : leftoverSum(leftover));
        if (added <= 0) return; // hopper đầy, không đụng entity
        // v4.04r: sweep nhặt được đồ cho hopper đang ngủ → đánh thức ngay
        // (dispenser bắn đồ rơi xuống hopper là đường phổ biến của farm).
        wakeHopper(hopper.getLocation());
        int remaining = original - added;
        if (remaining <= 0) {
            // setStackAmount(0) = removeHologram + remove, dọn hologram ngay
            setStackTotal(itemEntity, 0);
        } else {
            // Còn dư: trả phần thừa lại cho entity - cập nhật CẢ surface
            // (tối đa 64) lẫn PDC (tổng thật còn lại). Task hiển thị của
            // ItemStackingManager sẽ tự cập nhật theo PDC.
            ItemStack surface = itemEntity.getItemStack().clone();
            surface.setAmount(Math.min(remaining, 64));
            itemEntity.setItemStack(surface);
            if (polyTotal != null) {
                setStackTotal(itemEntity, remaining);
            }
        }
        plugin.getPerformanceOptimizer().recordHopperItemsMoved(added);
    }

    private boolean tryLockGroundItem(Item item) {
        return lockedItems.add(item.getUniqueId());
    }

    private void unlockGroundItem(Item item) {
        lockedItems.remove(item.getUniqueId());
    }

    // =========================================================================
    // Minecart hoppers
    // =========================================================================

    // v66.5: dang ky minecart NGAY khi spawn (gần như free) -> scan dinh ky
    // chi con vai tro safety net, khong con quet full-world entity thuong xuyen.
    @EventHandler(ignoreCancelled = true)
    public void onMinecartSpawn(org.bukkit.event.vehicle.VehicleCreateEvent e) {
        if (!plugin.isActive()) return; // v67.8
        if (!plugin.getConfigManager().minecartHopperEnabled) return;
        if (!(e.getVehicle() instanceof HopperMinecart cart)) return;
        if (!plugin.getWorldManager().isWorldAllowed(cart.getWorld())) return;
        cartAdd(cart);
    }

    // ==================== PERF (2026-09-27): minecart cache EVENT-DRIVEN ====================
    // Truoc day cachedMinecarts rebuild = quet TAT CA world x chunk x entity
    // moi minecartScanInterval tick (mac dinh 100 = 5 giay) -> spike tren
    // server nhieu chunk. Bay gio cache duoc GIU TUOI bang 4 event nay;
    // scan toan bo trong processHopperMinecarts chi con la safety net rat
    // thua (toi thieu 5 phut) + 1 lan seed luc khoi dong.

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onMinecartEntitiesLoad(org.bukkit.event.world.EntitiesLoadEvent e) {
        for (Entity en : e.getEntities()) {
            if (en instanceof HopperMinecart hm) cartAdd(hm);
        }
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onMinecartEntitiesUnload(org.bukkit.event.world.EntitiesUnloadEvent e) {
        for (Entity en : e.getEntities()) {
            if (en instanceof HopperMinecart hm) {
                cartRemove(hm);
                cartCachePurge(hm); // PATCH 2026-09-29 (batch 3, loi #11)
            }
        }
    }


    @EventHandler(priority = EventPriority.MONITOR)
    public void onMinecartVehicleDestroy(org.bukkit.event.vehicle.VehicleDestroyEvent e) {
        if (e.getVehicle() instanceof HopperMinecart hm) {
            cartRemove(hm);
            cartCachePurge(hm); // PATCH 2026-09-29 (batch 3, loi #11)
        }
    }

    // PATCH 2026-09-29 (batch 3, loi #11): don 3 slot cua cart khoi
    // vehicleQueryCache ngay khi unload/destroy. Truoc day entry (song toi
    // 60s, giu strong ref entity chet) chi bi age-purge khi map >20k - farm
    // minecart qua lai lam cache churn lien tuc. cartCacheKey xac dinh duy
    // nhat tu UUID nen remove O(1) tung slot, khong can scan keySet.
    private void cartCachePurge(HopperMinecart cart) {
        for (int slot = 0; slot < 3; slot++) vehicleQueryCache.remove(cartCacheKey(cart, slot));
    }

    private void processHopperMinecarts() {
        ConfigManager cfg = plugin.getConfigManager();
        // CAM FIX: config tat hopper minecart thi khong xu ly cart cached.
        if (!cfg.minecartHopperEnabled) return;
        minecartScanCountdown--;
        if (minecartScanCountdown <= 0 && !minecartRescanActive) {
            // PERF (2026-09-27): lan dau (seed) scan day du; cac lan sau la
            // SAFETY NET tu chua su co event bi miss - chu ky toi thieu
            // 30 phut. PATCH v28p3: khong scan het 1 tick nua - bat dau qua
            // trinh tung phan, moi tick nhai 200 chunk (xem duoi).
            minecartScanCountdown = minecartSeeded
                    ? (int) Math.max((long) cfg.minecartScanInterval * 180L, 36000L) // p9: nhan long, tranh int overflow
                    : cfg.minecartScanInterval;
            minecartSeeded = true;
            minecartRescanActive = true;
            rescanWorldIdx = 0;
            rescanChunkIdx = 0;
            minecartRescanResult = new ArrayList<>();
        }
        // PATCH v28p3 (loi #7): nhai 200 chunk/tick cho toi het. Event
        // (EntitiesLoad/Unload/VehicleCreate/Destroy) van giu cache tuoi
        // trong luc scan - ket qua chi swap khi scan xong nen khong mat cart.
        // PATCH v28p7-batch5-P2 (loi #5 - TPS): giam 200 -> 60 chunk/tick.
        // Day chi la SAFETY NET (cache van duoc giu tuoi boi event) - scan
        // cham gap 3.3x khong anh huong chuc nang, nhung cat 70% chi phi
        // getEntities() tren main thread trong giai doan rescan.
        if (minecartRescanActive) {
            int budget = 60;
            List<World> worlds = plugin.getServer().getWorlds();
            while (budget > 0 && rescanWorldIdx < worlds.size()) {
                World world = worlds.get(rescanWorldIdx);
                if (!plugin.getWorldManager().isWorldAllowed(world)) {
                    rescanWorldIdx++;
                    rescanChunkIdx = 0;
                    continue;
                }
                Chunk[] chunks = world.getLoadedChunks();
                while (budget > 0 && rescanChunkIdx < chunks.length) {
                    try {
                        for (Entity entity : chunks[rescanChunkIdx].getEntities()) {
                            if (entity instanceof HopperMinecart hm) {
                                minecartRescanResult.add(hm);
                            }
                        }
                    } catch (Throwable t) {
                        // chunk unload giua luc quet - bo qua, safety-scan sau don
                    }
                    rescanChunkIdx++;
                    budget--;
                }
                if (rescanChunkIdx >= chunks.length) {
                    rescanWorldIdx++;
                    rescanChunkIdx = 0;
                }
            }
            if (rescanWorldIdx >= worlds.size()) {
                // PATCH 2026-09-28 (loi #10): scan tung phan keo dai nhieu
                // tick - cart spawn/xoa bang event trong cua so scan phai
                // GIU LAI. Truoc day swap thay the toan bo bang ket qua scan
                // -> cart spawn sau khi chunk no bi quet MAT khoi cache toi
                // lan scan sau (toi thieu 30 phut).
                java.util.Set<HopperMinecart> scanned = new java.util.LinkedHashSet<>(minecartRescanResult);
                for (HopperMinecart c : cachedMinecartSet) {
                    if (c.isValid() && scanned.add(c)) minecartRescanResult.add(c);
                }
                cachedMinecarts = minecartRescanResult;
                // PATCH 2026-09-28 (loi #1/#2/#19): swap list xong PHAI dong
                // bo lai companion set - khong thi set cu con tro toi cart da
                // chet (leak) va contains sai ket qua cho toi lan swap sau.
                cachedMinecartSet.clear();
                cachedMinecartSet.addAll(minecartRescanResult);
                minecartRescanActive = false;
            }
        }

        int processed = 0;
        int max = cfg.maxMinecartsPerTick > 0 ? cfg.maxMinecartsPerTick : Integer.MAX_VALUE;

        // v67.21: xoay vong - 500 cart / 50 moi tick thi moi con duoc xu ly
        // moi 10 tick, khong con bo doi danh sach cuoi
        int n = cachedMinecarts.size();
        if (n == 0) return;
        // p9 FIX: max co the = Integer.MAX_VALUE (unlimited) -> cong int
        // tran sang am -> modulo am -> ArrayIndexOutOfBounds. Dung long +
        // floorMod.
        int startIdx = Math.floorMod(cartRotateOffset, n);
        cartRotateOffset = (int) Math.floorMod((long) cartRotateOffset + Math.max(1, max), (long) n);
        for (int i = 0; i < n && processed < max; i++) {
            HopperMinecart cart = cachedMinecarts.get((startIdx + i) % n);
            if (!cart.isValid()) continue;
            // v67: bo qua minecart o vung khong co nguoi choi gan
            // PATCH v28p3 (loi #1 - compile): 'loc' chua khai bao o method nay
            // (loc chi ton tai trong processMinecartTransfers) -> dung
            // cart.getLocation(). cfg da lay o dau method, khong goi lai
            // plugin.getConfigManager() cho moi cart.
            // FIX 2026-09-28 (loi #13 - TPS): dung scratch Location chung
            // (Entity#getLocation(Location) fill vao, 0 alloc) thay vi
            // cart.getLocation() alloc moi Location cho moi cart moi tick.
            cart.getLocation(scratchCartLoc);
            if (!isChunkActive(scratchCartLoc, cfg, System.currentTimeMillis())) continue;
            if (!plugin.getWorldManager().isWorldAllowed(cart.getWorld())) continue;
            processMinecartTransfers(cart, cfg);
            processed++;
        }
    }

    private void processMinecartTransfers(HopperMinecart cart, ConfigManager cfg) {
        Location loc = cart.getLocation();
        // v67.93: slow mode cho MINECART - nguoi da /mh toggle gan do thay
        // cart chay dung nhip vanilla (1 item/luot). Truoc day chi hopper
        // block co slow mode, cart van nhanh -> khong nhat quan tinh nang.
        boolean cartSlow = cfg.respectPlayerToggle
                && isSlowChunk(loc, cfg, System.currentTimeMillis());
        int cartAmount = cfg.minecartTransferAmount > 0
                ? cfg.minecartTransferAmount
                : Math.min(64, (int) Math.ceil(cfg.getEffectivePullAmount() * cfg.minecartSpeedMultiplier));
        if (cartSlow) cartAmount = 1;
        cartAmount = Math.min(cartAmount, Math.max(1, cfg.maxItemsPerTick));

        // Pull from block above
        Block above = loc.getBlock().getRelative(BlockFace.UP);
        // v65: block phía trên -> hút NHANH qua DispenserService
        // (trước đây return sớm để vanilla xử lý -> 1 item/8 tick, và còn
        // làm minecart bỏ qua cả phần pickup đồ dưới đất phía dưới).
        // v67.101: minecart hut tu RƯƠNG THUYỀN phia tren - DOC LAP, truoc chuoi
        // if-else. KHONG gate moved (bien do khong ton tai o method nay - :1442);
        // thuyen chiem block tren nen chuoi duoi (block container) khong doi dup.
        // FIX TPS: thuyen chi noi trong AIR/WATER - block tren la container
        // thi khong co thuyen, dung query AABB vo ich moi cart moi luot.
        Material aboveType = above.getType();
        if (aboveType == Material.AIR || aboveType == Material.WATER) {
            for (Entity ent : queryVehiclesCached(
                    new Location(above.getWorld(), above.getX() + 0.5, above.getY() + 0.5, above.getZ() + 0.5), 1.0, 1.0, 1.0,
                    en -> en instanceof org.bukkit.entity.ChestBoat && en.isValid(),
                    cartCacheKey(cart, 0), 4)) {
                if (!ent.isValid()) continue; // cache co the giu entity vua chet
                org.bukkit.inventory.Inventory boatInv =
                        ((org.bukkit.entity.ChestBoat) ent).getInventory();
                if (boatInv.isEmpty()) continue;
                // FIX C1: lock entity inventory.
                if (plugin.getDuplicationProtector().tryLockContainer(boatInv)) {
                    try {
                        transferBatchBetweenInventories(boatInv,
                                cart.getInventory(), cartAmount, cfg,
                                plugin.getDuplicationProtector(), loc, null);
                    } finally {
                        plugin.getDuplicationProtector().unlockContainer(boatInv);
                    }
                }
                break;
            }
        }

        BlockState aboveState = above.getState(false);
        if (aboveState instanceof Container src) {
            // FIX AUDIT 2026-09: phai check ket qua tryLockContainer -
            // truoc day goi bo qua, lock fail van chay transfer roi finally
            // lai go unlock du minh khong giu -> gop nham lock cua transfer
            // dang chay = pha bao ve dong thoi.
            if (plugin.getDuplicationProtector().tryLockContainer(src.getInventory())) {
                try {
                    transferBatchBetweenInventories(
                            src.getInventory(), cart.getInventory(), cartAmount, cfg,
                            plugin.getDuplicationProtector(), loc, null);
                } finally {
                    plugin.getDuplicationProtector().unlockContainer(src.getInventory());
                }
            }
        }

        // Block dưới cart entity = block đỡ rail.
        Block below = loc.getBlock().getRelative(BlockFace.DOWN);
        if (!cart.getInventory().isEmpty()) {
            // v67.101: minecart day xuong RƯƠNG THUYỀN duoi rail
            // FIX TPS: thuyen chi noi trong AIR/WATER.
            Material belowType = below.getType();
            if (belowType == Material.AIR || belowType == Material.WATER)
            for (Entity ent : queryVehiclesCached(
                    new Location(below.getWorld(), below.getX() + 0.5, below.getY() + 0.5, below.getZ() + 0.5), 1.0, 1.0, 1.0,
                    en -> en instanceof org.bukkit.entity.ChestBoat && en.isValid(),
                    cartCacheKey(cart, 1), 4)) {
                if (!ent.isValid()) continue; // cache co the giu entity vua chet
                org.bukkit.inventory.Inventory boatInv =
                        ((org.bukkit.entity.ChestBoat) ent).getInventory();
                if (plugin.getDuplicationProtector().tryLockContainer(boatInv)) {
                    try {
                        transferBatchBetweenInventories(cart.getInventory(),
                                boatInv, cartAmount, cfg,
                                plugin.getDuplicationProtector(), loc, null);
                    } finally {
                        plugin.getDuplicationProtector().unlockContainer(boatInv);
                    }
                }
                break;
            }
            // v67.94: minecart day xuong CONTAINER THUONG duoi rail - truoc
            // day de vanilla xu ly (1 item/8 tick) trong khi moi duong khac
            // cua cart da nhanh -> khong deu. Day nhanh theo cartAmount.
            // (Cart -> hopper VAN de hopper tu hut - duong pull cua hopper,
            // khong can day o day.)
            BlockState belowState = below.getState(false);
            // v4.04 FIX: cart qua lo duoc day nhanh voi dung slot routing
            // (truoc day bi loai tru -> chi vanilla 1 item/8 tick).
            if (belowState instanceof Container destC
                    && !(belowState instanceof org.bukkit.block.Hopper)
                    && !(belowState instanceof org.bukkit.block.BrewingStand)) {
                // v4.09: AbstractFurnace - ca 3 loai lo
                // FIX C1: lock container/furnace phia duoi.
                if (plugin.getDuplicationProtector().tryLockContainer(destC.getInventory())) {
                    try {
                        if (isAnyFurnace(belowState)) {
                            transferToFurnace(cart.getInventory(), (org.bukkit.block.Container) belowState, cfg,
                                    plugin.getDuplicationProtector(), loc, true, 0);
                        } else {
                            transferBatchBetweenInventories(
                                    cart.getInventory(), destC.getInventory(), cartAmount, cfg,
                                    plugin.getDuplicationProtector(), loc, null);
                        }
                    } finally {
                        plugin.getDuplicationProtector().unlockContainer(destC.getInventory());
                    }
                }
            }
        }

        // Pickup ground items nearby
        // FIX TPS: khong AABB scan khi gio hang day - khong cho nao nhan
        // duoc them (merge partial van co cho -> hasSpace check ca 2).
        if (cfg.pickupEnabled && hasSpace(cart.getInventory())) {
            minecartPickupGround(cart, cfg);
        }
    }

    /** FIX TPS: true neu inventory con cho nhan item (slot trong hoac stack
     *  chua day) - tranh AABB pickup scan moi cart khi da day. */
    private static boolean hasSpace(org.bukkit.inventory.Inventory inv) {
        for (ItemStack s : inv.getStorageContents()) {
            if (s == null || s.getType().isAir()) return true;
            if (s.getAmount() < s.getMaxStackSize()) return true;
        }
        return false;
    }

    private void minecartPickupGround(HopperMinecart cart, ConfigManager cfg) {
        double r = cfg.minecartPickupRadius;
        Location loc = cart.getLocation();
        Collection<Entity> nearby = java.util.Arrays.asList(queryVehiclesCached(
                loc, r, r, r, e -> e instanceof Item, cartCacheKey(cart, 2), 4));
        int handled = 0;
        for (Entity e : nearby) {
            // AUDIT FIX P6: gioi han workload moi cart, tranh O(cart x item) spike.
            if (++handled > 16) break;
            Item item = (Item) e;
            // v67.27: tuong tu - minecart cung hut ngay nhu vanilla
            if (!item.isValid() || (cfg.pickupRespectDelay && item.getPickupDelay() > 0)) continue;
            if (!tryLockGroundItem(item)) continue;
            try {
                // Đọc số thật từ PDC (item gộp) - không thì chỉ nhặt 64 bề mặt
                // và phần gộp biến mất. Strip visual cho đồ vào minecart sạch.
                Integer stackTotal = null;
                try {
                    var mgr = plugin.getItemStackingManager();
                    if (mgr != null) stackTotal = mgr.getStackAmount(item);
                } catch (Exception ex) {
                    MauaHopper.fineSafe("Safe catch in HopperTicker", ex);
                }
                ItemStack picking = stackTotal != null
                        ? stripStackDisplayName(item.getItemStack())
                        : item.getItemStack().clone();
                if (stackTotal != null) picking.setAmount(stackTotal);
                int original = picking.getAmount();

                Map<Integer, ItemStack> leftover = cart.getInventory().addItem(picking);
                int added = original - (leftover.isEmpty() ? 0 : leftoverSum(leftover));
                if (added <= 0) continue;
                int remaining = original - added;
                if (remaining <= 0) {
                    setStackTotal(item, 0); // removeHologram + remove
                } else {
                    if (stackTotal != null) {
                        setStackTotal(item, remaining);
                    } else {
                        // FIX v4.04.1: leftover.get(0) co the null du leftover
                        // khac rong (key la slot index, phan thua co the o
                        // slot khac) -> phan du bien mat. Dat lai surface
                        // bang phan con lai nhu ban pickupItemEntityIntoHopper.
                        item.setItemStack(cloneAmount(picking, remaining));
                    }
                }
            } finally {
                unlockGroundItem(item);
            }
        }
    }

    // =========================================================================
    // Dropper chains
    // =========================================================================

    // v4.07 PERF: cap dropper giong hopper - quay vong offset tranh
    // starvation. Truoc day KHONG co cap: moi dropper cua moi chunk active
    // chay MOI TICK -> farm dropper lon = TPS drop nang.

    // PATCH 2026-09-28 (loi #27): dem tang/giam tai register/unregister -
    // truoc day tinh total = duyet toan bo chunkDroppers MOI TICK du khong
    // co dropper nao can xu ly (O(so dropper) vo ich moi tick).
    private int dropperTotal = 0;

    private void processDropperChains() {
        ConfigManager cfg = plugin.getConfigManager();
        int budget = cfg.maxDroppersPerTick;
        long nowMs = System.currentTimeMillis();
        int total = dropperTotal;
        if (total <= budget) { dropperRotateOffset = 0; }
        else { dropperRotateOffset %= total; }
        int skipped = 0;
        int processed = 0;
        for (Map.Entry<String, Set<Location>> entry : chunkDroppers.entrySet()) {
            if (processed >= budget) break;
            if (!isChunkActive(entry.getKey(), cfg, nowMs)) { skipped += entry.getValue().size(); continue; }
            for (Location loc : entry.getValue()) {
                if (total > budget) {
                    skipped++;
                    if (skipped <= dropperRotateOffset) continue;
                    if (processed >= budget) break;
                }
                if (dropperCooldowns.containsKey(loc)) continue;
                if (!plugin.getWorldManager().isWorldAllowed(loc.getWorld())) continue;
                if (tickDropperAt(loc, cfg) > 0) {
                    dropperCooldowns.put(loc, cfg.dropperChainTransferTicks);
                }
                processed++;
            }
        }
        if (total > budget) {
            // v28p6 FIX (loi #15): tien offset theo VUNG DA QUET (skipped)
            // thay vi theo so da xu ly - truoc day khi cua so dap vao cum
            // dropper dang cooldown (processed thap) offset chi tien budget,
            // lan quet sau do lai bat dau giua cum cooldown cu -> cum do bi
            // quet lai lien tuc, phan bo xoay vong lech. skipped = so vi tri
            // da di qua (ke ca bi loai) nen cua so luon roi khoi vung vua
            //quet, khong co cum nao bi ganh lai 2 lan lien tiep.
            dropperRotateOffset = (dropperRotateOffset + Math.max(skipped, budget)) % total;
        }
    }

    private int tickDropperAt(Location loc, ConfigManager cfg) {
        Block block = loc.getBlock();
        if (block.getType() != Material.DROPPER) {
            unregisterDropper(loc);
            return 0;
        }
        BlockState state = block.getState(false);
        if (!(state instanceof Dropper dropper)) return 0;

        BlockFace facing = facingOf(block.getBlockData());
        if (facing == null) return 0;

        Block target = block.getRelative(facing);
        BlockState targetState = target.getState(false);
        if (!(targetState instanceof Container dest)) return 0;

        // Guard against face-to-face dropper loops
        if (target.getType() == Material.DROPPER) {
            BlockData targetData = target.getBlockData();
            BlockFace targetFacing = facingOf(targetData);
            if (targetFacing != null && targetFacing == facing.getOppositeFace()) return 0;
        }

        // FIX v43: dropper vào furnace/smoker/blast PHẢI tách fuel/nung như
        // hopper - transferBatch generic sẽ nhét blaze rod vào ô NUNG (slot 0)
        // thay vì ô fuel (vanilla đặt fuel đúng ô). transferToFurnace xử lý
        // đúng qua furnaceSlotOrder (kelp -> nung, blaze rod -> fuel).
        // v4.09: AbstractFurnace - ca 3 loai lo
        if (isAnyFurnace(dest)) {
            // FIX v67.23b: tuong tu - Dropper BlockState khong co getFacing()
            BlockFace dFacing = facingOf(dropper.getBlockData());
            if (dFacing == null) return 0;
            // v28p6 FIX (loi #14): khoa destination nhu duong hopper - dropper
            // truoc day chay tran khong lock, plugin khac hook cung container
            // co the double-transfer. tryLockContainer tra true ngay khi
            // config tat block_concurrent_container_access (khong chi phi).
            if (!plugin.getDuplicationProtector().tryLockContainer(((org.bukkit.block.Container) dest).getInventory()))
                return 0;
            try {
                return transferToFurnace(dropper.getInventory(), (org.bukkit.block.Container) dest, cfg,
                        plugin.getDuplicationProtector(), loc,
                        dFacing == BlockFace.DOWN, 1); // PATCH 2026-09-27 (loi #25): vanilla dropper = 1 item/luot
            } finally {
                plugin.getDuplicationProtector().unlockContainer(((org.bukkit.block.Container) dest).getInventory());
            }
        }

        // v28p6 FIX (loi #14): khoa destination trong tu duong hopper.
        if (!plugin.getDuplicationProtector().tryLockContainer(dest.getInventory())) return 0;
        try {
            return transferBatchBetweenInventories(
                    dropper.getInventory(), dest.getInventory(),
                    1, cfg, plugin.getDuplicationProtector(), loc, null);
        } finally {
            plugin.getDuplicationProtector().unlockContainer(dest.getInventory());
        }
    }

    // =========================================================================
    // Hopper output block resolution
    // =========================================================================

    private Block getHopperOutput(Block hopperBlock, org.bukkit.block.Hopper hopper) {
        BlockFace facing = facingOf(hopperBlock.getBlockData());
        if (facing == null) return null;
        return hopperBlock.getRelative(facing);
    }

    /** PATCH v28p7-batch5-p3f: paper-api 1.21.11 to chuc lai blockdata -
     *  Crafter da MAT interface Directional (bug runtime p3e). Cac block
     *  con lai (hopper/dropper/dispenser) van implement - fast path
     *  instanceof giu NGUYEN hieu nang duong nong; fallback reflection
     *  getFacing() cho phien ban API nao do mat interface sau nay. Tra null
     *  = khong xac dinh duoc huong -> caller bo qua an toan. */
    private static BlockFace facingOf(BlockData data) {
        if (data instanceof Directional d) return d.getFacing();
        try {
            return (BlockFace) data.getClass().getMethod("getFacing").invoke(data);
        } catch (Exception ex) { return null; }
    }

    // =========================================================================
    // Registration
    // =========================================================================

    private void scanAllLoadedHoppers() {
        for (World world : plugin.getServer().getWorlds()) {
            if (!plugin.getWorldManager().isWorldAllowed(world)) continue;
            for (Chunk chunk : world.getLoadedChunks()) {
                registerChunkHoppers(chunk);
            }
        }
    }

    private void registerChunkHoppers(Chunk chunk) {
        String key = chunkKey(chunk);
        int count = 0;
        for (BlockState state : chunk.getTileEntities()) {
            if (state instanceof org.bukkit.block.Hopper) {
                registerHopper(state.getLocation());
                count++;
            }
            if (state instanceof Dropper) {
                ensureDropperRegistered(state.getLocation());
            }
            if (state instanceof org.bukkit.block.Dispenser) {
                ensureDispenserRegistered(state.getLocation());
            }
        }
        if (count > plugin.getConfigManager().maxPerChunk) {
            // FIX: bỏ mã màu '&' - Bukkit logger không translate, console
            // in ra ký tự thô.
            plugin.getLogger().warning("[MauaHopper] This chunk already has the maximum of "
                    + plugin.getConfigManager().maxPerChunk + " hopper!");
        }
    }

    private void registerHopper(Location loc) {
        String key = chunkKey(loc);
        // v4.04 FIX: chi tang counter khi Set thuc su nhan them (truoc day goi
        // 2 lan lam registeredHoppers phong -> cap max_hoppers_per_tick cao hon that).
        if (chunkHoppers.computeIfAbsent(key, k -> ConcurrentHashMap.newKeySet())
                .add(normalizeHopperLocation(loc))) {
            registeredHoppers.incrementAndGet();
            hopperChunks.add(packChunkKey(loc)); // PATCH batch 2 (loi #5) - idempotent
            wakeHopper(loc); // v4.04s: dang ky = co viec → vao queue ngay
        }
    }

    /**
     * Called the first time a hopper actually feeds/drains a composter, cauldron,
     * or crafter. Composters/cauldrons aren't tile entities, so we can't discover
     * them via chunk.getTileEntities() like real hoppers — instead we only learn
     * about one the moment a hopper touches it, which is O(1) and never requires
     * scanning a chunk's blocks. Warns once total (hoppers + special blocks) in
     * that chunk crosses max_per_chunk.
     */
    private void trackSpecialBlock(Location loc) {
        if (!plugin.getConfigManager().countSpecialBlocksInChunkLimit) return;

        String key = chunkKey(loc);
        Set<Location> specials = chunkSpecialBlocks.computeIfAbsent(key, k -> ConcurrentHashMap.newKeySet());
        Location normalized = normalizeHopperLocation(loc);

        if (specials.add(normalized)) { // only warn the first time this block is discovered
            int hopperCount = chunkHoppers.getOrDefault(key, Collections.emptySet()).size();
            int total = hopperCount + specials.size();
            int limit = plugin.getConfigManager().maxPerChunk;
            if (total > limit) {
                plugin.getLogger().warning("[MauaHopper] Chunk at " + key
                        + " hiện có " + total + " khối được cấp item (hopper + composter/vạc/crafter), "
                        + "vượt giới hạn " + limit);
            }
        }
    }

    /** v4.04r: danh thuc hopper dang ngu (idle cooldown/full-idle) khi co
     *  do duoc day vao tu ben ngoai (hopper khac, dropper, sweep).
     *  Dam bao cac kieu may farm khong bi tre them dung nao du hopper tung
     *  bi FIX B danh dau ngu. */
    public void wakeHopper(Location loc) {
        if (loc == null) return;
        hopperCooldowns.remove(loc);
        hopperFullIdle.remove(loc);
        // v4.04s: day vao work queue - diem vao duy nhat cua 1 hopper vao
        // vong xu ly. hotSet DEDUP: 1 hopper chi nam trong queue 1 lan.
        // PATCH v28p7-batch6: work_queue TAT thi khong enqueue nua - tranh
        // leak hotQueue/hotKeys vi luc do khong ai drain (polling loop tu
        // quay khong can duoc danh thuc).
        if (!plugin.getConfigManager().workQueueEnabled) return;
        if (hotKeys.add(packKey(loc))) hotQueue.addLast(loc);
    }

    private void unregisterHopper(Location loc) {
        String key = chunkKey(loc);
        Set<Location> locs = chunkHoppers.get(key);
        // v4.04g FIX: chi giam counter khi Set thuc su co hopper nay - doi
        // xung voi registerHopper. Truoc day break hopper khong register duoc
        // (world cam luc quet, location lech...) van decrement -> counter am
        // dan, sai lieu thong ke max_hoppers_per_tick.
        boolean removed = false;
        if (locs != null) {
            removed = locs.remove(normalizeHopperLocation(loc));
            if (locs.isEmpty()) {
                chunkHoppers.remove(key);
                hopperChunks.remove(packChunkKey(loc)); // PATCH batch 2 (loi #5)
                // v28p6 FIX (loi #3/#13-residual): het hopper trong chunk ->
                // khong con ai danh dau/nhat item tai day -> don 2 map keyed
                // packed-long cho toi khi chunk unload (truoc day song toi
                // luc unload du chunk khong con hopper nao).
                long chunkPk = packChunkKey(loc);
                chunkHasItems.remove(chunkPk);
                inactiveChunkBackoff.remove(chunkPk);
            }
        }
        hopperCooldowns.remove(loc);
        hopperFullIdle.remove(loc);
        hotKeys.remove(packKey(loc)); // v4.04s+v4.08
        if (removed) registeredHoppers.decrementAndGet();
        // AUDIT FIX B4: don pacing maps khi hopper bi go.
        nextContainerPullAt.remove(packKey(loc));
        nextContainerPushAt.remove(packKey(loc));
        // FIX TPS 2026-09-28: don ca cache AABB query cua hopper nay.
        long vpk = packKey(loc);
        vehicleQueryCache.remove(hopperCacheKey(vpk, 0));
        vehicleQueryCache.remove(hopperCacheKey(vpk, 1));
        vehicleQueryCache.remove(hopperCacheKey(vpk, 2));
    }

    private void ensureDropperRegistered(Location loc) {
        String key = chunkKey(loc);
        Set<Location> dropperSet = chunkDroppers.computeIfAbsent(key, k -> ConcurrentHashMap.newKeySet());
        if (dropperSet.add(normalizeHopperLocation(loc))) dropperTotal++;
    }

    private void ensureDispenserRegistered(Location loc) {
        String key = chunkKey(loc);
        chunkDispensers.computeIfAbsent(key, k -> ConcurrentHashMap.newKeySet()).add(normalizeHopperLocation(loc));
    }

    private void unregisterDispenser(Location loc) {
        String key = chunkKey(loc);
        Set<Location> locs = chunkDispensers.get(key);
        if (locs != null) {
            locs.remove(normalizeHopperLocation(loc));
            if (locs.isEmpty()) chunkDispensers.remove(key);
        }
        dispenserCooldowns.remove(loc);
    }

    private void unregisterDropper(Location loc) {
        String key = chunkKey(loc);
        Set<Location> locs = chunkDroppers.get(key);
        if (locs != null) {
            if (locs.remove(normalizeHopperLocation(loc))) dropperTotal--;
            // AUDIT PATCH: don set rong khoi map - tranh map phinh key vo nghia.
            if (locs.isEmpty()) chunkDroppers.remove(key, locs);
        }
        dropperCooldowns.remove(loc);
        // AUDIT FIX B4: don dispenser fast-burst state khi dispenser bi go.
        lastFastDispenserBurstTick.remove(packKey(loc));
    }

    private static Location normalizeHopperLocation(Location loc) {
        return new Location(loc.getWorld(), loc.getBlockX(), loc.getBlockY(), loc.getBlockZ());
    }

    private static String chunkKey(Chunk chunk) {
        return chunk.getWorld().getName() + ":" + chunk.getX() + ":" + chunk.getZ();
    }

    private static String chunkKey(Location loc) {
        return loc.getWorld().getName() + ":" + (loc.getBlockX() >> 4) + ":" + (loc.getBlockZ() >> 4);
    }

    // =========================================================================
    // Event listeners
    // =========================================================================

    /** PATCH v17: enforce max_per_chunk THAT - truoc day config nay chi log
     *  warning. Handler HIGHEST (event chua commit) de cancel duoc; hopper da
     *  ton tai truoc khi co gioi han duoc grandfathered. */
    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onHopperPlaceChunkLimit(BlockPlaceEvent e) {
        if (e.getBlock().getType() != Material.HOPPER) return;
        int limit = plugin.getConfigManager().maxPerChunk;
        if (limit <= 0) return;
        String key = chunkKey(e.getBlock().getLocation());
        int count = chunkHoppers.getOrDefault(key, Collections.emptySet()).size();
        if (plugin.getConfigManager().countSpecialBlocksInChunkLimit) {
            count += chunkSpecialBlocks.getOrDefault(key, Collections.emptySet()).size();
        }
        // Dat thay the len hopper cu: BlockBreakEvent da unregister truoc ->
        // count o day khong tinh block bi thay the.
        if (count >= limit) {
            e.setCancelled(true);
            e.getPlayer().sendMessage("§c[Hopper] Chunk nay da dat toi da " + limit + " hopper!");
        }
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onHopperPlace(BlockPlaceEvent e) {
        if (e.getBlock().getType() == Material.HOPPER) {
            registerHopper(e.getBlock().getLocation());
        }
        if (e.getBlock().getType() == Material.DROPPER) {
            ensureDropperRegistered(e.getBlock().getLocation());
        }
        if (e.getBlock().getType() == Material.DISPENSER) {
            ensureDispenserRegistered(e.getBlock().getLocation());
        }
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onHopperBreak(BlockBreakEvent e) {
        crafterPulseCount.remove(e.getBlock().getLocation());
        // p10: xoa luon 2 map con lai - truoc day de cho purge 10 phut.
        crafterPulseAt.remove(e.getBlock().getLocation());
        crafterRetriggerNextAt.remove(e.getBlock().getLocation());
        if (e.getBlock().getType() == Material.HOPPER) {
            unregisterHopper(e.getBlock().getLocation());
        }
        if (e.getBlock().getType() == Material.DROPPER) {
            unregisterDropper(e.getBlock().getLocation());
        }
        if (e.getBlock().getType() == Material.DISPENSER) {
            unregisterDispenser(e.getBlock().getLocation());
        }
    }

    @EventHandler
    public void onChunkLoad(ChunkLoadEvent e) {
        // p9 FIX: khong dang ky hopper cho world bi cam - truoc day van
        // inflate map/dropper counter cho du runtime co gate.
        if (!plugin.getWorldManager().isWorldAllowed(e.getWorld())) return;
        registerChunkHoppers(e.getChunk());
    }

    @EventHandler
    public void onChunkUnload(ChunkUnloadEvent e) {
        String key = chunkKey(e.getChunk());
        Set<Location> locs = chunkHoppers.remove(key);
        if (locs != null) {
            hopperChunks.remove(parseChunkKeyPacked(key)); // PATCH batch 2 (loi #5)
            locs.forEach(l -> {
                hopperCooldowns.remove(l);
                hopperFullIdle.remove(l);
                // FIX 2026-09-28 (loi #10 - leak): pull/push schedule cua
                // hopper thuoc chunk unload - khong don thi entry Long key
                // song mai trong 2 map (chi sach khi stop()/reload).
                nextContainerPullAt.remove(packKey(l));
                nextContainerPushAt.remove(packKey(l));
            });
            // PATCH 2026-09-28 (loi #13): khong cho counter am - moi lech
            // register nao do (world bi cam sau, reload giua chung) khong
            // duoc keo /mh stats + adaptive budget sai vo thoi han.
            registeredHoppers.updateAndGet(v -> Math.max(0, v - locs.size()));
        }
        // PATCH 2026-09-28 (loi #27): giam bo dem khi chunk unload mang theo
        // toan bo dropper cua no.
        Set<Location> unloadedDroppers = chunkDroppers.remove(key);
        if (unloadedDroppers != null) {
            dropperTotal -= unloadedDroppers.size();
            // FIX 2026-09-28 (loi #10 - leak): entry cooldown cua tung
            // dropper/dispenser trong chunk unload khong bao gio duoc don -
            // chi sach khi reload. Farm o chunk load/unload lien tuc se bom
            // day map theo thoi gian.
            for (Location dl : unloadedDroppers) dropperCooldowns.remove(dl);
        }
        Set<Location> unloadedDispensers = chunkDispensers.remove(key);
        if (unloadedDispensers != null) {
            for (Location dl : unloadedDispensers) dispenserCooldowns.remove(dl);
        }
        chunkHasItems.remove(parseChunkKeyPacked(key));
        chunkPickupCooldowns.remove(parseChunkKeyPacked(key)); // v67.7
        chunkSpecialBlocks.remove(key);
        // AUDIT PATCH: backoff chunk-inactive khong con hopper -> don de tranh leak.
        inactiveChunkBackoff.remove(parseChunkKeyPacked(key));
        // PATCH 2026-09-29 (batch 2, loi #6): chi quet queue khi chunk NAY
        // tung co hopper dang ky. Truoc day moi chunk unload (ke ca chunk
        // khong co hopper) deu chay removeIf tren 64 bucket x toan bo queue
        // = O(queue size), nhan len thanh dot dung dung luc chunk unload
        // hang loat (player bay nhanh). Entry queue stale cua chunk khong
        // hopper se tu drain sau toi da 4096 tick, vo hai.
        if (locs != null) removeQueuedHopperChunk(key);
    }

    private void removeQueuedHopperChunk(String key) {
        // PATCH 2026-09-28 (loi #7): chunkKey(l) cap phat STRING cho TUNG
        // entry cua hotQueue + 64 bucket tickWheel moi lan chunk unload.
        // Parse key 1 lan, so sanh packed long O(1) - 0 alloc.
        long target = parseChunkKeyPacked(key);
        hotQueue.removeIf(l -> {
            if (packChunkKey(l) != target) return false;
            hotKeys.remove(packKey(l));
            return true;
        });
        for (ArrayDeque<Location> q : tickWheel) {
            q.removeIf(l -> {
                if (packChunkKey(l) != target) return false;
                hotKeys.remove(packKey(l));
                return true;
            });
        }
    }

    /** Block vanilla hopper InventoryMoveItemEvent — we handle transfers ourselves. */
    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onInventoryMove(InventoryMoveItemEvent e) {

        // v67.8: plugin dang TAT (global toggle) -> khong cancel vanilla,
        // cho server chay nhu khong co plugin
        if (!plugin.isActive() || !plugin.getConfigManager().hopperEnabled) return; // v67.11: hopper.enabled=false -> vanilla
        // v67.6: world cam -> khong cancel vanilla, de server tu chay
        if (!isInvWorldAllowed(e.getSource()) || !isInvWorldAllowed(e.getDestination())) {
            return;
        }
        // FIX v59: minecart (chest/hopper) TREN RAIL -> hopper block duoi =
        // plugin tu hút nhanh theo config (cancel vanilla 1-item/8-tick).
        // PATCH v28p7-batch6-d1 (loi #21): thieu gate minecart_hopper_enabled -
        // tat config thi vanilla bi chan MA plugin path cung khong xu ly ->
        // minecart tren hopper ngung chuyen hoan toan. Mirror voi gate :3087.
        if (plugin.getConfigManager().minecartHopperEnabled
                && e.getDestination().getHolder() instanceof org.bukkit.block.Hopper
                && e.getSource().getHolder() instanceof org.bukkit.entity.minecart.StorageMinecart) {
            e.setCancelled(true);
            return;
        }
        // FIX A2 (audit 2026-09): vanilla minecart-hopper transfer (cart <->
        // block container) bi entity-gate ben duoi THA cho vanilla chay SONG
        // SONG voi processMinecartTransfers (2x toc do, lech dong bo, kho
        // trace). Plugin da dam nhan du ca 2 huong o processMinecartTransfers
        // (:1816 pull tren, :1868 push duoi) -> cancel phan vanilla.
        // Dieu kien MIRROR dung fast path de khong dong bang duong vanilla
        // dam nhan: push xuong HOPPER (hopper tu hut) va BREWING STAND
        // (fast path loai tru o :1910) VAN de vanilla. Cart <-> entity khac
        // (cart, boat) van roi xuong entity-gate, vanilla xu ly.
        // minecart_hopper_enabled=false -> khong cancel.
        if (plugin.getConfigManager().minecartHopperEnabled
                && e.getInitiator().getHolder() instanceof org.bukkit.entity.minecart.HopperMinecart) {
            boolean blockToCart = e.getSource().getHolder() instanceof BlockState
                    && !(e.getDestination().getHolder() instanceof org.bukkit.entity.Entity);
            boolean cartToBlock = e.getDestination().getHolder() instanceof BlockState
                    && !(e.getSource().getHolder() instanceof org.bukkit.entity.Entity)
                    && !(e.getDestination().getHolder() instanceof org.bukkit.block.Hopper)
                    && !(e.getDestination().getHolder() instanceof org.bukkit.block.BrewingStand);
            if (blockToCart || cartToBlock) {
                e.setCancelled(true);
                return;
            }
        }
        // FIX v46: hopper <-> ENTITY inventory khac (minecart chest, chest boat...) -
        // vanilla bị cancel ở dưới nhưng plugin KHÔNG xử lý được entity inventory
        // (push path chỉ nhận BlockState). Để vanilla xử lý đúng chuẩn.
        if (e.getSource().getHolder() instanceof org.bukkit.entity.Entity
                || e.getDestination().getHolder() instanceof org.bukkit.entity.Entity) {
            return;
        }

        // Block vanilla if our hopper is the initiator
        if (e.getInitiator().getHolder() instanceof org.bukkit.block.Hopper) {
            e.setCancelled(true);
        }
    }


    /** Xoa burst state khi reload config (tranh count cu ket). */
    public void clearBurstState() {
        crafterPulseCount.clear();
        // FIX TPS 2026-09-28: truoc day bo sot 2 map throttle crafter - sau
        // /mh reload timestamp cu van con (tu he thoi, nhung sai ten goi).
        crafterPulseAt.clear();
        crafterRetriggerNextAt.clear();
        // PATCH 2026-09-27 (loi #19): xoa cache smeltable khi reload config
        // de recipe duoc plugin khac dang ky sau nay duoc nhan.
        SMELTABLE_CACHE.clear();
    }

    // =====================================================================
    // AUTO-RETRIGGER CRAFTER (v48/49): tự craft tiếp khi còn nguyên liệu,
    // giới hạn crafts_per_pulse mỗi redstone pulse.
    // =====================================================================

    private final java.util.Map<Location, Integer> crafterPulseCount = new java.util.HashMap<>();
    private final java.util.Map<Long, Integer> lastFastDispenserBurstTick = new java.util.HashMap<>();
    private final java.util.Map<Location, Long> crafterPulseAt = new java.util.HashMap<>();
    // AUDIT FIX P1: cache reflection cho crafter auto-retrigger.
    private static java.lang.reflect.Method CRAFTER_WORLD_GET_HANDLE;
    private static Class<?> CRAFTER_BPOS_CLASS;
    private static java.lang.reflect.Method CRAFTER_BPOS_CONTAINING;
    private static java.lang.reflect.Method CRAFTER_WORLD_GET_BLOCK_ENTITY;
    private static java.lang.reflect.Method CRAFTER_BE_SET_TRIGGERED;
    private static boolean crafterNMSPrimed;
    // FIX 2026-09-28 (loi #5 - TPS): key String "world:x:z" -> packed long.
    private final java.util.Map<Long, Integer> inactiveChunkBackoff = new java.util.HashMap<>();
    private final java.util.Map<Location, Long> crafterRetriggerNextAt = new java.util.HashMap<>();
    private int tickCounter = 0; // v4.04m: dem tick cho purge dinh ky
    // v28p6 FIX (loi #11): dem tick monotonic RIENG cho gate dispenser fast
    // burst (tickCounter bi reset moi 12000 tick khong dung lam gate duoc).
    private int dispenserGateTick = 0;
    // PATCH 2026-09-29 (batch 2, loi #4): dong ho mili-giay MONOTONIC, +50L
    // moi tick ticker chay. Gate pull/push container dung dong ho nay thay vi
    // System.currentTimeMillis(): wall clock van chay dung toc do thuc khi
    // server lag (TPS < 20) trong khi game tick cham lai -> khoang cach
    // pull/push theo game tick thuc te dai gap nhieu lan config, hopper chay
    // cham dung luc server dang nghien nhat. Dong ho dung han khi ticker nghi
    // (inactive/throttle) nen gate khong bao gio troi nguoc.
    private long monotonicMillis = 0L;
    // PATCH 2026-09-29 (batch 3, loi #13): throttle log loi tick (1 lan/phut).
    // Khoi tao -60000 de lan loi dau tien luon duoc in.
    private long lastTickErrorLogMs = -60000L;

    // ===== v4.04s WORK QUEUE ENGINE =====
    // Kien truc hien dai thay the polling: hopper chi ton tai trong vong
    // lap khi CO VIEC THAT (co do moi / het cooldown / moi dang ky). Idle
    // tuyet doi = 0 chi phi - khong phai "scan re" ma la KHONG TON TAI
    // trong vong lap. Timing wheel O(1) thay cho decrement map nghin
    // entry moi tick. Chuan game engine hien dai (event-driven + lazy).
    private final java.util.ArrayDeque<Location> hotQueue = new java.util.ArrayDeque<>();
    // v4.08 PERF: packed-long key thay HashSet<Location> - Bukkit
    // Location.hashCode() goi world.getUID().hashCode() (RAT DAT tren duong
    // nong nhat: moi wakeHopper, moi full refresh deu tinh). Pack thanh long
    // x/y/z + world uid = re hon ~20 lan. Collision vo hai: hopper vao queue
    // 2 lan, double-process da chung minh an toan (fuzz test bao toan).
    private final java.util.Set<Long> hotKeys = new java.util.HashSet<>();

    private static long packKey(Location loc) {
        // FIX v4.04.1: dong 16 bit cu collision mod 65536 (x=0 vs x=65536
        // cung key) -> mot hopper khong bao gio vao queue. Bay gio hash
        // day du 64-bit tu (world UUID, x, y, z) - xac suat collision nhu
        // HashMap thong thuong, khong dang ke.
        long h = loc.getWorld().getUID().getMostSignificantBits()
               ^ loc.getWorld().getUID().getLeastSignificantBits();
        h = h * 0x9E3779B97F4A7C15L + loc.getBlockX();
        h = Long.rotateLeft(h, 31) * 0xC2B2AE3D27D4EB4FL + loc.getBlockY();
        h = Long.rotateLeft(h, 27) * 0x165667B19E3779F9L + loc.getBlockZ();
        return h ^ (h >>> 31);
    }
    // v4.04t RING BUFFER TIMING WHEEL (Linux-kernel style): thay HashMap
    // O(1) thuan - khong hash, khong boxing Long. Kich thuoc luy thua 2
    // de dung bitmask & thay modulo (nhanh hon tren CPU).
    private static final int WHEEL_SIZE = 4096;
    private static final long WHEEL_MASK = WHEEL_SIZE - 1;
    @SuppressWarnings("unchecked")
    private final java.util.ArrayDeque<Location>[] tickWheel = new java.util.ArrayDeque[WHEEL_SIZE];
    private long wheelTick = 0;
    private long lastFullRefreshTick = 0;
    // v4.04t AIMD (TCP congestion control): budget tu dieu chinh theo
    // thoi gian tick THUC - tang dan khi tho, giam phan 2 khi nghhen.
    // Dam bao max throughput ma khong bao gio lam tick vuot nguong.
    private int adaptiveBudget = -1;

    { // instance initializer: khoi tao ring buffer slots
        for (int i = 0; i < WHEEL_SIZE; i++) tickWheel[i] = new java.util.ArrayDeque<>();
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onCrafterCraft(org.bukkit.event.block.CrafterCraftEvent e) {
        if (!plugin.isActive()) return; // v67.8
        ConfigManager cfg = plugin.getConfigManager();
        if (!cfg.crafterEnabled || !cfg.crafterAutoRetrigger) return;
        Block b = e.getBlock();
        if (!plugin.getWorldManager().isWorldAllowed(b.getWorld())) return;
        org.bukkit.Bukkit.getScheduler().runTask(plugin, () -> tryRetriggerCrafter(b));
    }

    private void primeCrafterNMS(org.bukkit.World world) {
        if (crafterNMSPrimed) return;
        crafterNMSPrimed = true;
        try {
            CRAFTER_WORLD_GET_HANDLE = world.getClass().getMethod("getHandle");
            Object worldHandle = CRAFTER_WORLD_GET_HANDLE.invoke(world);
            CRAFTER_BPOS_CLASS = Class.forName("net.minecraft.core.BlockPos");
            CRAFTER_BPOS_CONTAINING = CRAFTER_BPOS_CLASS.getMethod("containing", double.class, double.class, double.class);
            CRAFTER_WORLD_GET_BLOCK_ENTITY = worldHandle.getClass().getMethod("getBlockEntity", CRAFTER_BPOS_CLASS);
        } catch (Exception ex) { MauaHopper.warnSafe("Crafter NMS init failed", ex); }
    }

    private void tryRetriggerCrafter(Block b) {
        try {
            ConfigManager cfg = plugin.getConfigManager();
            BlockState state = b.getState(false);
            if (!(state instanceof org.bukkit.block.Crafter crafter)) return;
            Location loc = b.getLocation();
            // CAM FIX: throttle recipe lookup/reflection theo crafter.
            long nowMs = System.currentTimeMillis();
            if (nowMs < crafterRetriggerNextAt.getOrDefault(loc, 0L)) return;
            // PATCH 2026-09-29 (batch 3, loi #12): dat entry SAU khi qua
            // throttle - truoc day MOI lan craft (ke ca bi throttle return)
            // deu ghi entry, crafterPulseAt phinh trong window 10 phut toi
            // khi purge dinh ky chay. Entry cua crafter dang hoat dong duoc
            // ghi lai o moi pulse nen khong anh huong purge (age check).
            // PATCH v28p7-batch6: 100ms -> 50ms - craft lien tuc MỌI TICK
            // khi co nguyen lieu (nhip Donut). CPU manh (4.3GHz) thoai mai.
            crafterRetriggerNextAt.put(loc, nowMs + 50L);
            crafterPulseAt.put(loc, nowMs); // PATCH batch 3 (loi #12): sau throttle
            // +1 vì craft VỪA XẢY RA (vanilla pulse) cũng tính 1 lần
            int count = crafterPulseCount.getOrDefault(loc, 0) + 1;
            // PATCH v28p7-batch6: crafts_per_pulse <= 0 = KHÔNG GIOI HAN -
            // truoc day burst 8 craft roi DUNG HAN cho xung/redstone tiep
            // (Donut 3.4 khong gioi han - chi dung khi het nguyen lieu hoac
            // dau ra bi chan). Nguong > 0 van dung cho ai muon an toan.
            if (cfg.crafterCraftsPerPulse > 0 && count >= cfg.crafterCraftsPerPulse) {
                crafterPulseCount.remove(loc);
                return;
            }
            org.bukkit.inventory.Inventory inv = crafter.getInventory();
            ItemStack[] matrix = new ItemStack[9];
            for (int i = 0; i < 9; i++) {
                // FIX B2 (audit 2026-09): vanilla crafter KHONG dung slot bi
                // khoa (bua) de match recipe. Doc ca slot disabled = ep craft
                // bang nguyen lieu vanilla tu choi dung -> khac behavior
                // vanilla, co the tao do tu "nguyen lieu bi khoa".
                // PATCH v28p7-batch5-P3b (build fix): goi getSlotState BANG
                // REFLECTION thay vi cast CrafterInventory - lop/phuong thuc
                // nay khong on dinh giua cac phien ban paper-api (zip goc loi
                // compile ngay dong nay voi paper-api 1.21.11). Reflection
                // bien dich duoc tren moi API; that bai = coi nhu slot
                // ENABLED (thuan vanilla, an toan).
                boolean slotEnabled = true;
                try {
                    Object ci = crafter.getInventory();
                    java.lang.reflect.Method gsm = ci.getClass().getMethod("getSlotState", int.class);
                    Object st = gsm.invoke(ci, i);
                    try {
                        slotEnabled = (boolean) st.getClass().getMethod("isEnabled").invoke(st);
                    } catch (NoSuchMethodException nm) {
                        slotEnabled = !st.toString().equals("DISABLED");
                    }
                } catch (Exception ignored) { }
                if (!slotEnabled) {
                    matrix[i] = null;
                    continue;
                }
                ItemStack it = inv.getItem(i);
                matrix[i] = (it == null || it.getType().isAir()) ? null : new ItemStack(it);
            }
            var recipe = org.bukkit.Bukkit.getServer().getCraftingRecipe(matrix, b.getWorld());
            if (recipe == null) { crafterPulseCount.remove(loc); return; }
            // PATCH v28p7-batch5-p3e (runtime fix - bao cao nguoi dung):
            // paper-api 1.21.11 to chuc lai blockdata - Crafter KHONG con
            // implement Directional (cung loai voi CrafterInventory/Attribute
            // Instance) nen cast truc tiep nem ClassCastException MỌI LAN
            // crafter craft, task retrigger chet + spam console. Doc facing
            // BANG REFLECTION getFacing() (van co tren blockdata Crafter,
            // chi khong con qua interface Directional); that bai = bo qua
            // lan retrigger nay (an toan). Cac cho khac cast Directional
            // (hopper/dropper) van hop le - day la block data van con interface.
            BlockFace facing;
            try {
                Object bd = b.getBlockData();
                facing = (BlockFace) bd.getClass().getMethod("getFacing").invoke(bd);
            } catch (Exception ex) {
                crafterPulseCount.remove(loc);
                return;
            }
            Block front = b.getRelative(facing);
            if (!canEjectCrafterResult(front, recipe.getResult())) {
                crafterPulseCount.remove(loc);
                return;
            }
            // FIX v67.4: truoc day put(count + 1) lam dem nhay 2 moi craft
            // (8 crafts_per_pulse chi ra 5 craft that). 'count' da gom craft
            // vanilla vua xay ra nen chi can luu 'count'.
            crafterPulseCount.put(loc, count);
            crafter.setTriggered(true);
            // FIX v67.29: setTriggered tren BlockState snapshot KHONG tu ap xuong
            // tile entity that - phai update() thi crafter moi craft lai. Day la
            // ly do truoc day moi redstone pulse chi ra 1 craft (vanilla) du
            // crafts_per_pulse=8. update(force=true) ap snapshot (chi khac
            // minh o co triggered) ve the gioi.
            crafter.update(true, false);
            // FIX v67.31: du phong NMS - Paper tung co issue #1882 "update()
            // khong ap duoc mot so tile entity". setTriggered truc tiep qua
            // NMS dam bao co triggered cham toi tile entity that bat ke hanh
            // vi snapshot cua BlockState. That bai thi thoi (update() da lo).
            try {
                primeCrafterNMS(b.getWorld());
                if (CRAFTER_WORLD_GET_HANDLE == null || CRAFTER_BPOS_CLASS == null
                        || CRAFTER_BPOS_CONTAINING == null || CRAFTER_WORLD_GET_BLOCK_ENTITY == null) return;
                Object worldHandle = CRAFTER_WORLD_GET_HANDLE.invoke(b.getWorld());
                Object bp = CRAFTER_BPOS_CONTAINING.invoke(null,
                        (double) b.getX(), (double) b.getY(), (double) b.getZ());
                Object be = CRAFTER_WORLD_GET_BLOCK_ENTITY.invoke(worldHandle, bp);
                if (be != null) {
                    if (CRAFTER_BE_SET_TRIGGERED == null) {
                        CRAFTER_BE_SET_TRIGGERED = be.getClass().getMethod("setTriggered", boolean.class);
                    }
                    CRAFTER_BE_SET_TRIGGERED.invoke(be, true);
                }
            } catch (Exception ex) {
                MauaHopper.fineSafe("Crafter block entity trigger failed", ex);
            }
        } catch (Exception ex) {
            MauaHopper.warnSafe("Crafter retrigger failed", ex);
        }
    }

    private boolean canEjectCrafterResult(Block front, ItemStack result) {
        try {
            BlockState fs = front.getState(false);
            if (!(fs instanceof Container container)) return true;
            org.bukkit.inventory.Inventory inv = container.getInventory();
            int remaining = result.getAmount();
            for (ItemStack s : inv.getContents()) {
                if (remaining <= 0) return true;
                if (s == null || s.getType().isAir()) {
                    remaining -= Math.min(remaining, result.getMaxStackSize());
                } else if (s.isSimilar(result)) {
                    remaining -= Math.min(remaining, s.getMaxStackSize() - s.getAmount());
                }
            }
            return remaining <= 0;
        } catch (Throwable t) {
            return false;
        }
    }

    // =====================================================================
    // DISPENSER FAST BURST (v59) - KHÔNG đặt block:
    // Redstone ngườI chơI kích hoạt -> dispenser bắn N lần NGAY (shots_per_pulse)
    // bằng cách gọi trực tiếp NMS DispenserBlock.dispenseFrom - không sinh
    // redstone block, không chờ nhịp. Chỉ item trong fast_items được bắn nhanh.
    // =====================================================================

    private boolean selfDispensing = false;

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onDispense(org.bukkit.event.block.BlockDispenseEvent e) {
        if (!plugin.isActive()) return; // v67.8
        ConfigManager cfg = plugin.getConfigManager();
        if (!cfg.dispenserFastEnabled) return;
        if (selfDispensing) return;
        Block b = e.getBlock();
        if (b.getType() != Material.DISPENSER) return;
        if (!cfg.dispenserFastItems.contains(e.getItem().getType())) return;
        if (!plugin.getWorldManager().isWorldAllowed(b.getWorld())) return;
        // YELLOW FIX: dung dispenser.fast_interval_ticks de gioi han burst.
        long dKey = packKey(b.getLocation());
        int intervalTicks = Math.max(1, cfg.dispenserFastInterval);
        int lastBurst = lastFastDispenserBurstTick.getOrDefault(dKey, Integer.MIN_VALUE);
        // v28p6 FIX (loi #11): dung dispenserGateTick (monotonic, khong bi
        // reset) thay tickCounter - tranh gate am khoa burst dinh ky 10 phut.
        if (intervalTicks > 1 && dispenserGateTick - lastBurst < intervalTicks) return;
        lastFastDispenserBurstTick.put(dKey, dispenserGateTick);
        // v4.06: burst NMS gọi thẳng dispenseFrom, không qua InventoryMoveItemEvent.
        // Nếu nghi block AC mà integration không sẵn
        // thì KHÔNG burst thêm - để vanilla/custom path duy nhất xử lý, tránh
        // bắn thêm vào inventory ẩn của CHEST/virtual page của AC.
        // v28p6 FIX (loi #16): xoa dead code tinh target/targetState khong
        // dung den (comment AC integration con do) - gay hieu nham con gate.
        if (!initDispenseNMS()) return;

        int shots = Math.max(1, cfg.dispenserShotsPerPulse);
        selfDispensing = true;
        try {
            // PATCH 2026-09-28: comment v67.95 cu (getState 1 LAN) da bi vo
            // hieu boi PATCH loi #26 ben duoi - xoa de khoi hieu nham. Hanh
            // vi dung: getState MOI cho tung shot (snapshot cu stale sau moi
            // lan NMS dispense).
            for (int i = 1; i < shots; i++) {
                // PATCH 2026-09-27 (loi #26): getState MOI cho tung shot -
                // snapshot cu bi stale sau moi lan NMS dispense (da rong van
                // tuong con do -> goi shot thua). 8 getState/pulse la chi
                // phi chap nhan duoc so voi correctness.
                BlockState st = b.getState(false);
                if (!(st instanceof org.bukkit.block.Dispenser disp)) return;
                boolean has = false;
                for (ItemStack it : disp.getInventory()) {
                    if (it != null && cfg.dispenserFastItems.contains(it.getType())) {
                        has = true;
                        break;
                    }
                }
                if (!has) break;
                // PATCH 2026-09-29 (batch 1, loi #2): dispenseOnceNMS tra false
                // khi NMS hong -> break ngay, khong goi reflection loi tiep.
                if (!dispenseOnceNMS(b)) break;
            }
        } catch (Exception ex) {
            MauaHopper.warnSafe("Dispenser fast burst failed", ex);
        } finally {
            selfDispensing = false;
        }
    }

    private static java.lang.reflect.Method NMS_DISPENSE_FROM;
    private static java.lang.reflect.Constructor<?> NMS_BLOCKPOS_CTOR;
    private static java.lang.reflect.Method CB_GET_HANDLE_WORLD;
    private static java.lang.reflect.Method CB_BLOCK_GET_NMS;
    private static java.lang.reflect.Method NMS_STATE_GET_BLOCK;
    private static boolean nmsInit = false;
    private static boolean nmsOk = false;
    private static boolean nmsWarned = false;

    private static boolean initDispenseNMS() {
        if (nmsInit) return nmsOk;
        nmsInit = true;
        try {
            Class<?> blockPosClass = Class.forName("net.minecraft.core.BlockPos");
            try {
                NMS_BLOCKPOS_CTOR = blockPosClass.getDeclaredConstructor(int.class, int.class, int.class);
                NMS_BLOCKPOS_CTOR.setAccessible(true);
            } catch (NoSuchMethodException e) {
                NMS_BLOCKPOS_CTOR = null;
            }
            Class<?> dispenserBlock = Class.forName("net.minecraft.world.level.block.DispenserBlock");
            for (java.lang.reflect.Method m : dispenserBlock.getDeclaredMethods()) {
                if (m.getName().equals("dispenseFrom") && m.getParameterCount() == 2) {
                    NMS_DISPENSE_FROM = m;
                    break;
                }
            }
            if (NMS_DISPENSE_FROM == null) throw new NoSuchMethodException("dispenseFrom");
            NMS_DISPENSE_FROM.setAccessible(true);
            Object anyWorld = org.bukkit.Bukkit.getWorlds().get(0);
            CB_GET_HANDLE_WORLD = anyWorld.getClass().getMethod("getHandle");
            nmsOk = true;
            return true;
        } catch (Throwable t) {
            warnNms("không khởi tạo được: " + t.getMessage());
            nmsOk = false;
            return false;
        }
    }

    private static void warnNms(String msg) {
        if (nmsWarned) return;
        nmsWarned = true;
        try {
            org.bukkit.Bukkit.getLogger().warning(
                    "[MauaHopper] Dispenser fast burst tat (NMS " + msg + ") - vanilla toc do");
        } catch (Exception ex) {
            MauaHopper.fineSafe("Safe catch in HopperTicker", ex);
        }
    }

    // PATCH 2026-09-29 (batch 1, loi #2): tra true/false thay void. Truoc
    // day catch nem RuntimeException -> onDispense catch in FULL stack trace
    // qua warnSafe cho MOI pulse dispenser bi kich (KHONG dedupe) = spam log
    // lien tuc khi NMS mismatch. Bay gio: loi -> warn 1 lan (warnNms), tat
    // luon fast path (nmsOk=false) de vanilla tiep quan - dispenser khong
    // bao gio bi "ket" im lang, khong spam log.
    private boolean dispenseOnceNMS(Block b) {
        try {
            Object serverLevel = CB_GET_HANDLE_WORLD.invoke(b.getWorld());
            Object blockPos;
            if (NMS_BLOCKPOS_CTOR != null) {
                blockPos = NMS_BLOCKPOS_CTOR.newInstance(b.getX(), b.getY(), b.getZ());
            } else {
                Class<?> blockPosClass = Class.forName("net.minecraft.core.BlockPos");
                blockPos = blockPosClass.getMethod("containing", double.class, double.class, double.class)
                        .invoke(null, b.getX() + 0.5, b.getY() + 0.5, b.getZ() + 0.5);
            }
            if (CB_BLOCK_GET_NMS == null) CB_BLOCK_GET_NMS = b.getClass().getMethod("getNMS");
            Object nmsState = CB_BLOCK_GET_NMS.invoke(b);
            if (NMS_STATE_GET_BLOCK == null) NMS_STATE_GET_BLOCK = nmsState.getClass().getMethod("getBlock");
            Object nmsBlock = NMS_STATE_GET_BLOCK.invoke(nmsState);
            NMS_DISPENSE_FROM.invoke(nmsBlock, serverLevel, blockPos);
            return true;
        } catch (Throwable t) {
            warnNms("dispense loi: " + t.getMessage());
            nmsOk = false;
            return false;
        }
    }

    // =====================================================================
    // DISPENSER AUTO BURST (v66) - tu ban theo nhip ticker, KHONG can redstone:
    // Moi dispenser da dang ky (dat tu khi plugin chay / chunk load) duoc ban
    // shots_per_pulse item moi auto_burst_ticks tick, mien la con fast_items
    // trong inventory. Co gioi han max_per_tick + cooldown theo dispenser.
    // =========================================================================

    private void processDispenserAutoBurst() {
        ConfigManager cfg = plugin.getConfigManager();
        // PATCH v28p7-batch6-d1 (loi #10): 0=unlimited la foot-gun (admin dat 0
        // nghi "tat gioi han" -> hoa ra MAX_VALUE dispenser/tick). Doi sentinel:
        // < 0 = unlimited (ro rang), 0 = ve mac dinh 50.
        int maxPerTick = cfg.dispenserAutoBurstMaxPerTick < 0 ? Integer.MAX_VALUE
                : (cfg.dispenserAutoBurstMaxPerTick == 0 ? 50 : cfg.dispenserAutoBurstMaxPerTick);
        int processed = 0;

        // v67.21: snapshot + xoay vong tranh bo doi dispenser cuoi map
        long nowMs = System.currentTimeMillis();
        if (dispenserEntriesSnapshot == null || nowMs - lastDispenserEntrySnapshotMs > 500) {
            lastDispenserEntrySnapshotMs = nowMs;
            dispenserEntriesSnapshot = new java.util.ArrayList<>(chunkDispensers.entrySet());
        }
        int dEntryCount = dispenserEntriesSnapshot.size();
        if (dEntryCount == 0) return;
        int dEntryStart = dispenserRotateOffset % dEntryCount;
        dispenserRotateOffset = (dispenserRotateOffset + Math.max(1, maxPerTick)) % dEntryCount;

        for (int dei = 0; dei < dEntryCount && processed < maxPerTick; dei++) {
            Set<Location> locs = dispenserEntriesSnapshot.get((dEntryStart + dei) % dEntryCount).getValue();
            for (Location loc : locs) {
                if (processed >= maxPerTick) break;
                if (dispenserCooldowns.containsKey(loc)) continue;

                Block b = loc.getBlock();
                if (b.getType() != Material.DISPENSER) {
                    // PATCH 2026-09-29 (batch 1, loi #3): tu unregister nhu
                    // hopper (738) va dropper (2512). Piston keo dispenser di
                    // khong sinh BlockBreakEvent -> entry song toi chunk
                    // unload, bi snapshot quet moi 500ms vo ich.
                    unregisterDispenser(loc);
                    continue;
                }
                if (!plugin.getWorldManager().isWorldAllowed(b.getWorld())) continue;

                // Chi ban khi co nguoi choi gan (tranh chay vung khong ai toi)
                if (cfg.dispenserAutoRequirePlayer
                        && !anyPlayerNear(loc, cfg.dispenserAutoPlayerRadius)) {
                    continue;
                }

                BlockState st = b.getState(false);
                if (!(st instanceof org.bukkit.block.Dispenser disp)) continue;

                int shots = 0;
                // CAM FIX cuoi: auto-burst phai init NMS truoc khi goi dispense,
                // va phai lay BlockState MOI sau tung shot. BlockState cu bi
                // stale sau NMS dispense, khien burst ban thua/sai item.
                if (!initDispenseNMS()) continue;
                selfDispensing = true; // chan onDispense no burst long burst
                try {
                    for (int i = 0; i < cfg.dispenserShotsPerPulse; i++) {
                        BlockState freshState = b.getState(false);
                        if (!(freshState instanceof org.bukkit.block.Dispenser freshDisp)) break;
                        boolean has = false;
                        for (ItemStack it : freshDisp.getInventory()) {
                            if (it != null && cfg.dispenserFastItems.contains(it.getType())) {
                                has = true;
                                break;
                            }
                        }
                        if (!has) break;
                        // PATCH 2026-09-29 (batch 1, loi #2): false = NMS hong
                        // -> break, khong dem shot, khong goi reflection loi tiep.
                        if (!dispenseOnceNMS(b)) break;
                        shots++;
                    }
                } catch (Exception ex) {
                    MauaHopper.warnSafe("Dispenser fast burst failed", ex);
                } finally {
                    selfDispensing = false;
                }

                if (shots > 0) {
                    processed++;
                    dispenserCooldowns.put(loc, Math.max(0, cfg.dispenserAutoBurstTicks));
                }
            }
        }
    }

    private static boolean anyPlayerNear(Location loc, double radius) {
        double r2 = radius * radius;
        for (var p : loc.getWorld().getPlayers()) {
            // PATCH 2026-09-29 (batch 3, loi #10): p.getLocation() alloc 1
            // Location cho MOI player x MOI dispenser x MOI tick. Toa do
            // primitive cua entity - 0 alloc, cung cong thuc khoang cach.
            double ddx = p.getX() - loc.getX(), ddy = p.getY() - loc.getY(), ddz = p.getZ() - loc.getZ();
            if (ddx * ddx + ddy * ddy + ddz * ddz <= r2) return true;
        }
        return false;
    }



    private static ItemStack cloneAmount(ItemStack proto, int amount) {
        ItemStack c = proto.clone();
        c.setAmount(amount);
        return c;
    }

    // PATCH 2026-09-28 (loi #8/#26 - TPS): stream trong hot path - moi
    // transfer chay pipeline iterator + boxing. Vong thuan don gian hon,
    // 0 alloc, cung ket qua.
    private static int leftoverSum(Map<Integer, ItemStack> leftover) {
        int sum = 0;
        for (ItemStack is : leftover.values()) sum += is.getAmount();
        return sum;
    }

    /** Them item vao inventory, tra ve so KHONG cho duoc (leftover). */
    private int add(Inventory inv, Material type, int amount) {
        ItemStack stack = new ItemStack(type, amount);
        java.util.Map<Integer, ItemStack> leftover = inv.addItem(stack);
        if (leftover.isEmpty()) return 0;
        return leftoverSum(leftover);
    }

    /** v4.04j: them STACK DAY DU META (khong dung new ItemStack(type, amt)). */
    private int addStack(Inventory inv, ItemStack stack) {
        java.util.Map<Integer, ItemStack> leftover = inv.addItem(stack);
        if (leftover.isEmpty()) return 0;
        return leftoverSum(leftover);
    }

    private int freeSpaceTotal(Inventory inv) {
        int room = 0;
        for (ItemStack it : inv.getStorageContents()) {
            if (it == null || it.getType() == Material.AIR) room += 64;
            else room += Math.max(0, it.getMaxStackSize() - it.getAmount());
        }
        return room;
    }


    /**
     * v67.6: world bi cam trong config -> plugin khong xu ly o do, nen cung
     * KHONG duoc cancel vanilla (neu khong hopper se chet han vi ticker bo
     * qua world nay).
     */
    private boolean isInvWorldAllowed(Inventory inv) {
        try {
            if (inv.getHolder() instanceof BlockState bs) {
                return plugin.getWorldManager().isWorldAllowed(bs.getWorld());
            }
            if (inv.getHolder() instanceof Entity ent) {
                return plugin.getWorldManager().isWorldAllowed(ent.getWorld());
            }
        } catch (Exception ex) {
            MauaHopper.fineSafe("Safe catch in HopperTicker", ex);
        }
        return true; // khong xac dinh -> cho phep
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onInventoryPickup(InventoryPickupItemEvent e) {
        // Cancel vanilla pickup của HOPPER BLOCK - sweep/immediate pickup của
        // MauaHopper tự đọc đủ số thật từ PDC (xem pickupItemEntityIntoHopper).
        if (!plugin.isActive() || !plugin.getConfigManager().hopperEnabled) return; // v67.8/v67.11
        // v4.04 FIX: pickup.enabled=false -> khong cancel vanilla nua (sweep +
        // immediate pickup cung da duoc gate boi pickupEnabled; neu van cancel
        // thi do roi tren hopper KHONG BAO GIO duoc nhat).
        if (!plugin.getConfigManager().pickupEnabled) return;
        if (!isInvWorldAllowed(e.getInventory())) return; // v67.6: world cam -> vanilla tu lo
        if (e.getInventory().getHolder() instanceof org.bukkit.block.Hopper) {
            e.setCancelled(true);
            return;
        }
        // FIX v40: cancel CẢ vanilla pickup của MINECART HOPPER - vanilla suck
        // KHÔNG đọc PDC -> item gộp 576 chỉ vào 64, mất 512. Minecart sweep
        // của MauaHopper (minecartPickupGround) tự nhặt đủ số thật.
        if (e.getInventory().getHolder() instanceof org.bukkit.entity.minecart.HopperMinecart) {
            // p9 FIX: chi cancel vanilla khi plugin path DANG chay - neu
            // minecart_hopper=false ma van cancel thi minecart KHONG NHAT
            // duoc gi ca (vanilla bi chan, plugin path cung return som).
            if (plugin.getConfigManager().minecartHopperEnabled) e.setCancelled(true);
        }
    }


    /** Clone stack và xóa mọi dấu vết hiển thị stack gộp (display name +
     * lore số lượng) - tránh đồ trong rương mang tên/lore "Gộp: 576...".
     * Delegate sang ItemStackingManager để logic strip nằm 1 chỗ. */
    private ItemStack stripStackDisplayName(ItemStack stack) {
        try {
            var mgr = plugin.getItemStackingManager();
            if (mgr != null) return mgr.stripStackVisuals(stack);
        } catch (Exception ex) {
            MauaHopper.fineSafe("Safe catch in HopperTicker", ex);
        }
        return stack.clone();
    }

    /**
     * Đọc số lượng THẬT của item đã gộp (ItemStackingManager tích hợp của
     * chính plugin). ItemStack bề mặt chỉ 64, PDC mới lưu tổng thật (vd 576).
     * Trả null nếu chưa gộp.
     */
    private Integer getStackTotal(Item item) {
        try {
            var mgr = plugin.getItemStackingManager();
            if (mgr != null) return mgr.getStackAmount(item);
        } catch (Exception ex) {
            MauaHopper.fineSafe("Safe catch in HopperTicker", ex);
        }
        return null;
    }

    /** Ghi lại số lượng còn lại (tự xóa entity khi hết). */
    private void setStackTotal(Item item, int amount) {
        try {
            var mgr = plugin.getItemStackingManager();
            if (mgr != null) mgr.setStackAmount(item, amount);
        } catch (Exception ex) {
            MauaHopper.fineSafe("Safe catch in HopperTicker", ex);
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onItemSpawn(ItemSpawnEvent e) {
        if (!plugin.isActive() || !plugin.getConfigManager().hopperEnabled) return; // v67.8/v67.11
        markChunkHasItems(e.getEntity().getLocation());
        // PORT từ bản gốc 3.4: nhặt NGAY LẬP TỨC khi item spawn.
        // Trước đây chỉ đánh dấu chunk rồi chờ sweep định kỳ - đồ dễ bị
        // LagFixer TrashDisposal / despawn nuốt mất trước khi sweep tới.
        // PATCH v17: getEntity() cua ItemSpawnEvent da tra Item - instanceof
        // thua gay loi ECJ (javac chap nhan nhung khong can thiet).
        Item item = e.getEntity();
        if (!trySpawnImmediateGate(item.getLocation())) return; // FIX TPS 2026-09-28
        // PATCH v28p7-batch6-d4 (loi #22): 'cfg' KHONG PHAI field cua class
        // va method onItemSpawn nay chua khai bao local - 2 cho 'cfg.pickupDebugLog'
        // ben duoi la LOI COMPILE TIEM AN tu source goc (cung loai voi loi #11).
        // Fix: dung plugin.getConfigManager() nhu dong :3802 ben tren.
        if (plugin.getConfigManager().pickupDebugLog)
            plugin.getLogger().info("[DBG-PICKUP] spawn-ok: " + item.getItemStack().getType() + " @ " + item.getLocation().getBlockX() + "," + item.getLocation().getBlockY() + "," + item.getLocation().getBlockZ());
        {
            Block hopper = findHopperForGroundItem(item);
            if (plugin.getConfigManager().pickupDebugLog)
                plugin.getLogger().info("[DBG-PICKUP] hopper-ben-duoi=" + (hopper == null ? "KHONG TIM THAY" : hopper.getType()));
            if (hopper != null) {
                tryImmediateGroundPickup(hopper, item);
            }
        }
    }

    /**
     * Tìm hopper tại vị trí item (item thường nằm TRÊN mặt hopper:
     * block tại vị trí item là AIR, block dưới là HOPPER).
     */
    private Block findHopperForGroundItem(Entity entity) {
        Block block = entity.getLocation().getBlock();
        if (block.getType() == Material.HOPPER) {
            return block;
        }
        Block below = block.getRelative(BlockFace.DOWN);
        if (below.getType() == Material.HOPPER) {
            return below;
        }
        return null;
    }

    /**
     * Nhặt item vào hopper ngay lập tức - port từ DonutHopper 3.4 gốc.
     * Đây là lý do bản gốc không bị mất đồ.
     */
    private void tryImmediateGroundPickup(Block hopperBlock, Item item) {
        ConfigManager cfg = plugin.getConfigManager();
        // CAM FIX: khong pickup bang duong immediate o world bi cam.
        if (!plugin.getWorldManager().isWorldAllowed(hopperBlock.getWorld())) return;
        if (!cfg.pickupEnabled || !cfg.pickupInstant) return;
        if (cfg.pickupDebugLog) plugin.getLogger().info("[DBG-PICKUP] spawn: enabled=" + cfg.pickupEnabled + " instant=" + cfg.pickupInstant + " active=" + plugin.isActive());
        if (item == null || !item.isValid() || item.isDead()) return;

        // v28p6 FIX (loi #12): blacklist chua ten ITEM (vd COBBLESTONE) -
        // check hopperBlock.getType().name() (luon la "HOPPER") khong bao gio
        // khop -> blacklist bi bypass o duong pickup ngay.
        // PATCH 2026-09-29 (batch 3, loi #9): doi sang EnumSet<Material> giong
        // sweep path - O(1), khong String alloc. Kiem tra nhat quan: truoc
        // day duong nay equalsIgnoreCase O(n) trong khi sweep path contains
        // exact -> config viet thuong chi chan 1 trong 2 duong.
        if (cfg.blacklistedMaterialsForPickup.contains(item.getItemStack().getType())) return;

        BlockState state = hopperBlock.getState(false);
        if (!(state instanceof org.bukkit.block.Hopper hopper)) return;
        // PATCH v28p7-batch6-d4 (loi #20): log "hopper day" truoc day nam
        // SAU lenh return cua chinh no -> dead log, khong bao gio in dung
        // luc. Chuyen vao trong nhanh full.
        if (isInventoryFull(hopper.getInventory())) {
            if (cfg.pickupDebugLog) plugin.getLogger().info("[DBG-PICKUP] instant: hopper day, bo qua");
            return;
        }

        prepareItemForPickup(item, cfg);
        pickupItemEntityIntoHopper(item, hopper, cfg);
    }

    /**
     * Xóa pickup delay + owner để cả plugin lẫn vanilla đều nhặt được ngay
     * (vanilla pickup làm đường dự phòng khi plugin đang bận).
     */
    // v4.04 FIX: ton trong respect_pickup_delay; KHONG setOwner(null) nua -
    // xoa owner lam plugin bao ve do roi (protection/anti-grief) mat chu so huu.
    private void prepareItemForPickup(Item item, ConfigManager cfg) {
        if (cfg.pickupInstant && !cfg.pickupRespectDelay) {
            item.setPickupDelay(0);
        }
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onPlayerDrop(PlayerDropItemEvent e) {
        markChunkHasItems(e.getItemDrop().getLocation());
        // PORT từ bản gốc 3.4: nhặt ngay khi player vứt đồ lên hopper
        Item item = e.getItemDrop();
        if (!trySpawnImmediateGate(item.getLocation())) return; // FIX TPS 2026-09-28
        Block hopper = findHopperForGroundItem(item);
        if (hopper != null) {
            tryImmediateGroundPickup(hopper, item);
        }
    }

    private void markChunkHasItems(Location loc) {
        // PATCH 2026-09-29 (batch 2, loi #5): truoc day chi danh dau khi
        // chunk DUNG item spawn co hopper. Nhung sweep cua chunk co hopper
        // check 3x3 chunk LAN CAN (1.849-1.881) -> item roi o chunk KHONG
        // hopper (nam trong tam pickup cua hopper o chunk ben canh, khi
        // pickup_radius lon) khong bao gio duoc danh dau -> bi bo sot vinh
        // vien o bien chunk. Bay gio danh dau khi BAT KY chunk nao trong
        // 3x3 lan can co hopper (hopperChunks packed-long lookup O(1),
        // khong string alloc cho item spawn).
        long wBits = worldBits(loc.getWorld().getName()) << 42;
        int cx = loc.getBlockX() >> 4, cz = loc.getBlockZ() >> 4;
        boolean nearHopper = false;
        for (int dx = -1; dx <= 1 && !nearHopper; dx++) {
            for (int dz = -1; dz <= 1 && !nearHopper; dz++) {
                long nKey = wBits | ((((long) cx + dx) & 0x1FFFFFL) << 21)
                        | (((long) cz + dz) & 0x1FFFFFL);
                if (hopperChunks.contains(nKey)) nearHopper = true;
            }
        }
        if (!nearHopper) return;
        chunkHasItems.put(packChunkKey(loc), Boolean.TRUE);
        // v67.7: item moi -> quet lai ngay. PATCH v28p7-batch5-P2 (loi #9):
        // doi sang packed-long key (0 string alloc), dong bo voi
        // chunkPickupCooldowns da doi kieu.
        chunkPickupCooldowns.remove(packChunkKey(loc));
    }

    // =========================================================================
    // Stats accessors
    // =========================================================================

    public long getReadyHopperCount()      { return readyHoppers.get(); }
    public long getRegisteredHopperCount() { return registeredHoppers.get(); }

    public long getComposterFeeds()        { return composterFeeds.get(); }
    public long getBonemealCollected()     { return bonemealCollected.get(); }
    public long getCauldronFills()         { return cauldronFills.get(); }
    public long getCauldronDrains()        { return cauldronDrains.get(); }

    public void resetSpecialBlockStats() {
        composterFeeds.set(0);
        bonemealCollected.set(0);
        cauldronFills.set(0);
        cauldronDrains.set(0);
    }
}
