package com.mauahopper;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public class PlayerToggleManager {

    private final MauaHopper plugin;
    // UUIDs of players who have explicitly disabled fast hoppers for themselves
    // PATCH v28p7-batch5-P3 (loi #13): Map<UUID, thoi diem bi disable> thay vi
    // Set<UUID>. Truoc day cleanup removeIf(offline) chay moi 30 phut xoa BAT
    // KY ai dang offline - nguoi choi vua toggle roi relog sau 31 phut bi
    // reset toggle trai voi thiet ke "giu toi 30 phut SAU logout". Bay gio
    // moi entry luu thoi diem disable; cleanup chi xoa khi NGUOI CHOI OFFLINE
    // VA da qua 30 phut ke tu luc disable.
    private final Map<UUID, Long> disabledSince = new ConcurrentHashMap<>();

    // v28p6 FIX (loi #36): luu handle task de onDisable goi shutdown() -
    // phong truong hop PlugMan/manager khong cancel task cua plugin cu,
    // timer cu chay mai tren instance cu (memory leak + task mo).
    private org.bukkit.scheduler.BukkitTask cleanupTask;

    public PlayerToggleManager(MauaHopper plugin) {
        this.plugin = plugin;
        cleanupTask = plugin.getServer().getScheduler().runTaskTimer(plugin,
                () -> {
                    long cutoff = System.currentTimeMillis() - 30L * 60 * 1000L; // 30 phut
                    disabledSince.forEach((u, since) -> {
                        if (since < cutoff && plugin.getServer().getPlayer(u) == null)
                            disabledSince.remove(u, since);
                    });
                },
                20L * 60 * 30, 20L * 60 * 30);
    }

    /** v28p6 FIX (loi #36): goi tu onDisable - cancel timer don UUID. */
    public void shutdown() {
        if (cleanupTask != null) { cleanupTask.cancel(); cleanupTask = null; }
    }

    public boolean isEnabledFor(UUID uuid) {
        return !disabledSince.containsKey(uuid);
    }

    public void enable(UUID uuid) {
        disabledSince.remove(uuid);
    }

    public void disable(UUID uuid) {
        disabledSince.put(uuid, System.currentTimeMillis());
    }

    public boolean toggle(UUID uuid) {
        if (disabledSince.containsKey(uuid)) {
            disabledSince.remove(uuid);
            return true;  // now enabled
        } else {
            disabledSince.put(uuid, System.currentTimeMillis());
            return false; // now disabled
        }
    }
}
