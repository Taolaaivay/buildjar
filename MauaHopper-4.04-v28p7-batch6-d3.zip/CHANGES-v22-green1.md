# MauaHopper 4.04-PATCHED-v22-green1

Bao gom red1 + orange1 + yellow batch 1/2 + green batch 1.

## Green fixes
- Cauldron 1-slot bucket transform.
- Rail check dung RAIL_BLOCKS thay vi contains string.
- Crafter return so item moved thay vi so slot feed.
- push_ticks pacing that.
- BigChest placement dung material cua type.
- MSPT throttle doi sang server TPS estimate.
- Comment PlayerToggle dung hanh vi 30 phut.
- Tab completion loc theo permission.
- /chests search khong roi vao shop mac dinh.
- saveConfigAsync snapshot YAML ghi file async.
- AsyncPlayerChatEvent chuyen sang Paper AsyncChatEvent.

## Ghi chu
- Maven compile/runtime test chua chay trong moi truong nay.
