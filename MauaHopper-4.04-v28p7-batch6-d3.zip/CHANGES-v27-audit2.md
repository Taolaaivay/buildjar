# MauaHopper 4.04-PATCHED-v27-audit2

Bao gom v26-audit1 + audit batch 2.

## Audit batch 2 fixes
- P4: composter/cauldron/crafter pull ton trong pull_ticks.
- P3: inactive chunk backoff 20 -> 40 -> 80 -> 160 thay vi requeue co dinh.
- P5: safety-net minecart scan 5 phut -> 30 phut.
- P6: cap minecart pickup workload 16 item/cart.
- P7: cache Vault depositPlayer reflection method.
- B7: close all open Rương To GUI before chests.clear() khi load/reload.
- P9: ItemStacking xoay vong toi da 5 player/mergeTick de giam AABB query.
- P10: MobStacking xoay vong toi da 5 player/mergeTick.
- P11: mob attract mac dinh TAT (0.0) de tranh teleport hut mob xuyen tuong.
- P2: full_refresh_ticks mac dinh 40 -> 200.
- S8: cleanup expandNextAt khi player quit.
- S13: sua comment autosave 30s -> 60s.

## Ghi chu
Chua xu ly het toan bo S1-S16/P1-P11 trong dot nay; phan con lai uu tien thap hon.
