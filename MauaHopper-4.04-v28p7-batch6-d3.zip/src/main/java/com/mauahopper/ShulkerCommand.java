package com.mauahopper;

import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;

public class ShulkerCommand implements CommandExecutor, org.bukkit.command.TabCompleter {

    private final MauaHopper plugin;

    public ShulkerCommand(MauaHopper plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        ConfigManager cfg = plugin.getConfigManager();
        if (!sender.hasPermission("mauahopper.shulker")) {
            sender.sendMessage(ChatColor.translateAlternateColorCodes('&', cfg.getMessage("no_permission")));
            return true;
        }

        if (args.length == 0) {
            // PATCH 2026-09-27 (loi #6): hien thi CA 2 trang thai pulling/pushing
            String pull = cfg.shulkerAllowPulling ? "&aBật" : "&cTắt";
            String push = cfg.shulkerAllowPushing ? "&aBật" : "&cTắt";
            sender.sendMessage(ChatColor.translateAlternateColorCodes('&',
                    cfg.getMessage("shulker_status").replace("{status}", pull)));
            sender.sendMessage(ChatColor.translateAlternateColorCodes('&',
                    "&7Đẩy shulker: " + push));
            return true;
        }

        switch (args[0].toLowerCase()) {
            case "on" -> {
                // PATCH 2026-09-27 (loi #6): TRUOC DAY chi bat pulling, bo sot
                // pushing -> /hoppershulk off van con duong day shulker.
                cfg.shulkerAllowPulling = true;
                cfg.shulkerAllowPushing = true;
                plugin.getConfig().set("hopper.shulker.allow_pulling", true);
                plugin.getConfig().set("hopper.shulker.allow_pushing", true);
                // PATCH 2026-09-27 (loi #3): saveConfig SYNC tren main thread
                // (loi #2 tuong tu o SpeedManager).
                plugin.saveConfigAsync();
                sender.sendMessage(ChatColor.translateAlternateColorCodes('&',
                        cfg.getMessage("shulker_enabled")));
            }
            case "off" -> {
                cfg.shulkerAllowPulling = false;
                cfg.shulkerAllowPushing = false;
                plugin.getConfig().set("hopper.shulker.allow_pulling", false);
                plugin.getConfig().set("hopper.shulker.allow_pushing", false);
                plugin.saveConfigAsync();
                sender.sendMessage(ChatColor.translateAlternateColorCodes('&',
                        cfg.getMessage("shulker_disabled")));
            }
            default -> sender.sendMessage(ChatColor.translateAlternateColorCodes('&',
                    cfg.getMessage("usage_shulker")));
        }
        return true;
    }

    @Override
    public java.util.List<String> onTabComplete(org.bukkit.command.CommandSender sender,
            org.bukkit.command.Command command, String alias, String[] args) {
        // v4.17 FIX P3-SHULKER: goi y on/off (truoc day lenh khong co tab complete)
        if (args.length != 1) return java.util.Collections.emptyList();
        java.util.List<String> subs = new java.util.ArrayList<>();
        if ("on".startsWith(args[0].toLowerCase())) subs.add("on");
        if ("off".startsWith(args[0].toLowerCase())) subs.add("off");
        return subs;
    }
}
