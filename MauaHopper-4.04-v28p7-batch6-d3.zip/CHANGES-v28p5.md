# CHANGES v28p5 (2026-09-28) — fix bug + TPS con sot sau v28p4

## BATCH 1 — bug/TPS nang
- MobStack: CLAMP stacking.mobs.attract-radius <= 32, radius <= 64.
  Truoc: attract-radius: 500 -> scanR ~508 trong getNearbyEntities()
  moi merge tick x 5 player = TPS drop tu dong config.
- MobStack: vuot cap 25 respawn/tick chi in 1 warning/dot (truoc: moi
  death event 1 dong -> killall 500 mob ~475 dong log / 1 tick).
- HopperTicker: onChunkUnload don nextContainerPullAt/PushAt,
  dropperCooldowns, dispenserCooldowns — het leak map khi chunk
  load/unload lien tuc.
- HopperTicker: xoa dead field containerCooldownMap.
- HopperTicker: bo ma mau '&' trong 2 dong logger.warning.
- HopperTicker: tickCounter reset vo dieu kien (het tang mai khi map rong).

## BATCH 2 — TPS nhe
- HopperTicker: chunkHasItems + inactiveChunkBackoff doi key String ->
  packed long (het string concat trong lookup 3x3 pickup scan).
- HopperTicker: minecart dung scratch Location chung (0 alloc/cart/tick).
- ItemStack: attractWorld bucket key "cx,cz" -> packed long; bo
  split()/parseInt; het string concat 3x3.

## Xac nhan KHONG phai loi
- MauaHopper.flushConfigSave: write da trong cung synchronized lock ->
  khong co race.
- ItemStack.mergeWorld bucket String: chi 3 lookup/bucket, khong dang lo.
