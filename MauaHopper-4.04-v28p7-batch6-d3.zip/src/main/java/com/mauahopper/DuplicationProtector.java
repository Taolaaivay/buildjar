package com.mauahopper;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.persistence.PersistentDataType;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;
import java.util.logging.Logger;

/**
 * Anti-duplication and anti-item-loss guard for hopper transfers.
 *
 * Strategy:
 *  - Per-hopper transfer lock: a location-keyed set of in-flight transfers.
 *    If a hopper is already mid-transfer, skip it this tick.
 *  - Container cooldown: optional cooldown map preventing two transfers
 *    into the same container within the same tick window.
 *  - Verify-then-commit: optional pre/post item count check with rollback.
 */
public class DuplicationProtector {
    // v4.16 FIX P2-11: key on dinh cho virtual inventory (identity thay vi hashCode)

    private final MauaHopper plugin;

    // PATCH v28p3 (loi #3 - NPE): NamespacedKey phai duoc tao TRONG CONSTRUCTOR
    // sau khi this.plugin duoc gan. Field initializer cu chay truoc than
    // constructor body -> plugin luc do null -> new NamespacedKey(null,...)
    // nem NPE -> plugin tu disable ngay luc onEnable.
    private final NamespacedKey stackAmountKey;

    // PATCH 2026-09-28 (loi #24): key dang STRING duoc build lai 2 lan cho
    // MOI transfer (tryLock + unlock) - hang nghin string concat/tick tren
    // duong nong. Doi sang packed long (16 bit world hash-mix + 16 bit
    // x/y/z co bias) - 0 alloc, x/y/z day du trong 64 bit.
    private final Set<Long> hopperLocks = ConcurrentHashMap.newKeySet();

    // Concurrent container access block: in-flight container set
    private final Set<Long> containerInFlight = ConcurrentHashMap.newKeySet();

    // Stats
    private final AtomicLong blockedDupes       = new AtomicLong(0);
    private final AtomicLong blockedConcurrent  = new AtomicLong(0);

    public DuplicationProtector(MauaHopper plugin) {
        this.plugin = plugin;
        // PATCH v28p3 (loi #3): init key sau khi plugin da gan xong.
        this.stackAmountKey = new NamespacedKey(plugin, "stack_amount");
    }

    /** Try to acquire a per-hopper lock. Returns false if already locked. */
    public boolean tryLockHopper(Location loc) {
        if (!plugin.getConfigManager().perHopperTransferLock) return true;
        long key = packLocKey(loc);
        if (key == Long.MIN_VALUE) return true;
        return hopperLocks.add(key);
    }

    public void unlockHopper(Location loc) {
        long key = packLocKey(loc);
        if (key != Long.MIN_VALUE) hopperLocks.remove(key);
    }

    /** Try to lock a destination container for concurrent-access protection. */
    public boolean tryLockContainer(Inventory inv) {
        if (!plugin.getConfigManager().blockConcurrentContainerAccess) return true;
        long key = invPackedKey(inv);
        if (key == Long.MIN_VALUE) return true;
        boolean locked = containerInFlight.add(key);
        if (!locked) blockedConcurrent.incrementAndGet();
        return locked;
    }

    public void unlockContainer(Inventory inv) {
        long key = invPackedKey(inv);
        if (key != Long.MIN_VALUE) containerInFlight.remove(key);
    }

    /** Pack location ve long 64 bit: 15 bit world-UID + 18 bit x + 12 bit y
     *  + 18 bit z. PATCH 2026-09-29 (batch 1, loi #1): world hash giam con
     *  15 bit de DANH bit 63 lam co phan biet key cua ENTITY inventory (xem
     *  invPackedKey) - tranh collision giua key vi tri block va key UUID.
     *  World lay tu UUID (mix MSB^LSB) - deterministic theo world, khong doi
     *  khi restart.
     *  AUDIT FIX 2026-09-28: ban dau 16 bit/truc chi phu ±32767 block,
     *  world Minecraft rong ±30 trieu block -> 2 container cach 65536 block
     *  trung lock key (false lock). Bo cuc moi: 18 bit x/z = ±131072 block,
     *  12 bit y = -1024..3071 phu toan vanilla build range. False lock chi
     *  delay 1 tick (tryLock fail, retry sau), khong bao gio mat do. */
    private static long packLocKey(Location loc) {
        if (loc == null || loc.getWorld() == null) return Long.MIN_VALUE;
        java.util.UUID uid = loc.getWorld().getUID();
        long w = ((uid.getMostSignificantBits() ^ uid.getLeastSignificantBits()) >> 16) & 0x7FFFL;
        long x = ((long) loc.getBlockX() + 131072L) & 0x3FFFFL;
        long y = ((long) loc.getBlockY() + 1024L) & 0xFFFL;
        long z = ((long) loc.getBlockZ() + 131072L) & 0x3FFFFL;
        return (w << 48) | (x << 30) | (y << 18) | z;
    }

    /** Inventory -> packed key; virtual inventory -> MIN_VALUE (khong khoa).
     *  PATCH 2026-09-29 (batch 1, loi #1): inventory cua ENTITY (minecart
     *  chest, chest boat) khong khoa theo toa do nua. Entity co the dich
     *  chuyen giua tryLock va unlock (plugin teleport day xe / xu ly vat ly)
     *  -> key unlock lech key lock -> entry nam lai trong containerInFlight
     *  VINH VIEN -> toa do do bi stall vinh vien (tryLockContainer false mai,
     *  do ngung chuyen, phai reload). Bay gio khoa theo UUID entity: bit 63
     *  set lam co, 63 bit con lai la mix cua UUID - on dinh du entity di
     *  dau. Inventory block giu nguyen khoa theo vi tri (block khong di
     *  dau duoc). */
    private static long invPackedKey(Inventory inv) {
        if (inv == null) return Long.MIN_VALUE;
        try {
            org.bukkit.inventory.InventoryHolder holder = inv.getHolder();
            if (holder instanceof org.bukkit.entity.Entity ent) {
                java.util.UUID id = ent.getUniqueId();
                long mix = id.getMostSignificantBits() * 31L + id.getLeastSignificantBits();
                long key = 0x8000000000000000L | (mix & 0x7FFFFFFFFFFFFFFFL);
                return key == Long.MIN_VALUE ? Long.MIN_VALUE + 1 : key;
            }
            Location loc = inv.getLocation();
            if (loc != null) return packLocKey(loc);
        } catch (Exception ex) {
            MauaHopper.fineSafe("Safe catch in DuplicationProtector", ex);
        }
        return Long.MIN_VALUE;
    }

    /**
     * Snapshot item counts for all slots in an inventory.
     * Used for pre/post verify when verifyTransfers is enabled.
     */
    public Map<Integer, ItemStack> snapshot(Inventory inv) {
        Map<Integer, ItemStack> snap = new HashMap<>();
        for (int i = 0; i < inv.getSize(); i++) {
            ItemStack item = inv.getItem(i);
            if (item != null) snap.put(i, item.clone());
        }
        return snap;
    }


    /** v4.06: dem theo SIGNATURE + ledger thật. Stack PDC stack_amount được
     *  normalize về meta sạch (bỏ PDC/dòng hiển thị stack) và amount dùng số
     *  THẬT, để verify không false-rollback khi transfer hợp lệ tách ledger.
     *  Item thường vẫn so full meta/enchant/damage/PDC như cũ. */
    /** @deprecated chi con duy tri cho API ngoai; verifyTransfer P2 (batch5)
     *  da chuyen sang accumulateTotals (tong theo Material, khong isSimilar). */
    @Deprecated
    public java.util.Map<String, Integer> countByType(Map<Integer, ItemStack> snap) {
        java.util.List<ItemStack> reps = new java.util.ArrayList<>();
        java.util.Map<String, Integer> m = new java.util.HashMap<>();
        for (ItemStack item : snap.values()) {
            if (item == null || item.getType().isAir()) continue;
            ItemStack base = normalized(item);
            int idx = -1;
            for (int i = 0; i < reps.size(); i++) {
                if (reps.get(i).isSimilar(base)) { idx = i; break; }
            }
            if (idx < 0) { reps.add(base); idx = reps.size() - 1; }
            m.merge("g" + idx, realAmountForVerify(item), Integer::sum);
        }
        return m;
    }

    /** Số thật cho verify: PDC stack_amount nếu hợp lệ và lớn hơn surface. */
    private int realAmountForVerify(ItemStack item) {
        int surface = item.getAmount();
        try {
            var meta = item.getItemMeta();
            if (meta != null) {
                Integer v = meta.getPersistentDataContainer().get(
                        stackAmountKey,
                        PersistentDataType.INTEGER);
                if (v != null && v > surface) return v;
            }
        } catch (Exception ex) {
            MauaHopper.fineSafe("Safe catch in DuplicationProtector", ex);
        }
        return surface;
    }

    private boolean hasStackLedgerKey(ItemStack item) {
        try {
            var meta = item.getItemMeta();
            return meta != null && meta.getPersistentDataContainer().has(
                    stackAmountKey,
                    PersistentDataType.INTEGER);
        } catch (Exception ex) {
            MauaHopper.fineSafe("Safe catch in DuplicationProtector", ex);
            return false;
        }
    }

    /**
     * Verify that items moved == (before - after) for source and
     * (after - before) for destination.  Rolls back if mismatch detected.
     * Returns false when a rollback was performed.
     *
     * FIX AUDIT 2026-09: nhom item bang representative + ItemStack.isSimilar
     * tren 4 snapshot CHUNG mot danh sach rep - thay vi hashCode(ItemMeta)
     * (khong on dinh giua cac phien ban API, false-positive rollback lien
     * tuc). Ledger PDC stack_amount duoc strip + dem theo so that nhu truoc.
     */
    public boolean verifyTransfer(
            Inventory source, Map<Integer, ItemStack> srcBefore,
            Inventory dest,   Map<Integer, ItemStack> dstBefore,
            int expectedMoved, Location hopperLoc) {

        if (!plugin.getConfigManager().verifyTransfers) return true;

        // PATCH v28p7-batch5-P2 (loi #7 - TPS): truoc day verify clone THEM 2
        // snapshot (srcAfter/dstAfter) roi nhom item bang representative +
        // ItemStack.isSimilar cho MOI slot ca 4 phia = O(slots x reps) meta
        // compare + 2 full clone MOI transfer co verify bat. Dupe/loss = TAO
        // hoac MAT vat pham -> TONG SO LUONG theo tung loai Material BAT
        // BUOC thay doi. Verify theo tong theo Material (EnumMap O(1), chi
        // cong so nguyen, KHONG clone, KHONG isSimilar) van bat duoc moi
        // truong hop tao/mat/hoan-doi vat pham. Rollback nguyen ven.
        Map<Material, long[]> delta = new EnumMap<>(Material.class);
        accumulateTotals(delta, srcBefore, 0, +1);
        accumulateTotalsLive(delta, source, 0, -1);
        accumulateTotals(delta, dstBefore, 1, -1);
        accumulateTotalsLive(delta, dest, 1, +1);

        long srcDelta = 0, dstDelta = 0;
        boolean mismatch = false;
        // PATCH v28p7-batch6-d3 (loi #7): truoc day break o mismatch DAU TIEN
        // -> srcDelta/dstDelta chi la TONG MOT PHAN nhung van duoc so voi
        // expectedMoved trong dieu kien + log -> so lieu sai gay kho debug
        // (rollback khong sai vi 'mismatch ||' da bat). Bay gio: duyet het,
        // cong du tong, danh dau mismatch rieng.
        for (long[] d : delta.values()) {
            if (d[0] != d[1]) mismatch = true;
            srcDelta += d[0];
            dstDelta += d[1];
        }

        if (mismatch || srcDelta != expectedMoved || dstDelta != expectedMoved) {
            blockedDupes.incrementAndGet();

            Logger log = plugin.getLogger();
            log.warning("Đã chặn dup: xác minh thất bại (totals) "
                    + locKey(hopperLoc) + " -> (dest) (" + expectedMoved + " items, srcΔ=" + srcDelta + ", dstΔ=" + dstDelta + ")");

            if (plugin.getConfigManager().rollbackOnDupe) {
                // Restore source
                for (int i = 0; i < source.getSize(); i++) {
                    source.setItem(i, srcBefore.getOrDefault(i, null));
                }
                // Restore dest
                for (int i = 0; i < dest.getSize(); i++) {
                    dest.setItem(i, dstBefore.getOrDefault(i, null));
                }
                log.warning("Lỗi chuyển item, đã rollback tại " + locKey(hopperLoc));
            }
            return false;
        }
        return true;
    }

    /** PATCH v28p7-batch5-P2 (loi #7): cong so luong THAT (ledger PDC)
     *  theo Material tu snapshot clone da co - khong clone them. which=0 src,
     *  1 dst; sign quy uoc chieu cong/tru theo before/after. */
    private void accumulateTotals(Map<Material, long[]> delta,
                                  Map<Integer, ItemStack> snap,
                                  int which, int sign) {
        for (ItemStack item : snap.values()) {
            if (item == null || item.getType().isAir()) continue;
            long[] d = delta.computeIfAbsent(item.getType(), k -> new long[2]);
            d[which] += sign * (long) realAmountForVerify(item);
        }
    }

    /** Phien ban KHONG CLONE - doc truc tiep inventory hien tai. */
    private void accumulateTotalsLive(Map<Material, long[]> delta, Inventory inv,
                                      int which, int sign) {
        for (int i = 0; i < inv.getSize(); i++) {
            ItemStack item = inv.getItem(i);
            if (item == null || item.getType().isAir()) continue;
            long[] d = delta.computeIfAbsent(item.getType(), k -> new long[2]);
            d[which] += sign * (long) realAmountForVerify(item);
        }
    }

    /** Ban sao sach de so sanh: strip PDC ledger + visual stack, amount=1. */
    private ItemStack normalized(ItemStack item) {
        ItemStack base;
        if (hasStackLedgerKey(item)) {
            var mgr = plugin.getItemStackingManager();
            base = mgr != null ? mgr.stripStackVisuals(item) : item.clone();
            var meta = base.getItemMeta();
            if (meta != null) {
                meta.getPersistentDataContainer().remove(stackAmountKey);
                base.setItemMeta(meta);
            }
        } else {
            base = item.clone();
        }
        base.setAmount(1);
        return base;
    }

    public long getBlockedDupes()      { return blockedDupes.get(); }
    public long getBlockedConcurrent() { return blockedConcurrent.get(); }

    public void resetStats() {
        blockedDupes.set(0);
        blockedConcurrent.set(0);
    }

    // -------------------------------------------------------------------------

    private static String locKey(Location loc) {
        if (loc == null) return "null";
        // FIX AUDIT 2026-09: world co the null khi chunk vua unload -> NPE
        // tren duong khoa/release hopper.
        if (loc.getWorld() == null) return "unloaded:" + loc.getBlockX() + ":" + loc.getBlockY() + ":" + loc.getBlockZ();
        return loc.getWorld().getName() + ":" + loc.getBlockX() + ":" + loc.getBlockY() + ":" + loc.getBlockZ();
    }

    // PATCH 2026-09-28 (loi #24): invKey() da thay bang invPackedKey() - go
    // v28p6 FIX (loi #33): VIRTUAL_KEYS da xoa - snapshot() khong con dung
    // no (invKey() bi xoa tu truoc), comment cu mo ta sai thuc te.
}
