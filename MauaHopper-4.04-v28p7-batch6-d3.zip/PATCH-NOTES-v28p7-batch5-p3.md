# PATCH NOTES v28p7-batch5-p3 (2026-09-29) - build tren p2

Dia chi 5 lỗi MỨC NHỎ + hoan tat dot patch audit (P1: 4 lỗi cao, P2: 5 lỗi TB).

## Lỗi #11 (TPS) - ItemStackingManager + MobStackingManager: AABB query chong lap
- TRIỆU CHỨNG: mergeTick xoay vong 5 player/luot, moi player 1 query AABB box
  lon. 5 nguoi dung gan nhau -> 5 query vung CHONG LAP; seen set chi dedupe
  ket qua sau query, khong ngan duoc query trung.
- FIX: giu list vi tri da quet, bo qua player nam trong scanR cua player da
  quet. Hanh vi khong doi (seen set van loc item trung), chi giam so query.

## Lỗi #12 (TPS) - ItemStackingManager: cap hologram 1000 armor stand
- TRIỆU CHỨNG: display HOLOGRAM/BOTH spawn toi 1000 armor stand marker -
  gan nang entity tracking/packet bang 1000 mob that tren viewer.
- FIX: giam cap 1000 -> 200. Item vuot cap van gop/stack binh thuong, chi
  khong hien so luong bay. Muon doi: sua hang so 200 trong updateHologram.

## Lỗi #13 - PlayerToggleManager: toggle bi mat som hon thiet ke
- TRIỆU CHỨNG: cleanup removeIf(offline) chay moi 30 phut xoa BAT KY ai
  offline -> nguoi choi toggle roi relog sau 31 phut bi reset, trai voi
  thiet ke "giu toi 30 phut SAU logout".
- FIX: Set<UUID> -> Map<UUID, thoi diem disable>. Cleanup chi xoa khi
  OFFLINE VA qua 30 phut ke tu luc disable. API public giu nguyen chu ky -
  HopperTicker/MainCommand khong can sua.

## Lỗi #14 - MainCommand: /mh stats hien thi MSPT sai gay hieu nham
- TRIỆU CHỨNG: lastTickMs la duration tick NOI BO cua plugin nhung hien thi
  nhu phan tram tick cua server.
- FIX: ghi ro "Xms (plugin - server ~Yms)" voi Y uoc luong tu Bukkit.getTPS();
  message config.yml doi thanh "ThờI gian xử lý hopper".

## Verify
- Brace balance 0 ca 4 file. Parens -3 ItemStackingManager la san co ban goc.
- disabledPlayers: 0 tham chieu con lai (doi ten toan bo sang disabledSince).
- accepted: 3 diem moi file (khai bao + add + dung) - khop voi thiet ke.

## Trang thai audit sau 3 dot patch
14/14 lỗi tu audit tong hop da duoc xu ly:
- P1: hint chunkHasItems, mob starvation, check Y, flushConfigSave busy-wait.
- P2: verifyTransfer clone/isSimilar, minecart rescan budget, foundAny,
  chunkPickupCooldowns String key, monotonicMillis trôi.
- P3: AABB overlap, hologram cap, toggle purge, stats MSPT.

# BUILD FIX v28p7-batch5-p3b (2026-09-29) - sau khi nguoi dung bao loi compile

Phat hien quan trong: ZIP GOC batch4 CHUA TUNG DUOC BIEN DICH (pom thieu
project version + 3 loi compile san co). Cac ban jar truoc day duoc build
tu nguon khac tren may tac gia. 8 loi compile khi build batch5-p3:

## Loi do patch (4)
1. DuplicationProtector: thieu `import org.bukkit.Material;` - patch P2
   verifyTransfer dung Material/EnumMap. DA THEM IMPORT.
2. MobStackingManager: patch P2 #2 dat `int start` trung voi player
   rotation trong mergeTick -> doi ten `cellStart`.
3+4. ItemStackingManager + MobStackingManager: ZIP GOC da co san 2 khai bao
   `int start` trong cung method mergeTick (javac: "already defined") ->
   doi cai cap-rotation sang `capStart` / `cellStart`.

## Loi co san tu zip goc (3)
5. MauaHopper:143: catch IllegalPluginAccessException nhung file chi import
   Bukkit + JavaPlugin -> them import org.bukkit.plugin.IllegalPluginAccessException
6. HopperTicker:3137: cast CrafterInventory + getSlotState().isEnabled() loi
   voi paper-api 1.21.11 -> doi sang REFLECTION (bien dich moi API, that bai
   = coi nhu slot ENABLED, thuan vanilla an toan).
7. pom.xml: thieu project <version> -> da them o ban truoc (4.04-v28p7-batch5-p3).

## Verify sau fix
- Brace balance 0 cho ca 5 file.
- Moi file con dung 1 khai bao int start (khai bao con lai trong comment).
- build: mvn clean package

## BUILD FIX p3c - MobStackingManager:335 (loi cuoi cung)
onMobDeath copy attribute: cast AttributeInstance truc tiep -> "cannot find
symbol" voi paper-api 1.21.11 (loi co san tu zip goc, truoc day bi che boi
loi trung bien start). Fix: copy attribute BANG REFLECTION (Class.forName
Attribute/AttributeInstance) - bien dich moi API, that bai = bo qua copy
(an toan). Day la error cuoi cung: build ve 0 loi.

## HOTFIX p3d - PerformanceOptimizer.shouldThrottle() (BUG NGHIEM TRONG)
Triệu CHỨNG: cho do vao hopper khong truyen, vứt do len hopper khong hut,
khong exception nao trong console.
NGUYÊN NHÂN: loi #18 (PATCH 2026-09-28) doi MIN -> Math.max(instant,
estimatedMspt) >= threshold. estimatedMspt o TPS 20 = 50ms >= threshold
mac dinh 35 -> shouldThrottle() TRUE VINH VIEN -> runTick return truoc
work queue + pickup sweep. Zip goc chua tung duoc compile nen bug chua tung
lo ra; jar cu build tu nguon dung MIN nen khong loi.
FIX: tach 2 dieu kien - (1) tick noi bo plugin >= threshold -> nghi;
(2) server lag theo TPS trung binh: estimatedMspt > 50 (tuc TPS < 20).
TPS 20 hoan hao khong bao gio throttle nua.

## HOTFIX p3e - Crafter retrigger: ClassCastException Directional
Triệu CHỨNG: console spam "Crafter retrigger failed" + Task failed,
ClassCastException Crafter$1 -> Directional o HopperTicker:3161 moi khi
crafter craft (paper-api 1.21.11 to chuc lai blockdata, Crafter khong con
implement Directional - cung loai API breakage voi CrafterInventory va
AttributeInstance da fix truoc).
FIX: doc facing BANG REFLECTION getFacing(); that bai = bo qua lan retrigger.
Cac cast Directional khac (hopper/dropper, dong 1101/1840/2585/2606/2639)
van hop le - cac block do van giu interface.

## HARDENING p3f - chong API breakage loai Crafter-Directional con lai
Quet toan bo source sau 3 lan loi cung mo tip (CrafterInventory,
AttributeInstance, Crafter->Directional): MỌI cho doc facing tu blockdata
(6 diem: hopper->furnace 1101, crafter-facing-hopper 1840, dropper chain
2585/2594, dropper->furnace 2606, hopper output 2639) dua ve helper
facingOf(): fast path instanceof Directional (0 chi phi duong nong),
fallback reflection getFacing(), null = bo qua an toan. Neu paper-api phien
ban nao do mat Directional o hopper/dropper/dispenser, plugin KHONG chet,
chi bo qua chu ky do.
Danh gia cac nhom con lai tren 1.21.11: Container/ShulkerBox/
AbstractFurnace/Levelled/HopperMinecart/Animals/Monster/Tameable/Ageable/
EntityType/BlockFace/PDC/NamespacedKey - on dinh, khong doi. NMS reflection
(3098-3372) da co try/catch guard. io.papermc: khong dung.

## HOTFIX p3g - truyen cham: "vai giay moi truyen 1 lan"
NGUYÊN NHÂN 1 (chinh): drainWorkQueue khong tu len lich lai khi moved==0 ->
hopper ROI KHOI TIMING WHEEL -> chi duoc full refresh don (config
full_refresh_ticks: 200 tick = 10 giay). Moi lan roi wheel = 1 batch / 10s.
Cac duong roi wheel: tryLockHopper bi giu (contention minecart), exception
giua chung, nguon tren vua rong (da co len lich noi bo nhung duong lock/
exception thi khong).
FIX 1: moved==0 -> scheduleHopperProcess(loc, idleCooldownTicks=4) - duy
tri chuoi, chi phi ~0 (tickHopperAt early-return hopper trong).
NGUYÊN NHÂN 2: duong re-queue khi het drain budget truyen cooldown =
wheelTick + 1 (thuong duoc hieu nham la "bucket tuyet doi") ->
scheduleHopperProcess clamp xuong 4095 tick ~ 204 giay.
FIX 2: doi thanh cooldown 1 tick.
NOTE: neu test o xa >128 block (require_player_radius), chunk coi "khong
active" -> backoff 20->40->80->160 tick - hay dung gan farm khi test.

## HOTFIX p3h - sua loi NGIEM TRONG cua p3g ("khong chuyen nua")
p3g them "else scheduleHopperProcess" o drainWorkQueue -> bùng nổ ban sao
hopper trong timing wheel (cap so nhan, do tickHopperAt DA tu len lich san
o 2 cho roi return 0) -> wheel ngap ban sao rong -> hopper that bi chon.
FIX 1: huy else do. FIX 2: bo sung len lich 1 tick dung cho truong hop
THUC SU roi wheel con lai: tryLockHopper that bai (contention minecart).
