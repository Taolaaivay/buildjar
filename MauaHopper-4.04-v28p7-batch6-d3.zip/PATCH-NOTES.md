# MauaHopper 4.04-fixed-PATCHED-v8 — PATCH NOTES (2026-09-26)

Nguon: MauaHopper-4.04-fixed-PATCHED.zip (da audit 100% - 9 dot, ~8750 dong)
Moi thay doi danh dau: v4.16 FIX <ma>

## 🔴 P0 - bat buoc test
- P0-1 ConfigManager.java:126 — XOA initializer dung bien local `cfg` (LOI COMPILE
  khong tim thay symbol -> plugin khong build duoc). load() van set gia tri,
  clamp dong bo: Math.max(20, ...default 40 = 2 giay).
- P0-2 BigChestManager.onClose — them `&& i < pg.length`: khong con
  ArrayIndexOutOfBounds khi doi page-size trong chests.yml roi /mh reload giua
  luc GUI dang mo (truoc day: crash handler Bukkit + mat do tren GUI).
- P0-3 BigChestManager.save() — chi `dirty = false` khi ghi file THANH CONG,
  IOException gio duoc log severe. Truoc day: 1 lan ghi loi -> dirty bi clear
  -> autosave khong bao gio retry -> MAT DU LIEU vinh vien den restart.

## 🟠 P1
- P1-4 Whitelist Rương To ap dung cho MOI duong dua do vao:
  a) onClose write-back: do khong hop le tra ve player thay vi nuot
  b) onDrag: cancel + thong bao (truoc day chi shift-click bi chan)
  c) /chests deposit: bo qua item khong hop le
- P1-5 /mh reload khong con ghi de lua chon thu cong cua admin
  (/mh off -> reload VAN tat). toggle_default_enabled chi ap dung luc khoi dong.
- P1-6 Cua so killall chi mo khi nguoi GUI LENH co quyen (op /
  essentials.killall / mauahopper.adminkill.detect). Truoc day: bat ky ai
  chat chu "killall" cung khien mob farm mat respawn 5 giay.
- P1-7 Mat khau Rương To duoc hash SHA-256 truoc khi luu (YAML + SQL).
  Tu dong migrate plaintext cu sang hash o lan load dau. BACKUP bigchests.yml
  TRUOC KHI CHAY LAN DAU.
- P1-8 onEnable: hopperTicker.start() chuyen xuong SAU khi tao xong
  itemStackingManager + mobStackingManager (het nguy co NPE tick dau).

## 🟡 P2
- P2-9  PerformanceOptimizer: cache debug.log_performance, doc config 1 lan/20
  tick thay vi moi tick.
- P2-10 PlayerToggleManager: don UUID offline moi 30 phut (het memory leak).
  HANH VI THAY DOI: toggle cua player reset khi logout.
- P2-11 DuplicationProtector.invKey: virtual inventory dung WeakHashMap+UUID
  thay identityHashCode (het false-lock sau GC).
- P2-12 Tab-complete /mh chi goi y lenh co quyen (het ro ri lenh admin).
- P2-13 Log khoi dong gio dung "Paper 1.21+" thay "Paper/Spigot".


## 🔴 v4.17 FIX BO SUNG (v3) - dupe nghiem trong
- P0-DUPE BigChestManager.destroyBigChest — doi thu tu: DONG VIEWER TRUOC khi
  bump version. Truoc day: version++ truoc -> onClose cua viewer roi nhanh
  mismatch -> tra het do GUI ve tui viewer -> sau do destroy lai drop tat ca
  pages xuong dat -> DO TRONG TRANG DANG MO BI NHAN DOI. Kich hoat: chu rương
  bam DONG Y PHA khi nguoi khac dang mo GUI, hoac TNT (break-blocks) trung
  rương dang co nguoi mo. Bay gio: dong viewer luc version con nguyen ->
  onClose ghi GUI ve pages binh thuong -> chi co 1 ban, drop dung 1 lan.
  Ca 2 caller (explosion path + confirm GUI) deu di qua ham nay nen 1 fix
  cover duong.
- Kiem chung kem theo: giveOrDrop / onPlayerPickup / onChestPlace /
  flushAndClear / onQuit — xac nhan an toan, khong phat hien van de moi.


## 🔴 v4.17 FIX BO SUNG (v4) - whitelist collector
- P1-4d BigChestManager.startCollector — them `if (!typeAllows(d.typeId, stack))
  continue;`. Truoc day collector hut MỌI item roi quanh rương nhét vào KHONG
  qua whitelist — rương whitelist bi nhoi day junk. Day la duong bypass CUỐI
  CÙNG: ca 7 diem goi insert() gio deu ton trong whitelist (hopper 1390,
  click 903, insertItem 1459, refund sellAll khong can, deposit da patch v2,
  craft output dung thiet ke).


## 🔴 v4.17 FIX BO SUNG (v5) - DUPE Rương To qua offhand
- P0-DUPE2 BigChestManager.onInteract — them
  `if (e.getHand() != EquipmentSlot.HAND) return;`. Truoc day event offhand
  cung chay nhanh dat rương: e.getItem() lay duoc item offhand nhung
  setItemInMainHand ghi vao tay CHINH -> item offhand khong bi tru =
  dupe rương vo han. Nghiem trong hon: neu tay chinh dang cam do khac,
  do tay chinh bi xoa/thay = MAT DO tay chinh. Bay gio chi main hand
  moi dat/convert duoc rương (offhand event bi bo qua ngay).
- Kiem chung kem: onChestPlace (chan rương canh Rương To - dung), 2
  handler explosion -> breakBigChest (cover TNT/creeper/wither), onMobDeath
  respawn (whitelist cause hop ly, loc ten "✖", PDC count=remaining dung,
  khong phat hien van de).


## 🟡 v4.17 FIX BO SUNG (v6) - phi sort/smelt qua settings GUI
- P2-FEE BigChestManager.handleSettingsClick — slot 14 (sort) va 22 (smelt)
  gio ton trong gia nut tuong ung trong chests.yml (truoc day mien phi du
  admin dat phi). Rieng smelt: CHI TINH TIEN KHI CO DO NUNG DUOC — dem
  truoc bang countSmeltable (cung pattern main GUI + /chests smelt), khong
  co do nung duoc thi khong tinh tien, khong nung.


## 🟡/⚪ v4.17 FIX DOT 3 (v7) - hang loat P2/P3
- P2-COMP  ConfigManager — go MUSHROOM_STEM khoi nhom 85% composter
  (vanilla = 65%, map.put() ghi de lam tang xac suat sai).
- P2-SEARCH BigChestManager.search — dung getRealAmount() thay getAmount():
  stack PDC gop 500 hien dung tong thay vi 64.
- P2-SHARE BigChestManager.handleShareChatMain — thay getOfflinePlayer(String)
  (BLOCKING tren main thread) = getPlayerExact + Paper getOfflinePlayerIfCached.
  Duong getOfflinePlayer(UUID) o dong ~1738 khong blocking nen giu nguyen.
- P3-MERGE ItemStackingManager.mergeTick — cap 1000 item/tick gio XOAY OFFSET
  moi tick (truoc day 1001+ bi bo quen mai mai khi world >1000 item).
- P2-GEARED MobStackingManager — cache protect-geared doc 1 lan/reload,
  het doc YAML trong vong O(n^2) cua isMergeableNoDist.
- P3-SHULKER ShulkerCommand — them TabCompleter on/off + dang ky trong
  MauaHopper.registerCommands (truoc day lenh khong goi y gi).
- P3-ATTRACT ItemStackingManager — clamp attract-radius MAX 16.0 (truoc day
  chi Math.max(0) khong co clamp tren: admin dat >16 -> bucket 3x3 chunk o
  attractWorld khong phu het -> item bi bo sot, hut khong deu).


## ⚪ v4.17 FIX DOT 4 (v8)
- P3-ISACTIVE MobStackingManager.onMobDeath — BO gate `isActive()` theo
  dung y comment cu: mob da stack con PDC duoc respawn phan con lai KỂ CẢ
  khi /mh off. Truoc day: admin /mh off dung luc farm chay -> mob stack
  20 con chet -> 19 con mat vinh vien — dung cai comment da noi phai tranh.

## BUILD & TEST
1. mvn clean package  (BUOC BAT BUOC - patch tay ma khong build lai thi vo nghia)
2. Test: /mh off -> /mh reload (phai VAN tat)
3. Test: dat mat khau rương -> mo lai (unlock bang hash)
4. Test: doi size trong chests.yml -> reload khi GUI dang mo (khong crash)
6. Test P0-DUPE2: cam Rương To o TAY PHU, chuot phai -> KHONG duoc dat rương
   (truoc day dat duoc va khong mat item)
5. Backup bigchests.yml truoc lan chay dau (migration password)

## Chua sua (de dot sau)
- P2: isMergeableNoDist doc config trong O(n^2) (cache protect-geared)
- P2: /chests deposit|smelt|search|settings chua co permission rieng
- P2: verifyTransfer khong lock source; composter table MUSHROOM_STEM 65%->85%
- P2: head() Paper-only cast (da fix log, chua doi code)
- P3: mergeTick starvation cap 1000 item; ~10 config key chet; dead code
  refreshHologram; MySQL params hardcode; hoppershulk thieu tab completer
