# MauaHopper 4.04-PATCHED-v21-yellow2

Bao gom red1 + orange1 + yellow batch 2.

## Yellow batch 2 fixes
- pull_ticks throttle pull container bang nextContainerPullAt.
- dispenser.fast_interval_ticks duoc dung de gioi han burst.
- Attract mob cap 50 teleports/mergeTick.
- Mob respawn copy attributes co ban, khong copy equipment de tranh duplicate drop.
- Password PBKDF2 hash async, chi ghi du lieu tren main thread.
- Cap hologram item stacking toi da 1000 armor stand.

## Ghi chu
- Maven compile/runtime test chua chay trong moi truong nay.
