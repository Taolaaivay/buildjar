package com.mauahopper;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.NamespacedKey;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Item;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.Material;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityPickupItemEvent;
import org.bukkit.event.entity.ItemMergeEvent;
import org.bukkit.event.entity.ItemSpawnEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.scheduler.BukkitTask;

import java.util.ArrayList;
import java.util.List;

/**
 * Gộp item rơi trên đất thành 1 entity (thay thế PolyStacking).
 * Số lượng thật lưu trong PDC key "mauahopper:stack_amount" (INTEGER),
 * bề mặt ItemStack chỉ hiển thị tối đa 64.
 * Tích hợp sẵn trong MauaHopper nên pickup của hopper đọc đúng số thật,
 * không còn xung đột với plugin ngoài.
 */
public class ItemStackingManager implements Listener {

    private final MauaHopper plugin;
    private final NamespacedKey stackKey;
    private BukkitTask task;

    private boolean enabled = true;
    private int maxStack = 500;
    private double radius = 4.0;
    private long interval = 20;
    // v67.25: ban kinh magnet hut item ve nhau (block, 0 = tat)
    private double attractRadius = 0.0; // v67.26: TAT mac dinh - keo item xa khoi diem thu cua farm se pha may
    // v67.9: chi quet world "ban" (co item moi spawn/merge) - tranh full-world
    // entity scan lap lai khi khong co gi thay doi (TPS tren server nhieu
    // entity). Safety scan toan bo moi 10 giay de bat item load tu chunk.
    private final java.util.Set<String> dirtyWorlds = new java.util.HashSet<>();
    private long lastIdleScanMs = 0;
    // v4.17 FIX P3-MERGE: offset xoay vong cho cap 1000 item/tick
    private long mergeRotateOffset = 0;
    private boolean initialItemScanDone = false;
    private String loreFormat = "&6Gộp: &e{amount} &6vật phẩm";
    // HIỂN THỊ: HOLOGRAM (armor stand bay trên đồ, như PolyStacking) |
    // LORE (trong mô tả item) | BOTH (cả hai) | NONE (không hiện)
    private String displayMode = "NONE";
    private String holoFormat = "&e&l{amount}x";
    // Hologram entities gắn với item (UUID item -> armor stand)
    private final java.util.Map<java.util.UUID, org.bukkit.entity.ArmorStand> holos =
            new java.util.HashMap<>();

    public ItemStackingManager(MauaHopper plugin) {
        this.plugin = plugin;
        this.stackKey = new NamespacedKey(plugin, "stack_amount");
    }

    public void start() {
        loadConfig();
        Bukkit.getPluginManager().registerEvents(this, plugin);
        task = Bukkit.getScheduler().runTaskTimer(plugin, this::mergeTick,
                interval, interval);
    }

    public void reload() {
        loadConfig();
        if (task != null) task.cancel();
        // RELOAD SAFETY: clear hologram ngay khi reload config, tranh display
        // cu ton tai them 1 tick khi admin doi HOLOGRAM/BOTH -> NONE.
        for (org.bukkit.entity.ArmorStand stand : holos.values()) {
            if (stand != null && stand.isValid()) stand.remove();
        }
        holos.clear();
        // PATCH v28p3 (loi #5): display-mode/lore-format co the doi sau
        // reload - bat buoc rewrite lore o lan toi, khong duoc dung cache cu.
        lastDisplayAmount.clear();
        task = Bukkit.getScheduler().runTaskTimer(plugin, this::mergeTick,
                interval, interval);
    }

    public void stop() {
        if (task != null) task.cancel();
        // YELLOW FIX: don hologram ngay khi plugin tat.
        for (org.bukkit.entity.ArmorStand stand : holos.values()) {
            if (stand != null && stand.isValid()) stand.remove();
        }
        holos.clear();
        lastDisplayAmount.clear();
    }

    private void loadConfig() {
        var cfg = plugin.getConfig();
        cachedLoreMarker = null;
        enabled = cfg.getBoolean("stacking.items.enabled", true);
        maxStack = Math.max(2, cfg.getInt("stacking.items.max-stack", 500));
        radius = Math.min(16.0, Math.max(0.5, cfg.getDouble("stacking.items.radius", 4.0)));
        interval = Math.max(10, cfg.getLong("stacking.items.interval", 20));
        // PATCH 2026-09-27 (loi #11): mac dinh 0.0 = TAT magnet, dung y dinh
        // v4.17 FIX P3-ATTRACT: clamp max 16 - tren 16 bucket 3x3 chunk o
        // attractWorld LO item xung quanh // v67.25 magnet
        attractRadius = Math.min(16.0, Math.max(0.0,
                cfg.getDouble("stacking.items.attract-radius", 0.0)));
        loreFormat = cfg.getString("stacking.items.lore",
                "&6Gộp: &e{amount} &6vật phẩm");
        displayMode = cfg.getString("stacking.items.display-mode", "NONE");
        holoFormat = cfg.getString("stacking.items.holo", "&e&l{amount}x");
    }

    // =====================================================================
    // API dùng bởi HopperTicker
    // =====================================================================

    /** Số lượng THẬT của item đã gộp. Trả null nếu chưa gộp. */
    /** AUDIT FIX B11: item load tu chunk khong co PDC van duoc merge voi
     *  amount hien thi; khi gop thanh stack lon se duoc setStackAmount tag. */
    private int amountOf(Item item) {
        Integer n = getStackAmount(item);
        if (n != null) return n;
        ItemStack stack = item.getItemStack();
        return Math.max(1, stack == null ? 1 : stack.getAmount());
    }

    public Integer getStackAmount(Item item) {
        if (item == null) return null;
        try {
            return item.getPersistentDataContainer().get(stackKey, PersistentDataType.INTEGER);
        } catch (Exception ex) {
            MauaHopper.fineSafe("Safe catch in ItemStackingManager", ex);
            return null;
        }
    }


    /** Cập nhật số lượng còn lại + hiển thị. amount <= 0 xóa entity. */
    public void setStackAmount(Item item, int amount) {
        try {
            if (amount <= 0) {
                removeHologram(item);
                item.remove();
                return;
            }
            item.getPersistentDataContainer().set(stackKey, PersistentDataType.INTEGER, amount);
            updateDisplay(item, amount);
        } catch (Exception ex) {
            MauaHopper.fineSafe("Safe catch in ItemStackingManager", ex);
        }
    }

    // =====================================================================
    // Hiển thị
    // =====================================================================

        private void updateDisplay(Item item, int total) {
        try {
            // PATCH v28p3 (loi #5 - TPS): farm grinder goi setStackAmount
            // rat nhieu lan trong 1 mergeTick, phan lon voi CUNG total (stack
            // lon da day, item xung quanh van duoc thu gop nhung khong doi
            // so). Rewrite lore + setItemMeta + setItemStack + broadcast
            // entity metadata cho MOI lan goi la hotspot packet/metadata.
            // Chi rewrite khi total thuc su thay doi; hologram van duoc quan
            // ly o duoi. Cache weak-key tu don khi item mat.
            Integer lastAmt = lastDisplayAmount.get(item);
            if (lastAmt != null && lastAmt == total) {
                updateHologram(item, total);
                return;
            }
            ItemStack surface = item.getItemStack();
            if (surface == null || surface.getType().isAir()) return;
            surface.setAmount(Math.min(total, 64));
            ItemMeta meta = surface.getItemMeta();
            if (meta != null) {
                // v28p6 FIX (loi #26): total <= 64 va lore CHUA CO marker ->
                // surface vanilla da hien DUNG so that, khong can rewrite
                // lore + setItemMeta + setItemStack (broadcast metadata) -
                // hotspot tren farm nem hang loat item, moi cai bi merge
                // 2 tick sau. Regex marker di duong day du cho an toan.
                if (total <= 64) {
                    String skipMarker = loreMarker();
                    if (!skipMarker.isEmpty() && !skipMarker.startsWith("REGEX:")
                            && (!meta.hasLore() || meta.getLore() == null)) {
                        item.setItemStack(surface);
                        lastDisplayAmount.put(item, total);
                        updateHologram(item, total);
                        return;
                    }
                }
                // HIỂN THỊ BẰNG LORE (không đổi tên item): dòng đầu lore là
                // số lượng thật của stack gộp, các dòng lore gốc giữ nguyên.
                // Mỗi lần update xóa dòng số lượng CŨ rồi ghi lại đầu danh
                // sách -> không bao giờ chồng lặp dù merge bao nhiêu lần.
                java.util.List<String> lore = meta.hasLore() && meta.getLore() != null
                        ? new java.util.ArrayList<>(meta.getLore())
                        : new java.util.ArrayList<>();

                // Xóa dòng số lượng cũ của chúng ta (nhận diện theo prefix
                // của loreFormat sau khi dịch màu) để tránh chồng khi merge lặp
                // Marker = phần TIỀN TỐ trước {amount} (không chứa {amount})
                // -> nhận diện được mọi dòng "Gộp: <số>..." dù số thay đổi.
                String marker = loreMarker();
                if (!marker.isEmpty()) {
                    // PATCH 2026-09-27 (loi #12-fix): marker fallback chua ma
                    // mau THO (vd "§a") thi so khop tren line THO (line.startsWith),
                    // khong strip - strip xong mat het ma mau, startsWith luon false.
                    if (marker.startsWith("REGEX:")) {
                        // PATCH check-lai vong 4: format khong mau - full-match
                        java.util.regex.Pattern p = java.util.regex.Pattern.compile(marker.substring(6));
                        lore.removeIf(line -> p.matcher(line).matches());
                    } else {
                        boolean rawMarker = marker.indexOf('§') >= 0;
                        lore.removeIf(line -> rawMarker
                                ? line.startsWith(marker)
                                : (org.bukkit.ChatColor.stripColor(line) != null
                                        && org.bukkit.ChatColor.stripColor(line).startsWith(marker)));
                    }
                }

                // Chỉ thêm lore khi display-mode là LORE hoặc BOTH
                boolean wantLore = displayMode.equalsIgnoreCase("LORE")
                        || displayMode.equalsIgnoreCase("BOTH");
                if (wantLore) {
                    String amountLine = org.bukkit.ChatColor.translateAlternateColorCodes('&',
                            loreFormat.replace("{amount}", String.valueOf(total)));
                    lore.add(0, amountLine);
                }
                if (lore.isEmpty()) meta.setLore(null);
                else meta.setLore(lore);
                surface.setItemMeta(meta);
            }
            item.setItemStack(surface);
            // PATCH v28p3 (loi #5): ghi nhan total da hien thi.
            lastDisplayAmount.put(item, total);
            updateHologram(item, total);
        } catch (Exception ex) {
            MauaHopper.fineSafe("Safe catch in ItemStackingManager", ex);
        }
    }

    /**
     * Tiền tố nhận diện dòng lore số lượng: phần format TRƯỚC {amount},
     * đã dịch màu và strip color. VD "&6Gộp: &e{amount}..." -> "Gộp: ".
     * Nếu {amount} nằm đầu format thì trả "" (không nhận diện được -> cấu
     * hình loreFormat nên để {amount} không nằm đầu).
     */
    private String cachedLoreMarker = null;

    /** PATCH v28p3 (loi #5): so luong gan nhat da hien thi tren item - tranh
     *  rewrite meta khi total khong doi. Weak key: tu don khi item bi GC.
     *  Duoc clear khi reload config (display-mode/lore-format co the doi). */
    private final java.util.Map<org.bukkit.entity.Item, Integer> lastDisplayAmount =
            java.util.Collections.synchronizedMap(new java.util.WeakHashMap<>());

    private String loreMarker() {
        if (cachedLoreMarker != null) return cachedLoreMarker;
        try {
            String translated = org.bukkit.ChatColor.translateAlternateColorCodes('&', loreFormat);
            int idx = translated.indexOf("{amount}");
            // PATCH 2026-09-27 (loi #12): idx == 0 (format bat dau bang
            // {amount}) truoc day tra "" = TAT hoan toan viec don lore cu ->
            // dong "Gộp:" chong lap khong gioi han moi lan merge. Bay gio
            // idx == 0 van duoc xu ly (substring(0,0) = ""), va marker rong
            // thi fallback ve ma mau dau tien de van nhan dien duoc dong cu.
            if (idx < 0) return "";
            String marker = idx > 0 ? org.bukkit.ChatColor.stripColor(translated.substring(0, idx)) : "";
            if (marker == null) marker = "";
            if (marker.isEmpty()) {
                // Lay day mau dau tien cua format (vd "§a{amount}x") lam marker
                int i = 0;
                while (i + 1 < translated.length() && translated.charAt(i) == '§') i += 2;
                marker = translated.substring(0, i);
                if (marker.isEmpty()) {
                    // PATCH check-lai vong 4: format KHONG mau + {amount} dau
                    // chuoi (vd "{amount}x") - khong co gi de prefix-match,
                    // ca "§f" cung khong khop line khong mau. Dung regex
                    // full-match: quote toan bo format, thay {amount} bang
                    // \\d+ - xoa DUNG dong lore cu moi truong hop con lai.
                    // Ky tu Private Use Area E000 - khong the co trong lore.
                    String ph = "\uE000";
                    String quoted = java.util.regex.Pattern.quote(
                            translated.replace("{amount}", ph));
                    marker = "REGEX:" + quoted.replace(
                            java.util.regex.Pattern.quote(ph), "\\d+");
                }
            }
            cachedLoreMarker = marker;
            return marker;
        } catch (Throwable t) {
            return "";
        }
    }

    /**
     * API public: clone stack và xóa mọi dấu vết hiển thị stack gộp
     * (display name + dòng lore số lượng). Dùng khi nhặt vào túi/rương.
     */
    public ItemStack stripStackVisuals(ItemStack stack) {
        return stripDisplayName(stack);
    }

    /** Clone stack và xóa mọi dấu vết hiển thị stack (display name + dòng
     * lore số lượng) - dùng để so sánh 2 item công bằng và để nhặt đồ sạch.
     * Nếu chỉ xóa tên mà giữ lore thì isSimilar vẫn so sánh lore "Gộp: 128"
     * vs "Gộp: 64" -> khác nhau -> kẹt merge (cùng bug trước đây). */
    private ItemStack stripDisplayName(ItemStack stack) {
        ItemStack copy = stack.clone();
        ItemMeta meta = copy.getItemMeta();
        if (meta != null) {
            // PATCH 2026-09-27 (loi #22): KHONG xoa display name nua. He gop
            // CHI them lore + hologram, KHONG dat ten hien thi - viec xoa ten
            // vo dieu kien lam do doi ten bang de ("Kiếm của Vua", gift...)
            // bi mat ten khi nhac/collector cho vao rương/tui.
            // CRITICAL - XÓA PDC stack_amount: nếu để lại, item vào túi/
            // rương vẫn mang PDC số thật (vd 576). Khi vứt ra đất/phá rương,
            // onItemSpawn thấy PDC tồn tại -> giữ 576 trong khi surface chỉ
            // 64 -> hopper nhặt 576 từ 64 vật phẩm = DUP 9x.
            meta.getPersistentDataContainer().remove(stackKey);
            String marker = loreMarker();
            if (meta.hasLore() && meta.getLore() != null && !marker.isEmpty()) {
                java.util.List<String> lore = new java.util.ArrayList<>(meta.getLore());
                // PATCH 2026-09-27 (loi #12-fix): tuong tu updateDisplay -
                // marker ma mau tho thi so khop tren line tho.
                if (marker.startsWith("REGEX:")) {
                    java.util.regex.Pattern p2 = java.util.regex.Pattern.compile(marker.substring(6));
                    lore.removeIf(line -> p2.matcher(line).matches());
                } else {
                    boolean rawMarker2 = marker.indexOf('§') >= 0;
                    lore.removeIf(line -> rawMarker2
                            ? line.startsWith(marker)
                            : (org.bukkit.ChatColor.stripColor(line) != null
                                    && org.bukkit.ChatColor.stripColor(line).startsWith(marker)));
                }
                if (lore.isEmpty()) meta.setLore(null);
                else meta.setLore(lore);
            }
            copy.setItemMeta(meta);
        }
        return copy;
    }



    // =====================================================================
    // Events
    // =====================================================================

    // LOWEST = chạy ĐẦU TIÊN: gắn PDC trước khi HopperTicker.onItemSpawn
    // (NORMAL) kịp nhặt - nếu không item bị nhặt khi chưa có PDC -> mất
    // phần gộp. Đây là race condition quan trọng nhất của bản tích hợp.
    // v67.25: chunk load -> danh dau world ban de gop ngay cho do cu
    @EventHandler
    public void onChunkLoadItems(org.bukkit.event.world.ChunkLoadEvent e) {
        if (!enabled || !plugin.isActive()) return;
        if (!plugin.getWorldManager().isWorldAllowed(e.getWorld())) return;
        dirtyWorlds.add(e.getWorld().getName());
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onItemSpawn(ItemSpawnEvent e) {
        if (!enabled || !plugin.isActive()) return; // v67.8: dong bo global toggle
        Item item = e.getEntity();
        dirtyWorlds.add(item.getWorld().getName()); // v67.9
        int amount = item.getItemStack().getAmount();
        if (amount <= 0) return;
        // Phòng thủ dupe: PDC tồn tại nhưng khác surface (đồ cũ PolyStacking,
        // plugin khác gắn, item túi bị lọt PDC...) -> resync về surface.
        Integer existing = getStackAmount(item);
        if (existing != null) {
            // FIX B7 (audit 2026-09): chi resync khi la DAU HIEU PDC RAC:
            //  - existing < amount : ledger nho hon surface (corrupt / plugin
            //    khac ghi de len)
            //  - existing > cap    : ledger vo ly lon (PDC rac tu nguon cu)
            // Ledger HOP LE (existing > amount - duong hopper -> container ->
            // vo roi container bi pha) phai GIU nguyen: resync ve surface an
            // mat phan gop (vd. surface 64 / PDC 500 -> con 64, MAT 436).
            // p8 FIX: cap phai ke ca CONFIG max-stack (1000 sau tune) -
            // truoc day chi dung vanilla maxStackSize=64 -> cap 128, stack
            // hop le PDC 500+ bi reset ve 64 = MAT ĐỒ khi entity respawn.
            int cap = Math.max(64, Math.max(item.getItemStack().getMaxStackSize(), maxStack)) * 2;
            if (existing < amount || existing > cap) {
                setStackAmount(item, amount);
            } else if (item.getItemStack().getAmount() != Math.min(64, existing)) {
                // ledger hop le nhung surface lech (hiem): chuan hoa lai
                // hien thi + PDC, khong mat so.
                setStackAmount(item, existing);
            }
            return;
        }
        try {
            item.getPersistentDataContainer().set(stackKey, PersistentDataType.INTEGER, amount);
            updateDisplay(item, amount);
        } catch (Exception ex) {
            MauaHopper.fineSafe("Safe catch in ItemStackingManager", ex);
        }
    }

    /** Chặn vanilla merge tự nhiên - merge gây sai số với PDC, để task của ta gộp. */
    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onItemMerge(ItemMergeEvent e) {
        if (!enabled || !plugin.isActive()) return; // v67.8: dong bo global toggle
        dirtyWorlds.add(e.getEntity().getWorld().getName()); // v67.9
        if (getStackAmount(e.getEntity()) != null || getStackAmount(e.getTarget()) != null) {
            e.setCancelled(true);
        }
    }

    /**
     * Player nhặt item đã gộp: cho ĐỦ số thật vào túi, cập nhật/clear entity.
     */
    // PATCH 2026-09-28 (loi #30 - NGHĨEM TRỌNG): 2 annotation @EventHandler
    // bi xep chong len onQuit (compile error duplicate annotation) va lam
    // onPlayerPickup MAT @EventHandler -> handler nhặt item gộp KHÔNG BAO
    // GIO duoc dang ky -> player nhặt item gộp bi mat phan tu vanilla.
    @EventHandler
    public void onQuit(org.bukkit.event.player.PlayerQuitEvent e) {
        expandNextAt.remove(e.getPlayer().getUniqueId());
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onPlayerPickup(EntityPickupItemEvent e) {
        // v4.04 FIX: khong gate bang `enabled` nua - item da gop tren dat van
        // con PDC; vanilla chi cho 64 surface roi xoa entity = mat phan gop.
        if (!plugin.isActive()) return;
        // Chỉ xử lý player nhặt - hopper pickup đã được HopperTicker cancel
        // và xử lý riêng, nếu đụng vào sẽ double pickup.
        if (!(e.getEntity() instanceof org.bukkit.entity.Player)) return;
        Item item = e.getItem();
        Integer total = getStackAmount(item);
        if (total == null) return;

        e.setCancelled(true); // chúng ta tự cho đồ

        ItemStack give = stripDisplayName(item.getItemStack());
        give.setAmount(total);
        // getEntity() trả LivingEntity (không có getInventory) - phải cast
        // sang Player vì đã check instanceof Player ở trên.
        org.bukkit.entity.Player player = (org.bukkit.entity.Player) e.getEntity();
        java.util.Map<Integer, ItemStack> leftover =
                player.getInventory().addItem(give);
        // v28p6 FIX (loi #29): thay stream bang vong lap - dung pattern da
        // toi uu o cac cho khac, cat alloc IntStream moi lan pickup.
        int left = 0;
        for (ItemStack ls : leftover.values()) left += ls.getAmount();
        int added = total - (leftover.isEmpty() ? 0 : left);

        if (added <= 0) return;

        int remaining = total - added;
        if (remaining <= 0) {
            removeHologram(item);
            item.remove();
        } else {
            setStackAmount(item, remaining);
        }
    }

    // =====================================================================
    // FIX DUPE (v40): PDC stack lọt vào TÚI PLAYER qua shift-click/click/drag
    // (đường chest -> inventory không qua pickup handler nào). Khi phát hiện
    // trong túi, MỞ RỘNG về số thật ngay: điền đủ slot 64, dư rơi ra đất.
    // Không để PDC sót trong túi -> ném vào hopper không thể dup.
    // =====================================================================

    /** Đọc số lượng gộp từ PDC của một ItemStack (không phải Item entity). */
    private Integer getStackAmountFromStack(ItemStack stack) {
        try {
            if (stack == null) return null;
            ItemMeta meta = stack.getItemMeta();
            if (meta == null) return null;
            return meta.getPersistentDataContainer().get(stackKey,
                    org.bukkit.persistence.PersistentDataType.INTEGER);
        } catch (Exception ex) {
            MauaHopper.fineSafe("Safe catch in ItemStackingManager", ex);
            return null;
        }
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onInventoryClick(InventoryClickEvent e) {
        if (!enabled || !plugin.isActive()) return; // v67.8: dong bo global toggle
        if (!(e.getWhoClicked() instanceof org.bukkit.entity.Player)) return;
        scheduleInvExpand((org.bukkit.entity.Player) e.getWhoClicked());
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onInventoryDrag(InventoryDragEvent e) {
        if (!enabled || !plugin.isActive()) return; // v67.8: dong bo global toggle
        if (!(e.getWhoClicked() instanceof org.bukkit.entity.Player)) return;
        scheduleInvExpand((org.bukkit.entity.Player) e.getWhoClicked());
    }

    private final java.util.Set<java.util.UUID> expandPending =
            java.util.concurrent.ConcurrentHashMap.newKeySet();
    private final java.util.Map<java.util.UUID, Long> expandNextAt = new java.util.HashMap<>();
    private int playerScanOffset;

    private void scheduleInvExpand(org.bukkit.entity.Player player) {
        long now = System.currentTimeMillis();
        if (now < expandNextAt.getOrDefault(player.getUniqueId(), 0L)) return;
        expandNextAt.put(player.getUniqueId(), now + 250L);
        if (!expandPending.add(player.getUniqueId())) return;
        org.bukkit.Bukkit.getScheduler().runTask(plugin, () -> {
            expandPending.remove(player.getUniqueId());
            try { expandStackedInInventory(player); } catch (Exception ex) { MauaHopper.warnSafe("ItemStacking expand inventory failed for " + player.getName(), ex); }
        });
    }

    /** Quét túi player: mọi stack có PDC đều trải phẳng thành số thật. */
    private void expandStackedInInventory(org.bukkit.entity.Player player) {
        org.bukkit.inventory.PlayerInventory inv = player.getInventory();
        // Chỉ quét 36 slot chính (main inv + hotbar), không đụng armor/offhand
        for (int slot = 0; slot < 36; slot++) {
            ItemStack stack = inv.getItem(slot);
            if (stack == null || stack.getType().isAir()) continue;
            Integer total = getStackAmountFromStack(stack);
            if (total == null || total <= stack.getAmount()) continue;

            ItemStack clean = stripDisplayName(stack);
            int remaining = total;
            inv.setItem(slot, null);

            // 1) Gộp vào slot cùng loại còn chỗ
            for (int s2 = 0; s2 < 36 && remaining > 0; s2++) {
                ItemStack cur = inv.getItem(s2);
                if (cur == null || cur.getType().isAir()) continue;
                if (!cur.isSimilar(clean)) continue;
                int space = cur.getMaxStackSize() - cur.getAmount();
                if (space <= 0) continue;
                int give = Math.min(space, remaining);
                cur.setAmount(cur.getAmount() + give);
                inv.setItem(s2, cur);
                remaining -= give;
            }
            // 2) Điền slot trống
            for (int s2 = 0; s2 < 36 && remaining > 0; s2++) {
                ItemStack cur = inv.getItem(s2);
                if (cur != null && cur.getType() != Material.AIR) continue;
                int give = Math.min(64, remaining);
                ItemStack fill = clean.clone();
                fill.setAmount(give);
                inv.setItem(s2, fill);
                remaining -= give;
            }
            // 3) Dư nữa: rơi ra đất (ItemSpawnEvent sẽ tag lại chuẩn)
            while (remaining > 0) {
                int give = Math.min(64, remaining);
                ItemStack drop = clean.clone();
                drop.setAmount(give);
                player.getWorld().dropItemNaturally(player.getLocation(), drop);
                remaining -= give;
            }
        }

        // FIX C4: quet ca OFFHAND (slot 40) - PDC stack lot tay phu (doi tay
        // bang F) se song sot mai neu khong don. Cung pattern: gop -> dien
        // slot trong -> rot du ra dat.
        try {
            ItemStack off = inv.getItem(40);
            if (off != null && !off.getType().isAir()) {
                Integer oTotal = getStackAmountFromStack(off);
                if (oTotal != null && oTotal > off.getAmount()) {
                    inv.setItem(40, null);
                    int remaining = oTotal;
                    ItemStack clean = stripDisplayName(off);
                    for (int s2 = 0; s2 < 36 && remaining > 0; s2++) {
                        ItemStack cur = inv.getItem(s2);
                        if (cur == null || cur.getType().isAir()) continue;
                        if (!cur.isSimilar(clean)) continue;
                        int space = cur.getMaxStackSize() - cur.getAmount();
                        if (space <= 0) continue;
                        int give = Math.min(space, remaining);
                        cur.setAmount(cur.getAmount() + give);
                        inv.setItem(s2, cur);
                        remaining -= give;
                    }
                    for (int s2 = 0; s2 < 36 && remaining > 0; s2++) {
                        ItemStack cur = inv.getItem(s2);
                        if (cur != null && cur.getType() != Material.AIR) continue;
                        int give = Math.min(64, remaining);
                        ItemStack fill = clean.clone();
                        fill.setAmount(give);
                        inv.setItem(s2, fill);
                        remaining -= give;
                    }
                    while (remaining > 0) {
                        int give = Math.min(64, remaining);
                        ItemStack drop = clean.clone();
                        drop.setAmount(give);
                        player.getWorld().dropItemNaturally(player.getLocation(), drop);
                        remaining -= give;
                    }
                }
            }
        } catch (Exception ex) { MauaHopper.fineSafe("Safe catch in ItemStackingManager", ex); }
        // Cursor cũng quét
        try {
            ItemStack cursor = player.getItemOnCursor();
            Integer cTotal = getStackAmountFromStack(cursor);
            if (cTotal != null && cTotal > cursor.getAmount()) {
                player.setItemOnCursor(null);
                int remaining = cTotal;
                ItemStack cleanCursor = stripDisplayName(cursor);
                for (int s2 = 0; s2 < 36 && remaining > 0; s2++) {
                    ItemStack cur = inv.getItem(s2);
                    if (cur != null && cur.getType() != Material.AIR) {
                        // p9 FIX: gop vao stack cung loai con cho TRUOC khi
                        // bo qua - truoc day chi dien slot trong nen phan du
                        // bi drop du inventory van gop duoc (mat do ao).
                        if (cur.isSimilar(cleanCursor) && cur.getAmount() < 64) {
                            int can = Math.min(64 - cur.getAmount(), remaining);
                            if (can > 0) {
                                ItemStack merged = cur.clone();
                                merged.setAmount(cur.getAmount() + can);
                                inv.setItem(s2, merged);
                                remaining -= can;
                            }
                        }
                        continue;
                    }
                    int give = Math.min(64, remaining);
                    ItemStack fill = cleanCursor.clone();
                    fill.setAmount(give);
                    inv.setItem(s2, fill);
                    remaining -= give;
                }
                while (remaining > 0) {
                    int give = Math.min(64, remaining);
                    ItemStack drop = stripDisplayName(cursor);
                    drop.setAmount(give);
                    player.getWorld().dropItemNaturally(player.getLocation(), drop);
                    remaining -= give;
                }
            }
        } catch (Exception ex) {
            MauaHopper.fineSafe("Safe catch in ItemStackingManager", ex);
        }
    }

    // =====================================================================
    // Merge task
    // =====================================================================

    private void mergeTick() {
        if (plugin.isShuttingDown()) return;
        cleanupHolograms();
        if (!enabled || !plugin.isActive()) return;

        long nowMs = System.currentTimeMillis();
        boolean idleScan = !initialItemScanDone || (nowMs - lastIdleScanMs >= 10000L);
        if (idleScan) {
            initialItemScanDone = true;
            lastIdleScanMs = nowMs;
        }

        for (org.bukkit.World world : Bukkit.getWorlds()) {
            // Chỉ quét world được plugin quản lý - tránh tốn CPU ở world vô hình
            if (!plugin.getWorldManager().isWorldAllowed(world)) continue;
            // v67.9: bo qua world khong co item moi (tru dot safety scan)
            String wn = world.getName();
            if (!idleScan && !dirtyWorlds.contains(wn)) continue;
            dirtyWorlds.remove(wn);
            List<Item> all = new ArrayList<>();
            // CAM FIX: idle safety scan cung chi quet quanh nguoi choi. Khong
            // con world.getEntitiesByClass() toan world; world khong nguoi thi bo.
            double scanR = Math.max(32.0, Math.max(radius, attractRadius) + 8.0);
            java.util.Set<java.util.UUID> seen = new java.util.HashSet<>();
            // AUDIT FIX P9: xoay vong toi da 5 player/mergeTick thay vi quet
            // toan bo online list cung luc, giam so AABB query dang ke.
            java.util.List<org.bukkit.entity.Player> players = world.getPlayers();
            int start = players.isEmpty() ? 0 : playerScanOffset % players.size();
            int count = Math.min(5, players.size());
            playerScanOffset = players.isEmpty() ? 0 : (start + count) % players.size();
            // PATCH v28p7-batch5-P3 (loi #11 - TPS): bo qua player dung trong
            // vung scanR cua player da duoc quet - seen set truoc day chi
            // dedupe KET QUA, query AABB box lon (65x128x65) van chay chong
            // lap cho 5 nguoi dung gan nhau. Bay gio query that bong khong
            // chong lap, seen set giu nguyen vai tro loc item trung.
            java.util.List<org.bukkit.Location> accepted = new java.util.ArrayList<>();
            double scanR2 = scanR * scanR;
            for (int pi = 0; pi < count; pi++) {
                org.bukkit.entity.Player p = players.get((start + pi) % players.size());
                org.bukkit.Location pl = p.getLocation();
                boolean overlap = false;
                for (org.bukkit.Location q : accepted) {
                    double ddx = pl.getX() - q.getX();
                    double ddz = pl.getZ() - q.getZ();
                    if (ddx * ddx + ddz * ddz < scanR2) { overlap = true; break; }
                }
                if (overlap) continue;
                accepted.add(pl);
                for (Entity entity : world.getNearbyEntities(pl, scanR, 64, scanR,
                        en -> en instanceof Item)) {
                    if (seen.add(entity.getUniqueId()) && entity.isValid() && !entity.isDead()) {
                        all.add((Item) entity);
                    }
                }
            }
            // v4.17 FIX P3-MERGE: cap 1000 nhung XOAY OFFSET moi tick. Truoc day
            // break o 1000 dau tien -> world co >1000 item thi 1000 sau BI BO
            // QUEN mai mai (starvation), khong bao gio duoc gop/hien thi.
            List<Item> items = all;
            if (all.size() > 1000) {
                // PATCH v28p7-batch5-P3b (build fix): doi ten start -> capStart
                // (trung ten voi int start cua player rotation o tren, javac
                // bao "already defined"; loi co san tu zip goc, zip goc chua
                // tung duoc bien dich).
                int capStart = (int) ((mergeRotateOffset += 997) % all.size());
                items = new ArrayList<>(1000);
                for (int k = 0; k < 1000; k++) items.add(all.get((capStart + k) % all.size()));
            }
            if (items.size() < 2) continue;
            mergeWorld(items);
            // v67.25: MAGNET - item cung loai trong attractRadius hut ve nhau
            // truoc khi du mergeRadius gop. Lam item roi rac tu farm tu hoi tu.
            attractWorld(items);
        }
    }

    /**
     * Magnet hut item cung loai ve nhau trong attractRadius (block).
     * Chi ap velocity, khong teleport - an toan voi vat ly. Chi hut khi
     * 2 stack gop lai khong vuot maxStack va item tuong tu (isSimilar).
     */
    private void attractWorld(List<Item> items) {
        if (attractRadius <= 0) return;
        double r2 = attractRadius * attractRadius;
        // FIX TPS 2026-09-28: pre-tinh stack-amount (DOC PDC - dat) va
        // location (alloc object) cho tung item DUNG 1 LAN. Truoc day
        // getStackAmount(b) + getLocation() chay lai cho MOI CAP a-b trong
        // vong nearest-search - O(n^2) PDC read tren farm dong item.
        java.util.Map<Item, Integer> amounts = new java.util.IdentityHashMap<>();
        java.util.Map<Item, org.bukkit.Location> itemLocs = new java.util.IdentityHashMap<>();
        // FIX 2026-09-28 (loi #15 - TPS): bucket key String "cx,cz" ->
        // packed long. Truoc day: 1 string concat cho MOI item + 9 string
        // concat cho moi item khi lookup 3x3 lang gieng + split()/parseInt
        // cho moi bucket. Bay gio toan bo 0 string alloc.
        java.util.Map<Long, List<Item>> buckets = new java.util.HashMap<>();
        for (Item item : items) {
            if (!item.isValid() || item.isDead()) continue;
            Integer amt = getStackAmount(item);
            if (amt == null) continue;
            org.bukkit.Location loc = item.getLocation();
            amounts.put(item, amt);
            itemLocs.put(item, loc);
            long key = ((long)(loc.getBlockX() >> 4) & 0x7fffffffL)
                    | (((long)(loc.getBlockZ() >> 4) & 0x7fffffffL) << 31);
            buckets.computeIfAbsent(key, k -> new java.util.ArrayList<>()).add(item);
        }
        // FIX (loi #15): entry Long-key - bo split()/parseInt
        for (java.util.Map.Entry<Long, List<Item>> entry : buckets.entrySet()) {
            int cx = (int)(entry.getKey() & 0x7fffffffL);
            int cz = (int)((entry.getKey() >> 31) & 0x7fffffffL);
            for (Item a : entry.getValue()) {
                if (!a.isValid() || a.isDead()) continue;
                Integer amtA = amounts.get(a); // da pre-tinh o tren
                if (amtA == null) continue;
                // FIX C3: stack da DAY thi khong the gop them -> khong can
                // keo (magnet vo tinh tap hop rac quanh farm neu bo qua).
                if (amtA >= maxStack) continue;
                Item nearest = null;
                double nearestD = r2;
                // quet 3x3 chunk lan can (attractRadius <= 16 an toan trong 3x3)
                for (int dx = -1; dx <= 1; dx++) {
                    for (int dz = -1; dz <= 1; dz++) {
                        List<Item> cand = buckets.get(((long)(cx + dx) & 0x7fffffffL)
                                | (((long)(cz + dz) & 0x7fffffffL) << 31));
                        if (cand == null) continue;
                        for (Item b : cand) {
                            if (b == a || !b.isValid() || b.isDead()) continue;
                            Integer amtB = amounts.get(b); // da pre-tinh o tren
                            if (amtB == null) continue;
                            // PATCH v28p3 (loi #4 - TPS): check KHOANG CACH
                            // TRUOC isSimilar. distanceSquared tren Location
                            // sanh re; isSimilar so meta dat. Tren farm dong
                            // item, phan lon candidate bi loai bo boi khoang
                            // cach - cu moi cap deu chay isSimilar la lang phi
                            // hang trieu lan so meta moi merge tick. Ket qua
                            // nearest KHONG doi (van la mergeable gan nhat
                            // trong r2), chi doi thu tu loai bo som.
                            double d = itemLocs.get(a).distanceSquared(itemLocs.get(b));
                            if (d >= nearestD) continue;
                            if (amtA + amtB > maxStack) continue;
                            // p9 FIX: dung isMergeable (strip display
                            // name ca hai phia) - truoc day raw isSimilar
                            // luon false voi stack da hien thi so luong ->
                            // magnet bo qua dung stack can hut.
                            if (!isMergeable(a, b)) continue;
                            nearestD = d; nearest = b;
                        }
                    }
                }
                if (nearest != null) {
                    // PATCH 2026-09-29 (batch 4, loi #C): 5 alloc (2x
                    // getLocation + 2x toVector + subtract) cho moi item bi
                    // hut moi mergeTick. Toa do primitive - chi con 1 alloc
                    // (Vector bat buoc cho setVelocity).
                    org.bukkit.util.Vector dir = new org.bukkit.util.Vector(
                            nearest.getX() - a.getX(), nearest.getY() - a.getY(), nearest.getZ() - a.getZ());
                    if (dir.lengthSquared() > 0.04) {
                        dir.normalize().multiply(0.25);
                        dir.setY(0.18);
                        a.setVelocity(dir);
                    }
                }
            }
        }
    }

    private void mergeWorld(List<Item> items) {
        // Bucket theo chunk: radius gộp 4 block << 16 block/chunk nên item
        // chỉ có thể gộp với item trong cùng chunk hoặc chunk kề (9 ô vuông).
        // Giảm từ O(n^2) toàn cục xuống O(k) với k = item trong vùng lân cận.
        // v28p6 FIX (loi #25): key packed-long thay string "cx,cz" - 0 alloc
        // string cho moi item moi merge tick, decode O(1) khong split/parseInt.
        java.util.Map<Long, List<Item>> buckets = new java.util.HashMap<>();
        for (Item item : items) {
            if (!item.isValid() || item.isDead()) continue;
            org.bukkit.Location loc = item.getLocation();
            long key = (((long) (loc.getBlockX() >> 4)) << 32) | ((loc.getBlockZ() >> 4) & 0xffffffffL);
            buckets.computeIfAbsent(key, k -> new ArrayList<>()).add(item);
        }
        // Gộp trong từng bucket
        for (List<Item> bucket : buckets.values()) {
            mergeBucket(bucket);
        }
        // Gộp qua biên chunk: với mỗi bucket, thử 3 hướng láng giềng
        // (đông, đông-nam, nam) để không xử lý cặp trùng 2 lần. isMergeable
        // vẫn check khoảng cách thật nên an toàn tuyệt đối.
        for (java.util.Map.Entry<Long, List<Item>> entry : buckets.entrySet()) {
            long key = entry.getKey();
            int cx = (int) (key >> 32);
            int cz = (int) key;
            mergeCross(buckets, entry.getValue(), cx + 1, cz);
            mergeCross(buckets, entry.getValue(), cx + 1, cz + 1);
            mergeCross(buckets, entry.getValue(), cx, cz + 1);
        }
    }

    private void mergeCross(java.util.Map<Long, List<Item>> buckets,
                            List<Item> source, int cx, int cz) {
        // v28p6 FIX (loi #25): pack key nhu mergeWorld - bo string concat
        // + hash string cho moi cap lang gieng.
        List<Item> target = buckets.get((((long) cx) << 32) | (cz & 0xffffffffL));
        if (target == null) return;
        // PATCH v28p3 (loi #13 - TPS): amountOf doc PDC cua item (DAT) -
        // truoc day doc LAI cho MOI CAP (i,j) qua bien chunk. Pre-tinh 1
        // lan cho ca 2 list; map DUOC REFRESH sau moi setStackAmount (ben
        // duoi) nen so luong luon chuan, khong overfill qua maxStack.
        java.util.Map<Item, Integer> amts = new java.util.IdentityHashMap<>();
        for (Item it : source) amts.put(it, amountOf(it));
        for (Item it : target) amts.put(it, amountOf(it));
        for (int i = 0; i < source.size(); i++) {
            Item a = source.get(i);
            if (!a.isValid() || a.isDead()) continue;
            int amtA = amts.get(a);
            for (int j = 0; j < target.size(); j++) {
                Item b = target.get(j);
                if (!b.isValid() || b.isDead()) continue;
                int amtB = amts.get(b);
                if (!isMergeable(a, b)) continue;
                // v67.79: dong nhu voi mergeBucket - stack LON song sot
                int bigAmt = Math.max(amtA, amtB);
                int smallAmt = Math.min(amtA, amtB);
                Item big = amtA >= amtB ? a : b;
                Item small = amtA >= amtB ? b : a;
                int space = maxStack - bigAmt;
                if (space <= 0) { if (big == a) break; else continue; }
                int move = Math.min(space, smallAmt);
                setStackAmount(big, bigAmt + move);
                amts.put(big, bigAmt + move); // PATCH v28p3: refresh cache PDC
                int left = smallAmt - move;
                if (left <= 0) { removeHologram(small); small.remove(); }
                else { setStackAmount(small, left); amts.put(small, left); }
                amtA = (big == a) ? bigAmt + move : left;
                if (amtA <= 0 || amtA >= maxStack) break;
            }
        }
    }

    private void mergeBucket(List<Item> items) {
        // PATCH 2026-09-28 (loi #28 - TPS): amountOf() doc PDC cua item (DAT)
        // - truoc day bi goi lai cho MOI CAP (i,j), farm 300-500 item trong
        // chunk = hang chuc nghin lan doc PDC moi merge tick. Pre-compute 1
        // lan cho tat ca item (dung pattern da fix o mergeCross loi #13).
        java.util.IdentityHashMap<Item, Integer> amts = new java.util.IdentityHashMap<>();
        for (Item it : items) amts.put(it, amountOf(it));

        for (int i = 0; i < items.size(); i++) {
            Item target = items.get(i);
            if (!target.isValid() || target.isDead()) continue;
            int targetAmt = amts.get(target);

            for (int j = i + 1; j < items.size(); j++) {
                Item source = items.get(j);
                if (!source.isValid() || source.isDead()) continue;
                int sourceAmt = amts.get(source);

                if (!isMergeable(target, source)) continue;

                // v67.26 GON HON: stack NHO HON luon bi gop vao stack LON HON.
                // Stack lon giu nguyen vi tri - do farm roi xuong quanh 1 diem
                // thu thi diem thu khong bi day di dau ca.
                int bigAmt = Math.max(targetAmt, sourceAmt);
                int smallAmt = Math.min(targetAmt, sourceAmt);
                Item big    = targetAmt >= sourceAmt ? target : source;
                Item small  = targetAmt >= sourceAmt ? source : target;

                int space = maxStack - bigAmt;
                if (space <= 0) break;
                int move = Math.min(space, smallAmt);

                setStackAmount(big, bigAmt + move);
                amts.put(big, bigAmt + move);
                int smallLeft = smallAmt - move;
                if (smallLeft <= 0) {
                    removeHologram(small);
                    small.remove();
                } else {
                    setStackAmount(small, smallLeft);
                    amts.put(small, smallLeft);
                }

                // cap nhat so luong con lai cua target cho vong trong
                if (big == target) {
                    targetAmt = bigAmt + move;
                    if (targetAmt >= maxStack) break;
                } else {
                    // target la stack nho, co the da bi xoa het hoac con lai
                    targetAmt = smallLeft;
                    if (targetAmt <= 0) break; // target da bi gop sach
                }
            }
        }
    }

    private boolean isMergeable(Item a, Item b) {
        ItemStack sa = a.getItemStack();
        ItemStack sb = b.getItemStack();
        if (sa == null || sb == null) return false;
        if (sa.getType() != sb.getType()) return false;
        // DISTANCE check TRƯỚC (rẻ) - loại bỏ đa số cặp ngay, tránh gọi
        // stripDisplayName (đắt: clone + xử lý meta/lore) cho item cách xa.
        // Farm 300 item cùng loại trong chunk: giảm ~90% clone vô ích mỗi tick.
        Location la = a.getLocation();
        Location lb = b.getLocation();
        if (la.getWorld() != lb.getWorld()) return false;
        double dx = la.getX() - lb.getX();
        double dz = la.getZ() - lb.getZ();
        // PATCH v28p7-batch5 (loi #3): them check Y - truoc day chi check
        // XZ nen 2 item o 2 TANG farm chong len nhau bi gop xuyen san
        // (item tren tang duoi bien mat, hien thi nhay len tang tren).
        // Y tolerance CLAMP 2.0 (khong dung full radius): item roi tu hopper/
        // attract giu gan muc dat; tang farm cach nhau >= 3-4 block nen 2.0
        // chan gop xuyen tang ma khong anh huong merge binh thuong.
        double dy = la.getY() - lb.getY();
        double rXZ = radius, rY = Math.min(radius, 2.0);
        if ((dx * dx + dz * dz) > (rXZ * rXZ)) return false;
        if (dy * dy > rY * rY) return false;

        // So sánh thuộc tính thật bỏ qua dấu vết hiển thị stack (tên/lore
        // có số lượng) - nếu không strip thì isSimilar luôn false -> kẹt merge.
        return stripDisplayName(sa).isSimilar(stripDisplayName(sb));
    }

    // =====================================================================
    // HOLOGRAM - armor stand bay trên item gộp (kiểu PolyStacking)
    // =====================================================================

    /** Spawn hoặc cập nhật hologram hiển thị số lượng trên item. */
    private void updateHologram(Item item, int total) {
        try {
            boolean wantHolo = total > 1
                    && (displayMode.equalsIgnoreCase("HOLOGRAM")
                        || displayMode.equalsIgnoreCase("BOTH"));
            org.bukkit.entity.ArmorStand holo = holos.get(item.getUniqueId());
            if (!wantHolo) {
                if (holo != null) { holo.remove(); holos.remove(item.getUniqueId()); }
                return;
            }
            if (holo != null && !holo.isValid()) {
                holos.remove(item.getUniqueId());
                holo = null;
            }
            if (holo == null) {
                // YELLOW FIX: cap hologram entity khi dung HOLOGRAM/BOTH.
                // PATCH v28p7-batch5-P3 (loi #12 - TPS): giam 1000 -> 200.
                // 1000 armor stand marker = gan nang entity tracking/packet
                // bang 1000 mob that - huy hoai TPS viewer farm. 200 holo
                // du cho man hinh 1 nguoi choi; item vuot cap van gop/stack
                // binh thuong, chi khong hien so luong bay.
                if (holos.size() >= 200) return;
                org.bukkit.Location loc = item.getLocation().add(0, 0.25, 0);
                holo = (org.bukkit.entity.ArmorStand) item.getWorld().spawnEntity(
                        loc, org.bukkit.entity.EntityType.ARMOR_STAND);
                holo.setVisible(false);
                holo.setGravity(false);
                holo.setMarker(true);
                holo.setInvulnerable(true);
                holo.setCustomNameVisible(true);
                holo.setSilent(true);
                holo.setSmall(true);
                // CRITICAL: không lưu armor stand vào world save - nếu lưu,
                // restart server sẽ để lại hologram mồ côi vĩnh viễn (item
                // chủ đã mất, cleanup không tìm được).
                holo.setPersistent(false);
                item.addPassenger(holo);
                holos.put(item.getUniqueId(), holo);
            }
            String name = org.bukkit.ChatColor.translateAlternateColorCodes('&',
                    holoFormat.replace("{amount}", String.valueOf(total)));
            // PATCH v28p3 (loi #5): setCustomName moi lan goi = gui lai
            // entity metadata packet cho moi viewer. getCustomName sanh re
            // (nam san trong memory) - chi gui khi ten thay doi.
            if (!name.equals(holo.getCustomName())) holo.setCustomName(name);
        } catch (Exception ex) {
            MauaHopper.fineSafe("Safe catch in ItemStackingManager", ex);
        }
    }

    /** Xóa hologram của item (khi item hết/không còn gộp). */
    private void removeHologram(Item item) {
        try {
            org.bukkit.entity.ArmorStand holo = holos.remove(item.getUniqueId());
            if (holo != null) holo.remove();
        } catch (Exception ex) {
            MauaHopper.fineSafe("Safe catch in ItemStackingManager", ex);
        }
    }

    /** Dọn hologram của item đã biến mất (gọi định kỳ trong mergeTick). */
    private void cleanupHolograms() {
        if (holos.isEmpty()) return;
        holos.entrySet().removeIf(e -> {
            org.bukkit.entity.Item item = null;
            try {
                // AUDIT FIX S9: hologram la passenger cua item - khong can lookup
                // Bukkit.getEntity(UUID) cho tung hologram moi merge tick.
                for (org.bukkit.entity.Entity passenger : e.getValue().getPassengers()) {
                    if (passenger instanceof org.bukkit.entity.Item it) { item = it; break; }
                }
            } catch (Exception ex) {
                MauaHopper.fineSafe("Safe catch in ItemStackingManager", ex);
            }
            if (item == null || !item.isValid() || item.isDead()) {
                try { e.getValue().remove(); } catch (Exception ex) { MauaHopper.fineSafe("Safe catch in ItemStackingManager", ex); }
                // PATCH v28p3 (loi #5): item da mat thi cache hien thi cung
                // het gia tri (du weak-map tu don duoc, don ngay cho sach).
                if (item != null) lastDisplayAmount.remove(item);
                return true;
            }
            return false;
        });
    }
}
