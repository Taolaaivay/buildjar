# PATCH-NOTES-v28p7-batch1 (2026-09-29) - Dot 1: 3 bug do

## Loai #1 - Container lock ro/stal vinh vien voi entity inventory
File: DuplicationProtector.java
- invPackedKey(): inventory cua ENTITY (minecart chest, chest boat) gio khoa
  theo UUID entity (bit 63 lam co + mix UUID) thay vi theo toa do. Truoc day
  entity dich chuyen giua tryLock/unlock -> key lech -> entry nam lai trong
  containerInFlight vinh vien -> toa do do stall vinh vien (do ngung chuyen).
- packLocKey(): world hash giam 16 -> 15 bit de danh bit 63 cho entity key,
  tranh collision 2 loai key.
- Inventory block giu nguyen khoa theo vi tri (khong doi hanh vi).

## Loai #2 - Spam log khi NMS dispenser loi
File: HopperTicker.java
- dispenseOnceNMS(): doi tu void -> boolean. Catch KHONG con nem
  RuntimeException (truoc day onDispense catch in FULL stack trace cho MOI
  pulse, khong dedupe). Bay gio: warn 1 lan qua warnNms, dat nmsOk=false de
  fast path tat vinh vien -> vanilla tiep quan, dispenser khong bao gio
  "ket" im lang.
- Ca 2 call site (onDispense :3178, auto-burst :3337) deu break vong lap khi
  tra false.

## Loai #3 - Dispenser auto-burst khong tu unregister khi block mat
File: HopperTicker.java :3303
- Piston keo dispenser di (khong sinh BlockBreakEvent) -> truoc day entry
  song toi chunk unload, bi snapshot quet moi 500ms vo ich. Bay gio tu
  unregisterDispenser(loc) nhu hopper (:738) va dropper (:2512).

## Verify
- Brace balance: 0 ca 2 file (parens delta -1 co san tu ban goc, ky tu trong
  comment).
- Grep call site: dispenseOnceNMS (3/3), invPackedKey (3/3),
  unregisterDispenser (3/3) - tat ca khop kieu tham so.
