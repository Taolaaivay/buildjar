package com.mauahopper;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.entity.Animals;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Monster;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.scheduler.BukkitTask;

import java.util.ArrayList;
import java.util.List;

/**
 * Gộp mob cùng loại đứng gần nhau thành 1 entity (thay thế PolyStacking).
 * Số lượng lưu trong PDC key "mauahopper:mob_stack" (INTEGER).
 * Khi mob chết: giảm stack 1, spawn lại mob còn lại tại chỗ (như StackMob).
 * Tích hợp sẵn - không xung đột plugin ngoài.
 */
public class MobStackingManager implements Listener {

    private final MauaHopper plugin;
    // PATCH v28p3 (loi #8 - TPS): cap so lan respawn stack con lai khi mob
    // stacked chet, TREN MOI TICK. Truoc day vụ no/killall lam 500+ mob
    // stacked cung chet 1 tick = 500+ spawnEntity() trong 1 tick = spike
    // main thread. Vuot cap -> bo respawn (log canh bao ro rang - chon
    // mat mob chu khong de server sap; tinh huong nay chi xay ra khi chet
    // hang loat bat thuong, khong phai farm binh thuong).
    // p8 FIX: 25 -> 60. max-stack da len 30 (batch6) - cap 25 chi du 1
    // stack/tick, no/farm sat thuong dien rong co the lam phan vuot cap
    // MAT VINH VIEN. 60 = 2 stack/tick, van la chan chong death-spiral.
    private static final int MAX_DEATH_RESPAWN_PER_TICK = 60;
    private int deathRespawnThisTick = 0;
    // FIX 2026-09-28 (loi #9): chi canh bao 1 LAN cho moi dot vuot cap -
    // truoc day MOI EntityDeathEvent sau cap deu in 1 dong warning: vu no/
    // killall 500 mob = ~475 dong log trong 1 tick = ghi log dong bo + flush
    // console = lag main thread.
    private boolean deathCapWarned = false;
    private org.bukkit.scheduler.BukkitTask respawnCapTask = null;
    private final NamespacedKey mobKey;
    private BukkitTask task;

    private boolean enabled = true;
    // v4.17 FIX P2-GEARED: cache protect-geared - doc YAML 1 lan/reload
    // thay vi moi lan goi isMergeableNoDist (nam trong vong O(n^2)).
    private boolean protectGearedCached = true;
    private final java.util.Map<java.util.UUID, Boolean> gearCache = new java.util.HashMap<>();
    private int playerScanOffset;
    // PATCH 2026-09-27 (loi #14): cache attract-radius - truoc day doc
    // parse YAML moi merge tick trong hot path.
    private double attractRadiusCached = 0.0;
    private int maxStack = 20;
    private double radius = 8.0;
    private long interval = 100;
    // v67.34: danh sach mob bi chan spawn tu nhien (mac dinh GLOW_SQUID)
    private final java.util.Set<org.bukkit.entity.EntityType> blockedSpawnTypes = new java.util.HashSet<>();

    // v67.33: cua so "admin dang xoa mob" - Essentials /remove (killall/butcher/
    // mobkill) co the sat thuong theo cach khong sinh dung damage cause (dat
    // health ve 0, remove...) hoac bo qua mob co ten. 5 giay sau lenh killall:
    // khong respawn bat ke nguyen nhan chet -> lenh chac chan sach.
    private long adminKillQuietUntilMs = 0;
    // v67.9: chi quet world co mob moi spawn - tranh getLivingEntities()
    // full-world scan khi khong co gi thay doi. Safety scan moi 15 giay.
    private final java.util.Set<String> dirtyWorlds = new java.util.HashSet<>();
    private long lastIdleScanMs = 0;

    public MobStackingManager(MauaHopper plugin) {
        this.plugin = plugin;
        this.mobKey = new NamespacedKey(plugin, "mob_stack");
    }

    public void start() {
        loadConfig();
        Bukkit.getPluginManager().registerEvents(this, plugin);
        task = Bukkit.getScheduler().runTaskTimer(plugin, this::mergeTick,
                interval, interval);
        // PATCH v28p3 (loi #8): reset nhip respawn cap theo TICK that (1L)
        // - khong dung merge-interval lam nhip, neu khong cap 25/tick se
        // thanh 25/interval tuy config.
        respawnCapTask = Bukkit.getScheduler().runTaskTimer(plugin,
                () -> { deathRespawnThisTick = 0; deathCapWarned = false; }, 1L, 1L);
    }

    public void reload() {
        loadConfig();
        if (task != null) task.cancel();
        task = Bukkit.getScheduler().runTaskTimer(plugin, this::mergeTick,
                interval, interval);
    }

    public void stop() {
        if (task != null) task.cancel();
        if (respawnCapTask != null) respawnCapTask.cancel();
    }

    private void loadConfig() {
        var cfg = plugin.getConfig();
        protectGearedCached = cfg.getBoolean("stacking.mobs.protect-geared", true);
        // AUDIT FIX P11: attract mac dinh TAT - tranh teleport hut mob xuyen tuong.
        // FIX 2026-09-28 (loi #8 - TPS): clamp attract-radius TUONG TU
        // ItemStackingManager (file do da clamp 16). Khong clamp thi admin
        // dat attract-radius: 500 -> scanR ~508 trong
        // world.getNearbyEntities() MOI merge tick cho toi 5 player cung luc
        // = query AABB khong lo tren main thread = TPS drop tu dong config.
        double attractCfg = cfg.getDouble("stacking.mobs.attract-radius", 0.0);
        if (attractCfg > 32.0) {
            plugin.getLogger().warning("[MobStack] stacking.mobs.attract-radius=" + attractCfg
                    + " qua lon - clamp xuong 32 (AABB scan moi merge tick).");
            attractCfg = 32.0;
        }
        attractRadiusCached = Math.max(0.0, attractCfg); // PATCH #14
        enabled = cfg.getBoolean("stacking.mobs.enabled", true);
        maxStack = Math.max(2, cfg.getInt("stacking.mobs.max-stack", 7));
        // FIX 2026-09-28 (loi #8b): radius cung phai co tran - radius 500
        // lam scanR = radius + 8 phong AABB vo han du mergeCell da xu ly
        // reach > 1 chunk dung dan.
        double radiusCfg = cfg.getDouble("stacking.mobs.radius", 4.0);
        if (radiusCfg > 64.0) {
            plugin.getLogger().warning("[MobStack] stacking.mobs.radius=" + radiusCfg
                    + " qua lon - clamp xuong 64 (AABB scan moi merge tick).");
            radiusCfg = 64.0;
        }
        radius = Math.max(1.0, radiusCfg); // v67.56: mac dinh 4 block theo yeu cau chu server
        interval = Math.max(20, cfg.getLong("stacking.mobs.interval", 100));
        // v67.34: chan spawn - key thieu hoan toan thi mac dinh chan GLOW_SQUID,
        // neu admin da khai bao key (ke ca rong) thi ton trong y minh
        blockedSpawnTypes.clear();
        if (!cfg.isSet("stacking.mobs.block-spawn")) {
            blockedSpawnTypes.add(org.bukkit.entity.EntityType.GLOW_SQUID);
        } else {
            for (String name : cfg.getStringList("stacking.mobs.block-spawn")) {
                try {
                    blockedSpawnTypes.add(org.bukkit.entity.EntityType.valueOf(name.toUpperCase()));
                } catch (IllegalArgumentException ignored) {
                }
            }
        }
    }

    // =====================================================================
    // API
    // =====================================================================

    public int getStackCount(LivingEntity entity) {
        if (entity == null) return 1;
        try {
            Integer c = entity.getPersistentDataContainer().get(mobKey, PersistentDataType.INTEGER);
            return c != null ? Math.max(1, c) : 1;
        } catch (Exception ex) {
            MauaHopper.fineSafe("Safe catch in MobStackingManager", ex);
            return 1;
        }
    }

    private void setStackCount(LivingEntity entity, int count) {
        try {
            if (count <= 1) {
                entity.getPersistentDataContainer().remove(mobKey);
                updateName(entity, 1);
                return;
            }
            entity.getPersistentDataContainer().set(mobKey, PersistentDataType.INTEGER, count);
            updateName(entity, count);
        } catch (Exception ex) {
            MauaHopper.fineSafe("Safe catch in MobStackingManager", ex);
        }
    }

    private void updateName(LivingEntity entity, int count) {
        try {
            if (count <= 1) {
                entity.setCustomName(null);
                entity.setCustomNameVisible(false);
                return;
            }
            entity.setCustomName("§c§l✖ " + count + "x " + friendlyName(entity.getType()));
            entity.setCustomNameVisible(true);
        } catch (Exception ex) {
            MauaHopper.fineSafe("Safe catch in MobStackingManager", ex);
        }
    }

    private String friendlyName(EntityType type) {
        String[] parts = type.name().toLowerCase().split("_");
        StringBuilder sb = new StringBuilder();
        for (String p : parts) {
            if (p.isEmpty()) continue;
            sb.append(Character.toUpperCase(p.charAt(0))).append(p.substring(1)).append(" ");
        }
        return sb.toString().trim();
    }

    // =====================================================================
    // Death handling - mob chết thì giảm stack, spawn lại phần còn lại
    // =====================================================================

    // v67.9: danh dau world ban khi co mob spawn de mergeTick quet lai
    @EventHandler(ignoreCancelled = true)
    public void onMobSpawn(org.bukkit.event.entity.CreatureSpawnEvent e) {
        if (!enabled || !plugin.isActive()) return;
        if (!plugin.getWorldManager().isWorldAllowed(e.getEntity().getWorld())) return;
        // v67.34: chan spawn tu nhien cua mob trong danh sach (GLOW_SQUID mac
        // dinh). Chi chan NATURAL - spawner do nguoi choi dat, breed, spawn
        // egg, summon van hoat dong day du.
        if (blockedSpawnTypes.contains(e.getEntityType())
                && e.getSpawnReason() == org.bukkit.event.entity.CreatureSpawnEvent.SpawnReason.NATURAL) {
            e.setCancelled(true);
            return;
        }
        dirtyWorlds.add(e.getEntity().getWorld().getName());
    }

    // v67.25: chunk load -> danh dau world ban
    @EventHandler
    public void onChunkLoadMobs(org.bukkit.event.world.ChunkLoadEvent e) {
        if (!enabled || !plugin.isActive()) return;
        if (!plugin.getWorldManager().isWorldAllowed(e.getWorld())) return;
        boolean hasCandidate = false;
        for (org.bukkit.entity.Entity en : e.getChunk().getEntities()) {
            if (en instanceof Animals || en instanceof Monster) { hasCandidate = true; break; }
        }
        if (hasCandidate) dirtyWorlds.add(e.getWorld().getName());
    }

    // v67.33: bat lenh killall/butcher/remove cua Essentials (va tuong tu)
    @EventHandler(ignoreCancelled = true)
    public void onAdminKillCommand(org.bukkit.event.player.PlayerCommandPreprocessEvent e) {
        // v4.16 FIX P1-6: chi nguoi co quyen killall moi mo cua so. Truoc day bat ky
        // ai chat chu "killall" cung khien mob farm mat respawn trong 5 giay.
        if (!e.getPlayer().isOp()
                && !e.getPlayer().hasPermission("essentials.killall")
                && !e.getPlayer().hasPermission("mauahopper.adminkill.detect")) return;
        // FIX C9: parse LABEL + first arg thay vi contains TOAN CAU - truoc
        // day /msg banbe "killall" cung mo cua so 5 giay (da co gate quyen
        // nen thiet hai thap, nhung la false positive ro rang).
        String raw = e.getMessage().trim();
        String body = raw.startsWith("/") ? raw.substring(1) : raw;
        String label = body.isEmpty() ? "" : body.split(" ")[0].toLowerCase();
        int colon = label.indexOf(':');
        String name = colon >= 0 ? label.substring(colon + 1) : label;
        String firstArg = body.indexOf(' ') > 0
                ? body.substring(body.indexOf(' ') + 1).trim().toLowerCase() : "";
        boolean killCmd = name.equals("killall") || name.equals("butcher") || name.equals("mobkill")
                || name.equals("ekill") || name.equals("ekillall") || name.equals("remove")
                || name.equals("eremove")
                // PATCH 2026-09-27 (loi #13): chi nhan "kill" khi KHONG co
                // namespace hoac namespace minecraft: - tranh bat nham lenh
                // "kill" cua plugin khac (PvP/minigame) mo cua so 5 giay.
                || (name.equals("kill") && (colon < 0 || label.startsWith("minecraft:")))
                || firstArg.startsWith("@e");
        if (killCmd) {
            adminKillQuietUntilMs = System.currentTimeMillis() + 5000;
        }
    }

    // PATCH 2026-09-28 (loi #29): gearCache chi clear o DAU mergeTick (moi
    // 150 tick mac dinh) - mob nhat do giua 2 lan scan van con cache "khong
    // mac do" -> bi gop vao stack, MAT DO. Xoa cache ngay khi pickup de
    // cap nhat trang thai giap/vu khi som nhat co the.
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onMobPickupGear(org.bukkit.event.entity.EntityPickupItemEvent e) {
        if (e.getEntity() instanceof LivingEntity le) gearCache.remove(le.getUniqueId());
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onMobDeath(EntityDeathEvent e) {
        // PATCH v28p3 (loi #8): cap respawn/tick. CHECK dat som (re) de
        // khong chay xuong duoi khi da het nang luc; NHUNG counter chi
        // TANG NGAY TRUOC cho respawn thuc su (sau moi gate count/cause/
        // admin-kill) - neu tang o day, 25 con chet binh thuong KHONG
        // stacked (count<=1) cung tieu sach nang luc va lam MAT stack that.
        if (deathRespawnThisTick >= MAX_DEATH_RESPAWN_PER_TICK) {
            // FIX 2026-09-28 (loi #9): chi in canh bao 1 lan/dot - truoc day
            // moi death event sau cap in 1 dong = spam log lag main thread.
            if (!deathCapWarned) {
                deathCapWarned = true;
                plugin.getLogger().warning("[MobStack] Qua " + MAX_DEATH_RESPAWN_PER_TICK
                        + " respawn/tick - bo respawn phan con lai (mob mat). "
                        + "Nguyen nhan: chet hang loat cung 1 tick (no/killall?).");
            }
            return;
        }
        // v4.17 FIX P3-ISACTIVE (chon A): BO gate isActive() - dung nhu comment
        // ben tren da viet: mob da stack con PDC PHAI duoc respawn phan con lai
        // ke ca khi /mh off, neu khong 19/20 con bien mat vinh vien khi admin
        // tat plugin tam thoi de khac phuc lag.
        LivingEntity entity = e.getEntity();
        int count = getStackCount(entity);
        if (count <= 1) return;
        // Không spawn lại nếu mob despawn tự nhiên hoặc chết do admin/kill
        // command - tránh dup vô hạn. Chỉ spawn lại khi chết thật sự.
        if (entity.getLastDamageCause() == null) return;
        var cause = entity.getLastDamageCause().getCause();
        // FIX v67.25 (whitelist): CHI respawn khi chet boi sat thuong tu nhien/farm.
        // Moi cach chet boi admin/lenh (/killall Essentials, /kill vanilla = CUSTOM
        // hoac VOID, plugin xoa entity, v.v.) KHONG respawn -> killall chac chan
        // duoc, khong con hien tuong "kill xong lai moc len".
        // PATCH v28p7-batch6-d4 (loi #17): 'cause' la DamageCause enum -
        // theo contract Bukkit khong bao gio null sau khi getLastDamageCause()
        // da non-null. Check null chet -> xoa.
        // v67.33: dang trong cua so killall cua admin -> khong respawn bat ke cause
        if (System.currentTimeMillis() < adminKillQuietUntilMs) return;
        switch (cause) {
            case ENTITY_ATTACK: case PROJECTILE: case MAGIC: case FIRE_TICK:
            case FIRE: case LAVA: case CONTACT: case BLOCK_EXPLOSION:
            case ENTITY_EXPLOSION: case FALL: case DROWNING: case SUFFOCATION:
            case STARVATION: case POISON: case THORNS: case FREEZE: case SONIC_BOOM:
            case HOT_FLOOR: case CAMPFIRE: case CRAMMING: case DRAGON_BREATH:
            case WITHER: case MELTING: case LIGHTNING:
            case FALLING_BLOCK: // v67.92: may dap de (anvil farm)
                break; // sat thuong thuong -> respawn
            default:
                return; // CUSTOM/SUICIDE/VOID/KILL/... -> khong respawn
        }

        // Spawn lại mob còn lại ngay tại chỗ (stack - 1)
        // PATCH v28p3 (loi #8): dem nang luc TAI DAY - luc nay chac chan
        // se respawn (da qua het gate o tren).
        deathRespawnThisTick++;
        int remaining = count - 1;
        // PATCH v28p7-batch6-d2 (loi #5 - death cascade): truoc day respawn
        // DUNG cho chet - cause whitelist co LAVA/FIRE_TICK/FIRE/HOT_FLOOR/
        // CAMPFIRE nen stack respawn vao dang chay roi chet tiep, moi vong
        // doi 1 budget (60/tick) va stack N con doi sach N budget lien tiep,
        // can budget lam stack chet hop le khac bi mat im lang. Day len 1
        // block neu cho dung nguy hiem - mob tu roi xuong, thoat vong lap.
        org.bukkit.Location spawnLoc = entity.getLocation().clone();
        Material feetMat = spawnLoc.getBlock().getType();
        if (feetMat == Material.LAVA || feetMat == Material.FIRE || feetMat == Material.SOUL_FIRE
                || feetMat == Material.CAMPFIRE || feetMat == Material.SOUL_CAMPFIRE
                || feetMat == Material.MAGMA_BLOCK) {
            spawnLoc.add(0, 1, 0);
        }
        LivingEntity fresh = (LivingEntity) entity.getWorld()
                .spawnEntity(spawnLoc, entity.getType());

        // v67.78: copy tuoi DUNG bang Ageable (truoc day chi Animals -> baby
        // zombie hoi thanh nguoi lon) + copy bien the/mau long/gien (truoc day
        // respawn mat variant - dan cuu nau hoi thanh cuu trang, axolotl quy
        // hoi thanh mau thuong...)
        if (fresh instanceof org.bukkit.entity.Ageable fa && entity instanceof org.bukkit.entity.Ageable ea) {
            fa.setAge(ea.getAge());
        }
        // YELLOW FIX: giu attributes co ban cho stack con lai. Khong copy
        // equipment o day de tranh duplicate gear voi death drop.
        // PATCH v28p7-batch5-p3c (build fix): copy attribute BANG REFLECTION -
        // paper-api 1.21.11 bao "cannot find symbol" o loat kieu
        // AttributeInstance/Attribute o day (cac phien ban API thay doi kieu
        // attribute). Reflection bien dich duoc tren MOI API; that bai = bo
        // qua copy attribute (mob respawn dung mac dinh - an toan, khong
        // crash).
        try {
            Class<?> attributeClass = Class.forName("org.bukkit.attribute.Attribute");
            java.lang.reflect.Method mGetAttributes = LivingEntity.class.getMethod("getAttributes");
            java.lang.reflect.Method mGetAttribute = LivingEntity.class.getMethod("getAttribute", attributeClass);
            Class<?> instClass = Class.forName("org.bukkit.attribute.AttributeInstance");
            java.lang.reflect.Method mGetBase = instClass.getMethod("getBaseValue");
            java.lang.reflect.Method mSetBase = instClass.getMethod("setBaseValue", double.class);
            @SuppressWarnings("unchecked")
            java.util.Collection<Object> attrs = (java.util.Collection<Object>) mGetAttributes.invoke(entity);
            for (Object oldAttr : attrs) {
                Object attribute = oldAttr.getClass().getMethod("getAttribute").invoke(oldAttr);
                Object newAttr = mGetAttribute.invoke(fresh, attribute);
                if (newAttr != null) mSetBase.invoke(newAttr, mGetBase.invoke(oldAttr));
            }
        } catch (Exception ignored) { }
        copyVariant(entity, fresh);
        // PATCH v28p7-batch6-d2 (loi #4 - mat ten custom): truoc day copy
        // ten TRUOC setStackCount -> updateName() ben trong luon ghi de
        // (remaining>1: "✖ Nx Type", remaining==1: setCustomName(null))
        // -> ten custom ("Bob", "Boss"...) mat vinh vien. Bay gio:
        // setStackCount TRUOC, copy ten LAI sau - chi khi remaining==1
        // (stack ghep ten thi de ten stack, hop ly hon ten cu).
        setStackCount(fresh, remaining);
        if (remaining == 1 && entity.isCustomNameVisible() && entity.getCustomName() != null
                && !entity.getCustomName().contains("✖")) {
            fresh.setCustomName(entity.getCustomName());
            fresh.setCustomNameVisible(true);
        }
    }

    // =====================================================================
    // Merge task
    // =====================================================================

    /** v67.78: copy bien the/mau long/gien khi respawn stack (doi xung voi
     *  14 tieu chi phan biet cua isMergeableNoDist). */
    // =====================================================================
    // v4.10 FIX #62: TACH stack khi thuan phuc / cuoi / day buoc
    // =====================================================================

    /** v4.10: tach con nay ra khoi stack - con nay thanh mob binh thuong
     *  (xoa PDC + ten), sinh stack con lai (count-1) tai cho. Dung cho
     *  thuan phuc / cuoi / day buoc. Phan con lai KHONG ke thua tame. */
    private void splitStack(LivingEntity ent) {
        // v28p6 FIX (loi #28): getStackCount tra int primitive (auto-box) -
        // khong bao gio null, nhanh count == null la dead code.
        int count = getStackCount(ent);
        if (count <= 1) return;
        setStackCount(ent, 1); // tu xoa PDC + ten stack
        try {
            LivingEntity rest = (LivingEntity) ent.getWorld()
                    .spawnEntity(ent.getLocation(), ent.getType());
            if (rest instanceof org.bukkit.entity.Ageable ra
                    && ent instanceof org.bukkit.entity.Ageable ea) {
                ra.setAge(ea.getAge());
            }
            copyVariant(ent, rest);
            // phan con lai la mob hoang - khong ke thua trang thai thuan
            if (rest instanceof org.bukkit.entity.Tameable rt) rt.setTamed(false);
            setStackCount(rest, count - 1);
            rest.setAI(true);
        } catch (Exception ex) { MauaHopper.fineSafe("Safe catch in MobStackingManager", ex); }
    }

    /** FIX #62a: thuan phuc con trong stack -> TACH. Truoc day con vua
     *  thuan van mang stack PDC -> chet -> onMobDeath respawn stack KHONG
     *  thuan = MAT PET + dupe mob. */
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onTameStack(org.bukkit.event.entity.EntityTameEvent e) {
        if (!enabled || !plugin.isActive()) return;
        // PATCH v17: getEntity() cua EntityTameEvent da tra LivingEntity -
        // instanceof thua gay loi ECJ (onLeashStack giu nguyen vi tra Entity).
        splitStack(e.getEntity());
    }

    /** FIX #62b: cuoi con trong stack (horse/pig/strider...) -> TACH truoc
     *  khi cho len. Mount lai o tick sau cho mượt. */
    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onMountStack(org.bukkit.event.entity.EntityMountEvent e) {
        if (!enabled || !plugin.isActive()) return;
        if (!(e.getMount() instanceof LivingEntity mount)) return;
        // v28p6 FIX (loi #28): tuong tu splitStack - int primitive khong
        // bao gio null, bo dead branch.
        int count = getStackCount(mount);
        if (count <= 1) return;
        e.setCancelled(true);
        splitStack(mount);
        org.bukkit.entity.Entity rider = e.getEntity();
        org.bukkit.Bukkit.getScheduler().runTask(plugin, () -> {
            if (rider.isValid() && mount.isValid() && !mount.isDead()) {
                mount.addPassenger(rider);
            }
        });
    }

    /** FIX #62c: day buoc con trong stack -> TACH (day 1 con, khong day ca
     *  cuc). Khong cancel event - day van dinh vao con vua tach. */
    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onLeashStack(org.bukkit.event.entity.PlayerLeashEntityEvent e) {
        if (!enabled || !plugin.isActive()) return;
        if (e.getEntity() instanceof LivingEntity ent) splitStack(ent);
    }

    private void copyVariant(LivingEntity from, LivingEntity to) {
        try {
            if (from instanceof org.bukkit.entity.Sheep a && to instanceof org.bukkit.entity.Sheep b)
                b.setColor(a.getColor());
            if (from instanceof org.bukkit.entity.Wolf a && to instanceof org.bukkit.entity.Wolf b)
                b.setVariant(a.getVariant());
            if (from instanceof org.bukkit.entity.Cat a && to instanceof org.bukkit.entity.Cat b)
                b.setCatType(a.getCatType());
            if (from instanceof org.bukkit.entity.Rabbit a && to instanceof org.bukkit.entity.Rabbit b)
                b.setRabbitType(a.getRabbitType());
            if (from instanceof org.bukkit.entity.Parrot a && to instanceof org.bukkit.entity.Parrot b)
                b.setVariant(a.getVariant());
            if (from instanceof org.bukkit.entity.Fox a && to instanceof org.bukkit.entity.Fox b)
                b.setFoxType(a.getFoxType());
            if (from instanceof org.bukkit.entity.MushroomCow a && to instanceof org.bukkit.entity.MushroomCow b)
                b.setVariant(a.getVariant());
            if (from instanceof org.bukkit.entity.Axolotl a && to instanceof org.bukkit.entity.Axolotl b)
                b.setVariant(a.getVariant());
            if (from instanceof org.bukkit.entity.Frog a && to instanceof org.bukkit.entity.Frog b)
                b.setVariant(a.getVariant());
            if (from instanceof org.bukkit.entity.Horse a && to instanceof org.bukkit.entity.Horse b) {
                b.setColor(a.getColor());
                b.setStyle(a.getStyle());
            }
            if (from instanceof org.bukkit.entity.Llama a && to instanceof org.bukkit.entity.Llama b)
                b.setColor(a.getColor());
            if (from instanceof org.bukkit.entity.Panda a && to instanceof org.bukkit.entity.Panda b) {
                b.setMainGene(a.getMainGene());
                b.setHiddenGene(a.getHiddenGene());
            }
            if (from instanceof org.bukkit.entity.Goat a && to instanceof org.bukkit.entity.Goat b)
                b.setScreaming(a.isScreaming());
        } catch (Exception ex) {
            MauaHopper.fineSafe("Safe catch in MobStackingManager", ex);
        }
    }

    private void mergeTick() {
        gearCache.clear();
        if (!enabled || plugin.isShuttingDown()) return;
        if (!plugin.isActive()) return;

        long nowMs = System.currentTimeMillis();
        boolean idleScan = (nowMs - lastIdleScanMs >= 15000L);
        if (idleScan) lastIdleScanMs = nowMs;

        for (org.bukkit.World world : Bukkit.getWorlds()) {
            if (!plugin.getWorldManager().isWorldAllowed(world)) continue;
            // v67.9: bo qua world khong co mob moi (tru dot safety scan 15s)
            String wn = world.getName();
            if (!idleScan && !dirtyWorlds.contains(wn)) continue;
            dirtyWorlds.remove(wn);
            // v67.91 GATE (PATCH 2026-09-28 sua comment): quet xung quanh
            // TOI DA 5 nguoi choi/luot (xoay vong) voi ban kinh scanR =
            // max(32, mobStackRadius + 8) - KHONG dung require_player_radius
            // lam gate nhu comment cu hieu nham (nearPlayer() da bi xoa do
            // dead code). Day la scan mob ton nhat con lai. khong chay o vung hoang. Moi chunk kiem tra
            // bang cache player-chunk co san cua... tinh truc tiep cho chuan.
            // FIX TPS: cache vi tri nguoi choi 1 LAN cho ca dot quet (truoc day
            // world.getPlayers()+getLocation() chay lai cho MOI mob - 20k mob x
            // 20 nguoi = 400k allocation/dot quet tren farm dong), va bo qua
            // world khong co nguoi choi truoc khi getLivingEntities().
            java.util.List<org.bukkit.entity.Player> players = world.getPlayers();
            if (players.isEmpty()) continue;
            // RED FIX: scan nearby quanh nguoi choi thay vi getLivingEntities()
            // toan world. Loai bo ca nearPlayer O(mob x player) sau scan.
            double scanR = Math.max(32.0, Math.max(radius, attractRadiusCached) + 8.0);
            List<LivingEntity> mobs = new ArrayList<>();
            java.util.Set<java.util.UUID> seen = new java.util.HashSet<>();
            // AUDIT FIX P10: xoay vong toi da 5 player/mergeTick, giam bo query
            // AABB box lon quanh toan bo nguoi choi cung mot tick.
            int start = playerScanOffset % players.size();
            int count = Math.min(5, players.size());
            playerScanOffset = (start + count) % players.size();
            // PATCH v28p7-batch5-P3 (loi #11 - TPS): bo qua player nam trong
            // vung scanR cua player da duoc quet - tranh AABB query chong lap
            // khi 5 nguoi duoc xoay toi dung gan nhau (seen set chi dedupe
            // ket qua, khong ngan duoc query).
            java.util.List<org.bukkit.Location> accepted = new java.util.ArrayList<>();
            double scanR2 = scanR * scanR;
            for (int pi = 0; pi < count; pi++) {
                // FIX 2026-09-28 (loi #14): getLocation CHO 5 NGUOI DUOC
                // QUET (truoc day getLocation alloc cho TAT CA player moi
                // merge tick du chi 5 nguoi duoc dung).
                org.bukkit.Location pl = players.get((start + pi) % players.size()).getLocation();
                boolean overlap = false;
                for (org.bukkit.Location q : accepted) {
                    double ddx = pl.getX() - q.getX();
                    double ddz = pl.getZ() - q.getZ();
                    if (ddx * ddx + ddz * ddz < scanR2) { overlap = true; break; }
                }
                if (overlap) continue;
                accepted.add(pl);
                for (org.bukkit.entity.Entity en : world.getNearbyEntities(pl, scanR, scanR, scanR)) {
                    if (!(en instanceof LivingEntity le)) continue;
                    if (!seen.add(le.getUniqueId())) continue;
                    if (!(le instanceof Animals) && !(le instanceof Monster)) continue;
                    if (!le.isValid() || le.isDead()) continue;
                    if (le.getCustomName() != null && !le.getCustomName().contains("✖")) continue;
                    if (le.isLeashed()) continue;
                    if (!le.getPassengers().isEmpty() || le.getVehicle() != null) continue;
                    if (le instanceof org.bukkit.entity.Monster mm && mm.getTarget() != null) continue;
                    if (le instanceof org.bukkit.entity.Tameable
                            && ((org.bukkit.entity.Tameable) le).isTamed()) continue;
                    if (le instanceof org.bukkit.entity.AbstractHorse) {
                        org.bukkit.entity.AbstractHorse horse = (org.bukkit.entity.AbstractHorse) le;
                        if (horse.isTamed()) continue;
                        boolean hasGear = false;
                        for (org.bukkit.inventory.ItemStack it : horse.getInventory()) {
                            if (it != null && it.getType() != org.bukkit.Material.AIR) { hasGear = true; break; }
                        }
                        if (hasGear) continue;
                    }
                    mobs.add(le);
                }
            }
            mergeWorld(mobs);
            // v67.56 ATTRACT: mob le nhay ve stack gan nhat trong attract-radius
            double attract = attractRadiusCached; // PATCH 2026-09-27 (loi #14): dung cache thay doc config moi tick
            if (attract > radius && mobs.size() <= 200) { // v67.78: cap attract O(n^2)
                int attractedThisTick = 0;

                for (LivingEntity single : mobs) {
                    // PATCH v28p3 (loi #14): check cap TRUOC khi chay vong
                    // tim nearest O(n) - truoc day check SAU khi da duyet
                    // het ca danh sach roi moi break, lang phi tron vong
                    // cuoi cung (50 cap x O(n) doc PDC/location vo ich).
                    if (attractedThisTick >= 50) break;
                    if (!single.isValid() || single.isDead()) continue;
                    if (single.getCustomName() != null) continue;
                    LivingEntity nearest = null;
                    double nd = attract * attract;
                    for (LivingEntity cand : mobs) {
                        if (cand == single || !cand.isValid() || cand.isDead()) continue;
                        if (cand.getCustomName() == null) continue;
                        if (!isMergeableNoDist(single, cand)) continue;
                        double d = single.getLocation().distanceSquared(cand.getLocation());
                        if (d < nd) { nd = d; nearest = cand; }
                    }
                    if (nearest != null) {
                        single.teleport(nearest.getLocation());
                        attractedThisTick++;
                    }
                }
            }
        }
    }

    // PATCH 2026-09-28 (loi #32 - dead code): nearPlayerRadius chi duoc
    // GAN, khong mot dong nao DOC no (da grep toan project). Xoa field +
    // method + call site khoi loadConfig.

    /** PERF PATCH (v17): bucket theo chunk + forward-neighbor thay vi O(n^2)
     *  tren toan danh sach mob. radius <= 15 < 16 block nen 2 mob cach nhau
     *  >= 2 chunk khong bao gio merge duoc -> chi xet cap CUNG/KE chunk.
     *  Them cap so target/tick chong TPS drop tren mob farm tap trung. */
    private static final int MOB_MERGE_MAX_PER_TICK = 500;
    private static final int MOB_MERGE_CELL_CAP = 256;
    // PATCH v28p7-batch5 (loi #2): cell >256 mob - truoc day subList(0,256)
    // lay DUNG 256 con dau moi merge tick nen mob thu 257+ khong bao gio
    // duoc gop (starvation, item stacking da fix tuong tu o cap 1000).
    // Xoay cua so bang offset tang dan moi lan cap.
    private int mergeCellCapRotate = 0;

    private void mergeWorld(List<LivingEntity> mobs) {
        if (mobs.size() < 2) return;
        java.util.Map<Long, java.util.List<LivingEntity>> buckets = new java.util.HashMap<>();
        for (LivingEntity le : mobs) {
            if (!le.isValid() || le.isDead()) continue;
            org.bukkit.Location l = le.getLocation();
            long key = ((long) (l.getBlockX() >> 4) & 0x7fffffffL)
                    | (((long) (l.getBlockZ() >> 4) & 0x7fffffffL) << 31);
            buckets.computeIfAbsent(key, k -> new java.util.ArrayList<>()).add(le);
        }
        int processed = 0;
        for (java.util.Map.Entry<Long, java.util.List<LivingEntity>> entry : buckets.entrySet()) {
            if (processed >= MOB_MERGE_MAX_PER_TICK) break;
            // v28p6 FIX (loi #22): moi cell VISITED ton 1 don vi budget, cong
            // them so merge thuc te - tranh cell khong merge nao van doi 500
            // budget cu, dong thoi van gioi han duoc so cell + merge/tick.
            processed++;
            int bx = (int) (entry.getKey() & 0x7fffffffL);
            int bz = (int) ((entry.getKey() >> 31) & 0x7fffffffL);
            java.util.List<LivingEntity> cell = entry.getValue();
            // PATCH v17b: neighbor reach = ceil(radius/16). Gia dinh ban dau
            // (radius <= 16, chi xet 4 forward-neighbor) SE SOT cap neu admin
            // cau hinh stacking.mobs.radius > 16. Forward-half (dx>0 hoac
            // dx==0 && dz>0) dam bao moi cap chunk chi xet DUNG 1 LAN.
            final int reach = Math.max(1, (int) Math.ceil(radius / 16.0));
            java.util.List<LivingEntity> combined = new java.util.ArrayList<>(cell);
            for (int dx = -reach; dx <= reach; dx++) {
                for (int dz = -reach; dz <= reach; dz++) {
                    if (dx == 0 && dz == 0) continue;
                    if (!(dx > 0 || (dx == 0 && dz > 0))) continue;
                    addBucket(buckets, combined, bx + dx, bz + dz);
                }
            }
            if (combined.size() > MOB_MERGE_CELL_CAP) {
                // Farm tha hang tram mob vao 1 cho: xu ly phan dau, phan sau
                // doi luot merge tick sau - tranh vuot chi phi 1 tick.
                // PATCH v28p7-batch5 (loi #2): XOAY cua so theo offset tang
                // dan thay vi subList(0,256) co dinh - mob ngoai cua so o
                // luot nay duoc gop o luot sau, het starvation.
                // PATCH v28p7-batch5-P3b (build fix): doi ten start -> cellStart
                // (trung ten voi int start cua player rotation trong mergeTick).
                int cellStart = (mergeCellCapRotate++) % combined.size();
                java.util.ArrayList<LivingEntity> rotated = new java.util.ArrayList<>(MOB_MERGE_CELL_CAP);
                for (int i = 0; i < MOB_MERGE_CELL_CAP; i++)
                    rotated.add(combined.get((cellStart + i) % combined.size()));
                combined = rotated;
            }
            processed += mergeCell(combined);
        }
    }

    private static void addBucket(java.util.Map<Long, java.util.List<LivingEntity>> buckets,
                                  java.util.List<LivingEntity> out, int cx, int cz) {
        long key = ((long) cx & 0x7fffffffL) | (((long) cz & 0x7fffffffL) << 31);
        java.util.List<LivingEntity> b = buckets.get(key);
        if (b != null) out.addAll(b);
    }

    /** Merge trong 1 cell da gom forward-neighbor. Nguyen ven logic goc
     *  (v67.56 stack lon song sot, v4.04 left<=0 moi remove). */
    private int mergeCell(java.util.List<LivingEntity> mobs) {
        // PATCH 2026-09-28 (loi #31 - TPS): getStackCount doc PDC tren
        // entity (DAT) - truoc day doc lai cho MOI CAP (i,j). Pre-compute
        // 1 lan (dung pattern da fix o mergeBucket loi #28 / mergeCross).
        java.util.IdentityHashMap<LivingEntity, Integer> counts = new java.util.IdentityHashMap<>();
        for (LivingEntity le : mobs) counts.put(le, getStackCount(le));
        // FIX 2026-09-28 (loi #11 - TPS): pre-compute Location DUNG 1 LAN.
        // isMergeable cu goi a.getLocation() + b.getLocation() cho MOI CAP
        // (i,j) - cell cap 256 = ~32k cap x 2 Location alloc moi merge tick.
        org.bukkit.Location[] locs = new org.bukkit.Location[mobs.size()];
        for (int k = 0; k < mobs.size(); k++) locs[k] = mobs.get(k).getLocation();

        // v28p6 FIX (loi #22): dem so MERGE THUC HIEN thay so target duyet
        // qua - cell toan mob khong merge duoc truoc day tieu het budget
        // 500/tick, cac cell sau bi bo doi.
        int merged = 0;
        for (int i = 0; i < mobs.size(); i++) {
            LivingEntity target = mobs.get(i);
            if (!target.isValid() || target.isDead()) continue;
            int targetCount = counts.get(target);

            for (int j = i + 1; j < mobs.size(); j++) {
                LivingEntity source = mobs.get(j);
                if (!source.isValid() || source.isDead()) continue;

                if (!isMergeable(target, source, locs[i], locs[j])) continue;

                int sourceCount = counts.get(source);
                // v67.56 THONG MINH: stack LON HON luon song sot
                LivingEntity big = sourceCount >= targetCount ? source : target;
                LivingEntity small = sourceCount >= targetCount ? target : source;
                int bigCount = Math.max(targetCount, sourceCount);
                int smallCount = Math.min(targetCount, sourceCount);
                int space = maxStack - bigCount;
                if (space <= 0) {
                    if (big == target) break;
                    continue;
                }
                int move = Math.min(space, smallCount);
                setStackCount(big, bigCount + move);
                counts.put(big, bigCount + move);
                merged++;
                int left = smallCount - move;
                // v4.04 FIX: left <= 0 moi remove - truoc day left <= 1 xoa ca
                // entity khi stack nho con dung 1 con -> mat mob that.
                if (left <= 0) {
                    small.remove();
                } else {
                    setStackCount(small, left);
                    counts.put(small, left);
                }
                if (big == target) {
                    targetCount = bigCount + move;
                    if (targetCount >= maxStack) break;
                } else {
                    targetCount = smallCount - move;
                    if (targetCount <= 1) break;
                }
            }
        }
        return merged;
    }

    private boolean isMergeable(LivingEntity a, LivingEntity b,
                                org.bukkit.Location la, org.bukkit.Location lb) {
        return isMergeableNoDist(a, b) && nearEnough(la, lb, radius);
    }

    private boolean nearEnough(Location la, Location lb, double r) {
        if (la.getWorld() != lb.getWorld()) return false;
        double dx = la.getX() - lb.getX();
        double dz = la.getZ() - lb.getZ();
        // PATCH v28p7-batch5 (loi #3): them check Y - truoc day chi check
        // XZ nen 2 mob o 2 TANG spawner chong nhau bi gop xuyen san.
        // Y tolerance CLAMP 3.0: mob nhay/knockback chenh ~2-3 block van
        // merge duoc; tang spawner cach nhau >= 4 block thi khong bao gio
        // gop xuyen tang.
        double dy = la.getY() - lb.getY();
        double rY = Math.min(r, 3.0);
        return (dx * dx + dz * dz) <= (r * r) && (dy * dy) <= (rY * rY);
    }

    /** Kiem hop le KHONG kem khoang cach (cho attract radius lon hon). */
    private boolean isMergeableNoDist(LivingEntity a, LivingEntity b) {
        if (a.getType() != b.getType()) return false;
        // v67.25: Slime/MagmaCube khac size khong gop
        if (a instanceof org.bukkit.entity.Slime && b instanceof org.bukkit.entity.Slime
                && ((org.bukkit.entity.Slime) a).getSize() != ((org.bukkit.entity.Slime) b).getSize()) return false;
        // Creeper dang nap dien khong gop voi creeper thuong
        if (a instanceof org.bukkit.entity.Creeper && b instanceof org.bukkit.entity.Creeper
                && ((org.bukkit.entity.Creeper) a).isPowered() != ((org.bukkit.entity.Creeper) b).isPowered()) return false;
        // Cung trang thai con/truong thanh
        boolean aBaby = isBaby(a);
        boolean bBaby = isBaby(b);
        if (aBaby != bBaby) return false;

        // ===== v67.57 PHAN BIET DANG CAP: mau long / bien the / gien =====
        if (a instanceof org.bukkit.entity.Sheep && b instanceof org.bukkit.entity.Sheep
                && ((org.bukkit.entity.Sheep) a).getColor() != ((org.bukkit.entity.Sheep) b).getColor()) return false;
        if (a instanceof org.bukkit.entity.Wolf && b instanceof org.bukkit.entity.Wolf
                && ((org.bukkit.entity.Wolf) a).getVariant() != ((org.bukkit.entity.Wolf) b).getVariant()) return false;
        if (a instanceof org.bukkit.entity.Cat && b instanceof org.bukkit.entity.Cat
                && ((org.bukkit.entity.Cat) a).getCatType() != ((org.bukkit.entity.Cat) b).getCatType()) return false;
        if (a instanceof org.bukkit.entity.Rabbit && b instanceof org.bukkit.entity.Rabbit
                && ((org.bukkit.entity.Rabbit) a).getRabbitType() != ((org.bukkit.entity.Rabbit) b).getRabbitType()) return false;
        if (a instanceof org.bukkit.entity.Parrot && b instanceof org.bukkit.entity.Parrot
                && ((org.bukkit.entity.Parrot) a).getVariant() != ((org.bukkit.entity.Parrot) b).getVariant()) return false;
        if (a instanceof org.bukkit.entity.Fox && b instanceof org.bukkit.entity.Fox
                && ((org.bukkit.entity.Fox) a).getFoxType() != ((org.bukkit.entity.Fox) b).getFoxType()) return false;
        if (a instanceof org.bukkit.entity.MushroomCow && b instanceof org.bukkit.entity.MushroomCow
                && ((org.bukkit.entity.MushroomCow) a).getVariant() != ((org.bukkit.entity.MushroomCow) b).getVariant()) return false;
        if (a instanceof org.bukkit.entity.Axolotl && b instanceof org.bukkit.entity.Axolotl
                && ((org.bukkit.entity.Axolotl) a).getVariant() != ((org.bukkit.entity.Axolotl) b).getVariant()) return false;
        if (a instanceof org.bukkit.entity.Frog && b instanceof org.bukkit.entity.Frog
                && ((org.bukkit.entity.Frog) a).getVariant() != ((org.bukkit.entity.Frog) b).getVariant()) return false;
        if (a instanceof org.bukkit.entity.Horse && b instanceof org.bukkit.entity.Horse) {
            org.bukkit.entity.Horse ha = (org.bukkit.entity.Horse) a;
            org.bukkit.entity.Horse hb = (org.bukkit.entity.Horse) b;
            if (ha.getColor() != hb.getColor() || ha.getStyle() != hb.getStyle()) return false;
        }
        if (a instanceof org.bukkit.entity.Llama && b instanceof org.bukkit.entity.Llama
                && ((org.bukkit.entity.Llama) a).getColor() != ((org.bukkit.entity.Llama) b).getColor()) return false;
        if (a instanceof org.bukkit.entity.Panda && b instanceof org.bukkit.entity.Panda) {
            org.bukkit.entity.Panda pa = (org.bukkit.entity.Panda) a;
            org.bukkit.entity.Panda pb = (org.bukkit.entity.Panda) b;
            if (pa.getMainGene() != pb.getMainGene() || pa.getHiddenGene() != pb.getHiddenGene()) return false;
        }
        if (a instanceof org.bukkit.entity.Goat && b instanceof org.bukkit.entity.Goat
                && ((org.bukkit.entity.Goat) a).isScreaming() != ((org.bukkit.entity.Goat) b).isScreaming()) return false;

        // KHONG gop mob mac do/cam vu khi - bao ve do roi (tat bang
        // stacking.mobs.protect-geared: false neu muon gop tat)
        // PATCH 2026-09-27 (loi #10): sua cu phap if bi be o v4.17 FIX P2-GEARED
        if (protectGearedCached && (hasGearCached(a) || hasGearCached(b))) return false;
        return true;
    }

    /** Co giap hoac cam do tren nguoi khong (gom ca tay 2). */
    private boolean hasGearCached(org.bukkit.entity.LivingEntity le) {
        return gearCache.computeIfAbsent(le.getUniqueId(), k -> hasGear(le));
    }

    private boolean hasGear(org.bukkit.entity.LivingEntity le) {
        org.bukkit.inventory.EntityEquipment eq = le.getEquipment();
        if (eq == null) return false;
        for (org.bukkit.inventory.ItemStack it : eq.getArmorContents()) {
            if (it != null && !it.getType().isAir()) return true;
        }
        return (eq.getItemInMainHand() != null && !eq.getItemInMainHand().getType().isAir())
            || (eq.getItemInOffHand() != null && !eq.getItemInOffHand().getType().isAir());
    }

    // Dùng interface Ageable (Bukkit chuẩn) thay reflection - reflection
    // trong vòng lặp O(n^2) gây lag đáng kể với bầy mob lớn.
    private boolean isBaby(LivingEntity entity) {
        if (entity instanceof org.bukkit.entity.Ageable) {
            return !((org.bukkit.entity.Ageable) entity).isAdult();
        }
        return false; // Mob không có tuổi -> coi như trưởng thành
    }
}
