# MauaHopper 4.04-PATCHED-v28-audit-final

Bao gom toan bo cac batch truoc + audit final fixes.

## Audit final fixes
- P1: cache NMS reflection cho crafter auto-retrigger.
- P8: cooldown sort-all/smelt-all + cap/xoay vong collector workload.
- S2: foundAny chi dat sau blacklist/line-of-sight hop le.
- S3: bo handler VehicleCreateEvent trung lap.
- S7: cache NamespacedKey stack_amount trong BigChestManager.
- S9: hologram tim item bang passenger thay vi Bukkit.getEntity.
- S10: cache NamespacedKey trong DuplicationProtector.
- S14: SpeedManager.setEnabled dong bo ConfigManager.hopperEnabled.

## Ghi chu
Da xu ly het cac diem uu tien cao/trung binh con lai tu audit; cac diem rat nho khong con anh huong ro rang.
