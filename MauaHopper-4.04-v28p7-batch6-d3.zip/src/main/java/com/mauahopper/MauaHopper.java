package com.mauahopper;

import org.bukkit.Bukkit;
import org.bukkit.plugin.IllegalPluginAccessException;
import org.bukkit.plugin.java.JavaPlugin;

public class MauaHopper extends JavaPlugin {

    private static MauaHopper instance;

    private ConfigManager        configManager;
    private SpeedManager         speedManager;
    private PerformanceOptimizer performanceOptimizer;
    private DuplicationProtector duplicationProtector;
    private WorldManager         worldManager;
    private HopperTicker         hopperTicker;
    private PlayerToggleManager  playerToggleManager;
    private ItemStackingManager  itemStackingManager;
    private MobStackingManager   mobStackingManager;

    private volatile boolean isActive    = true;
    private volatile boolean shuttingDown = false;

    // RELOAD SAFETY: tracking async config write de reload/disable co the
    // flush dung snapshot, tranh doc/ghi config bi race hoac mat du lieu.
    private final Object configSaveLock = new Object();
    private org.bukkit.scheduler.BukkitTask pendingConfigSaveTask;
    private String pendingConfigSaveYaml;
    private boolean configSaveRunning;
    private int configSaveGeneration;
    // v28p6 FIX (loi #1): co che "gen khop moi ghi" cu de lo khoang tran:
    // writer da nhan snapshot, flush capture null + bump gen -> writer bo
    // qua, ma flush khong giu gi -> MAT CONFIG. Doi sang last-written-gen:
    // snapshot chi bi bo qua khi da co nguoi ghi dung no (hoac moi hon).
    private int configSaveLastWritten;
    // v28p6 FIX (loi #1): snapshot di kem the he de flush biet minh dang
    // ghi snapshot thu may (configSaveGeneration da bi bump luc capture).
    private int pendingConfigSaveGen;

    @Override
    public void onEnable() {
        instance = this;
        // FIX v4.04.1: reset shuttingDown - truoc day onDisable() set true
        // ma onEnable() khong set lai false -> sau reload server / PlugMan,
        // runTick() return ngay dong dau -> plugin "chet" vinh vien, khong
        // mot dong loi nao duoc in ra.
        shuttingDown = false;
        isActive     = true;

        try {
            configManager        = new ConfigManager(this);
            speedManager         = new SpeedManager(this);
            performanceOptimizer = new PerformanceOptimizer(this);
            duplicationProtector = new DuplicationProtector(this);
            worldManager         = new WorldManager(this);
            playerToggleManager  = new PlayerToggleManager(this);

            hopperTicker = new HopperTicker(this);
            itemStackingManager = new ItemStackingManager(this);
            itemStackingManager.start();
            mobStackingManager = new MobStackingManager(this);
            mobStackingManager.start();

            // v4.16 FIX P1-8: start ticker SAU KHI moi manager san sang - tick dau
            // khong the cham vao itemStackingManager/mobStackingManager dang null.
            hopperTicker.start();

            isActive = configManager.toggleDefaultEnabled;

            registerCommands();

            getLogger().info("MauaHopper " + getDescription().getVersion() + " đã bật (Paper 1.21+)"); // v4.16 FIX P2-13

        } catch (Exception e) {
            getLogger().severe("MauaHopper bật thất bại: " + e.getMessage() + " | " + e); // v67.18: thay printStackTrace, van day du stack qua logger
            getServer().getPluginManager().disablePlugin(this);
        }
    }

    /** GREEN FIX: luu config async bang snapshot YAML, tranh I/O sync tren main.
     *  RELOAD SAFETY: snapshot duoc tracking de reload/disable co the flush. */
    public void saveConfigAsync() {
        synchronized (configSaveLock) {
            pendingConfigSaveYaml = getConfig().saveToString();
            final int generation = ++configSaveGeneration;
            pendingConfigSaveGen = generation;
            if (pendingConfigSaveTask != null) pendingConfigSaveTask.cancel();
            pendingConfigSaveTask = Bukkit.getScheduler().runTaskAsynchronously(this, () -> writePendingConfigSave(generation));
        }
    }

    private void writePendingConfigSave(int generation) {
        final String yaml;
        synchronized (configSaveLock) {
            yaml = pendingConfigSaveYaml;
            pendingConfigSaveYaml = null;
            pendingConfigSaveTask = null;
            configSaveRunning = true;
        }
        boolean fallbackScheduled = false;
        try {
            // v28p6 FIX (loi #1): ghi khi snapshot nay CHUA AI ghi (thay vi
            // chi khi gen khop). Cu: writer thay gen lech (do flush bump khi
            // da capture null) la bo qua -> snapshot khong ai ghi, mat config.
            synchronized (configSaveLock) {
                if (yaml != null && generation > configSaveLastWritten) {
                    writeConfigSnapshot(yaml);
                    configSaveLastWritten = generation;
                }
            }
        } catch (Throwable t) {
            getLogger().severe("Khong the luu config async: " + t);
            // v28p6 FIX (loi #2): giai phong configSaveRunning + notify NGAY,
            // truoc khi schedule fallback. Cu: flag chi duoc clear trong
            // finally cua fallback - flush cancel task -> flag khet true vinh
            // vien, moi lan flush doi du 300ms + warning.
            synchronized (configSaveLock) {
                if (pendingConfigSaveYaml == null) pendingConfigSaveYaml = yaml;
                configSaveRunning = false;
                configSaveLock.notifyAll();
            }
            try {
                // RELOAD SAFETY: fallback sync nam trong cung tracking lock,
                // reload khong the doc config cu truoc khi fallback chay.
                pendingConfigSaveTask = Bukkit.getScheduler().runTask(this, () -> {
                    try {
                        synchronized (configSaveLock) {
                            if (yaml != null && generation > configSaveLastWritten) {
                                writeConfigSnapshot(yaml);
                                configSaveLastWritten = generation;
                            }
                        }
                    } catch (Throwable t2) {
                        getLogger().severe("Fallback config save failed: " + t2);
                        saveConfig();
                    } finally {
                        synchronized (configSaveLock) {
                            pendingConfigSaveTask = null;
                            pendingConfigSaveYaml = null;
                            configSaveLock.notifyAll();
                        }
                    }
                });
            } catch (IllegalPluginAccessException | IllegalStateException shutdownEx) {
                // v28p6 FIX (loi #1): scheduler da dong (server dang tat),
                // fallback khong schedule duoc - ghi truc tiep tren luong
                // nay (file I/O thuan, khong can scheduler) cho het mat
                // snapshot.
                try {
                    synchronized (configSaveLock) {
                        if (yaml != null && generation > configSaveLastWritten) {
                            writeConfigSnapshot(yaml);
                            configSaveLastWritten = generation;
                            pendingConfigSaveYaml = null;
                        }
                    }
                } catch (Throwable t3) {
                    getLogger().severe("Fallback truc tiep config save failed: " + t3);
                    saveConfig();
                }
            }
            fallbackScheduled = true;
        } finally {
            if (!fallbackScheduled) {
                synchronized (configSaveLock) {
                    configSaveRunning = false;
                    configSaveLock.notifyAll();
                }
            }
        }
    }

    private void writeConfigSnapshot(String yaml) throws java.io.IOException {
        // p9 FIX: ghi qua temp roi ATOMIC MOVE - crash giua luc ghi truoc
        // day co the de lai config.yml bi cat doi (corrupt, khoi dong sau
        // bi reset toan bo cau hinh).
        java.io.File target = new java.io.File(getDataFolder(), "config.yml");
        java.io.File tmp = new java.io.File(getDataFolder(), "config.yml.tmp");
        java.nio.file.Files.writeString(tmp.toPath(), yaml);
        try {
            java.nio.file.Files.move(tmp.toPath(), target.toPath(),
                    java.nio.file.StandardCopyOption.ATOMIC_MOVE,
                    java.nio.file.StandardCopyOption.REPLACE_EXISTING);
        } catch (java.nio.file.AtomicMoveNotSupportedException ex) {
            java.nio.file.Files.move(tmp.toPath(), target.toPath(),
                    java.nio.file.StandardCopyOption.REPLACE_EXISTING);
        }
    }

    /** RELOAD SAFETY: goi truoc khi doc lai config hoac tat plugin. */
    public void flushConfigSave() {
        org.bukkit.scheduler.BukkitTask task;
        String yaml;
        int yamlGen;
        synchronized (configSaveLock) {
            task = pendingConfigSaveTask;
            yaml = pendingConfigSaveYaml;
            yamlGen = pendingConfigSaveGen;
            pendingConfigSaveTask = null;
            pendingConfigSaveYaml = null;
        }
        // AUDIT FIX B1/B2: bump generation trong cung lock roi ghi snapshot.
        // Writer cu du chay toi dau cung se thay generation lech va bo qua.
        synchronized (configSaveLock) {
            configSaveGeneration++;
            if (task != null) task.cancel();
            if (yaml != null) {
                try {
                    writeConfigSnapshot(yaml);
                    // v28p6 FIX (loi #1): danh dau snapshot da duoc ghi - writer
                    // /fallback tre voi cung the he thay vay biet ma bo qua,
                    // khong ghi de (cung khong bi bo qua khi flush chua ghi).
                    if (yamlGen > configSaveLastWritten) configSaveLastWritten = yamlGen;
                }
                catch (Throwable t) { getLogger().severe("Khong the flush config save: " + t); saveConfig(); }
            }
        }
        synchronized (configSaveLock) {
            // FIX TPS 2026-09-28: busy-wait 1000ms -> 300ms. Viec ghi file
            // config.yml chi la vai KB - 300ms la qua du; 1s main thread
            // bi chan o onDisable/reload gay TPS drop thay ro.
            // PATCH v28p7-batch5 (loi #4): giam xuong 50ms. Snapshot MOI NHAT
            // da duoc ghi DONG BO o khoi synchronized phia tren (dong
            // writeConfigSnapshot) va generation da duoc bump - writer async
            // dang chay toi dau cung thay generation lech ma bo qua, khong
            // ghi de file. Viec cho them 300ms khong bao ve them gi ca, chi
            // tang lag spike reload/shutdown vo ly. 50ms la du de cho I/O
            // hoan tat trong dieu kien binh thuong; neu qua han, saveConfig()
            // fallback van chay (chi la vai KB tren main, khong dang ke).
            long deadline = System.currentTimeMillis() + 50L;
            while (configSaveRunning && System.currentTimeMillis() < deadline) {
                try { configSaveLock.wait(50L); }
                catch (InterruptedException ie) { Thread.currentThread().interrupt(); break; }
            }
            if (configSaveRunning) {
                getLogger().warning("Async config save van dang chay sau khi flush cho 50ms.");
                // v28p6 FIX (loi #7): duong hap I/O bat thuong - ghi dong bo
                // snapshot MOI NHAT tu bo nho truoc khi nguoi goi doc lai
                // config (reload), tranh doc dung file dang viet do.
                // PATCH v28p7-batch6-d3 (loi #8): saveConfig() fallback
                // phai nam TRONG configSaveLock - writer async dang giu lock
                // suot write+move, fallback khong lock bi writer ghi de file
                // bang YAML CU sau khi no chay xong. Cho lock = writer xong
                // moi save, du lieu moi nhat thang.
                try { synchronized (configSaveLock) { saveConfig(); } }
                catch (Throwable t) { getLogger().severe("Last-resort saveConfig() failed: " + t); }
            }
        }
    }

    @Override
    public void onDisable() {
        shuttingDown = true;
        // v28p6 FIX (loi #36): cancel timer don UUID dinh ky (toggle manager)
        // truoc khi disable - tranh task mo neu plugin bi enable lai.
        if (playerToggleManager != null) playerToggleManager.shutdown();
        flushConfigSave();
        if (hopperTicker != null) hopperTicker.stop();
        if (itemStackingManager != null) itemStackingManager.stop();
        if (mobStackingManager != null) mobStackingManager.stop();
        getLogger().info("MauaHopper đã tắt.");
    }

    private void registerCommands() {
        MainCommand main = new MainCommand(this);
        // FIX v4.04.1: null-check getCommand() - neu plugin.yml thieu khai
        // bao mot lenh nao do, getCommand() tra null -> NPE -> plugin tu
        // disable trong luc listener/task da dang ky mot phan.
        org.bukkit.command.PluginCommand mhCmd = getCommand("mauahopper");
        if (mhCmd != null) { mhCmd.setExecutor(main); mhCmd.setTabCompleter(main); }
        ShulkerCommand shulker = new ShulkerCommand(this);
        org.bukkit.command.PluginCommand hsCmd = getCommand("hoppershulk");
        if (hsCmd != null) { hsCmd.setExecutor(shulker); hsCmd.setTabCompleter(shulker); } // v4.17 FIX P3-SHULKER
    }

    public void reloadConfiguration() {
        // RELOAD SAFETY: config async phai duoc ghi xong truoc khi doc lai.
        flushConfigSave();
        configManager.load();
        speedManager.reload();
        worldManager.reload();
        if (itemStackingManager != null) itemStackingManager.reload();
        if (mobStackingManager != null) mobStackingManager.reload();
        if (hopperTicker != null) hopperTicker.clearBurstState();
        // v4.16 FIX P1-5: /mh reload KHONG duoc ghi de lua chon thu cong cua admin
        // (/mh off roi reload phai VAN tat). toggle_default_enabled chi ap dung luc
        // khoi dong trong onEnable.
    }

    // =========================================================================
    // Accessors
    // =========================================================================

    public static MauaHopper getInstance()                          { return instance; }
    public ConfigManager getConfigManager()                          { return configManager; }
    public SpeedManager getSpeedManager()                            { return speedManager; }
    public PerformanceOptimizer getPerformanceOptimizer()            { return performanceOptimizer; }
    public DuplicationProtector getDuplicationProtector()            { return duplicationProtector; }
    public WorldManager getWorldManager()                            { return worldManager; }
    public HopperTicker getHopperTicker()                            { return hopperTicker; }
    public PlayerToggleManager getPlayerToggleManager()              { return playerToggleManager; }
    public ItemStackingManager getItemStackingManager()              { return itemStackingManager; }
    public MobStackingManager getMobStackingManager()                { return mobStackingManager; }

    public boolean isActive()                                        { return isActive; }
    public void setActive(boolean active)                            { this.isActive = active; }
    public boolean isShuttingDown()                                  { return shuttingDown; }


    public static void warnSafe(String msg, Exception ex) {
        org.bukkit.Bukkit.getLogger().log(java.util.logging.Level.WARNING, "[MauaHopper] " + msg, ex);
    }

    public static void fineSafe(String msg, Exception ex) {
        org.bukkit.Bukkit.getLogger().log(java.util.logging.Level.FINE, "[MauaHopper] " + msg, ex);
    }
}
