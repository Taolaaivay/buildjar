package com.mauahopper;

import java.util.concurrent.atomic.AtomicLong;
import java.util.logging.Logger;

public class PerformanceOptimizer {

    private final MauaHopper plugin;

    // Lifetime counters
    private final AtomicLong totalItemsMoved    = new AtomicLong(0);
    private final AtomicLong totalTransfers     = new AtomicLong(0);

    // Per-tick live counters (reset each tick)
    private volatile long liveItems     = 0;
    private volatile long liveTransfers = 0;

    // Timing
    private volatile long lastTickNs   = 0;
    private volatile long lastTickMs   = 0;

    public PerformanceOptimizer(MauaHopper plugin) {
        this.plugin = plugin;
    }

    private long tickCount = 0;
    private boolean logPerfCached = false;

    public void startTick() {
        lastTickNs  = System.nanoTime();
        liveItems   = 0;
        liveTransfers = 0;
        // v4.16 FIX P2-9: cache config flag, chi doc YAML 1 lan/20 tick thay vi moi tick
        if (++tickCount % 20 == 0)
            logPerfCached = plugin.getConfig().getBoolean("debug.log_performance", false);
    }

    public void endTick() {
        lastTickMs = (System.nanoTime() - lastTickNs) / 1_000_000L;

        if (logPerfCached) {
            Logger logger = plugin.getLogger();
            logger.info("[Perf] Tick mất " + lastTickMs + "ms, items=" + liveItems);
        }
    }

    public void recordHopperItemsMoved(int items) {
        liveItems += items;
        totalItemsMoved.addAndGet(items);
    }

    public void recordTransfer() {
        liveTransfers++;
        totalTransfers.incrementAndGet();
    }

    /** GREEN FIX: throttle theo server TPS uoc luong MSPT, khong phai chi HopperTicker tick.
     *  FIX TPS 2026-09-28: tps[0] la trung binh 1 PHUT - khi server vua qua
     *  tai, uoc luong nay phan ung cham hang chuc giay, throttle kich hoat
     *  qua tre de cuu TPS. Ket hop MSPT tuc thi cua tick moi nhat
     *  (lastTickMs) voi uoc luong TPS -> lay MIN -> kich hoat som va dung. */
    public boolean shouldThrottle() {
        int threshold = plugin.getConfigManager().msptThrottleMs;
        if (threshold <= 0) return false;
        // v28p6 FIX (loi #35): lastTickMs stale khi ticker nghi (plugin
        // inactive / early-return truoc endTick) - con so tick rieng cu van
        // duoc dem vao quyet dinh throttle. Chi tinh instant khi no vua duoc
        // do trong ~2 tick gan nhat, nguoc lai chi tinh uoc luong TPS.
        boolean instantFresh = (System.nanoTime() - lastTickNs) < 100_000_000L;
        long instant = lastTickMs;
        // 1. Tick noi bo cua plugin vuot nguong -> nghi cho tick sau nhe.
        if (instantFresh && instant >= threshold) return true;
        // 2. Server lag theo TPS trung binh 1 phut. PATCH v28p7-batch5-p3d
        // (BUG NGHIEM TRONG - bao cao nguoi dung: "do vao hopper khong
        // truyen, vut do len khong hut"): ban MAX cua loi #18 dung
        // Math.max(instant, estimatedMspt) >= threshold - estimatedMspt o
        // TPS 20 hoan hao = 1000/20 = 50ms LUON >= moi threshold < 50 ->
        // shouldThrottle() TRUE VINH VIEN -> runTick return som -> khong
        // transfer, khong pickup, KHONG exception (hanh vi "dung theo code"
        // nen rat kho phat hien). Jar cu chay duoc vi build tu nguon dung
        // MIN. Fix: estimatedMspt chi duoc coi la "lag" khi VUOT tick chuan
        // 50ms (tuc TPS trung binh < 20); TPS 20 hoan hao khong bao gio
        // throttle.
        double[] tps = org.bukkit.Bukkit.getTPS();
        double estimatedMspt = tps[0] > 0 ? 1000.0 / tps[0] : Double.MAX_VALUE;
        // PATCH v28p7-batch6-d1 (loi #2 - CRITICAL): '50.0' cung lam nguong
        // lam ngat config mspt_throttle_ms TREN DUONG TPS - admin dat 100 van
        // bi throttle tu MSPT 51. Phai so voi threshold. tps[0]==0 ->
        // MAX_VALUE -> luon throttle (dung - server da sap).
        return estimatedMspt >= threshold;
    }

    public long getTotalItemsMoved()    { return totalItemsMoved.get(); }
    public long getTotalTransfers()     { return totalTransfers.get(); }
    public long getLiveItems()          { return liveItems; }
    public long getLiveTransfers()      { return liveTransfers; }
    public long getLastTickMs()         { return lastTickMs; }

    public void resetStats() {
        totalItemsMoved.set(0);
        totalTransfers.set(0);
    }
}
