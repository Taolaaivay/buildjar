package com.mauahopper;

public class SpeedManager {

    private final MauaHopper plugin;
    private int transferTicks;
    private int transferAmount;
    private boolean enabled;

    public SpeedManager(MauaHopper plugin) {
        this.plugin = plugin;
        ConfigManager cfg = plugin.getConfigManager();
        this.transferTicks  = cfg.transferTicks;
        this.transferAmount = cfg.transferAmount;
        this.enabled        = cfg.hopperEnabled;
    }

    public int getTransferTicks()  { return transferTicks; }
    public int getTransferAmount() { return transferAmount; }
    public boolean isEnabled()     { return enabled; }

    // PATCH 2026-09-27 (loi #2 + #16 + #9):
    // - #2: dung saveConfigAsync() snapshot YAML tren main roi ghi file async,
    //   tranh I/O sync nhung khong cham truc tiep object config tu worker.
    // - #16: /mh amount TRUOC DAY VO HIEU - ticker chi doc
    //   ConfigManager.getEffectivePush/PullAmount(), field SpeedManager khong
    //   ai doc. Bay gio setTransfer* cap nhat DONG THOI ca 2 nguon state.
    public void setTransferTicks(int ticks) {
        this.transferTicks = Math.max(0, ticks);
        plugin.getConfigManager().transferTicks = this.transferTicks;
        plugin.getConfig().set("hopper.transfer_ticks", this.transferTicks);
        plugin.saveConfigAsync();
    }

    public void setTransferAmount(int amount) {
        this.transferAmount = Math.max(1, amount);
        plugin.getConfigManager().transferAmount = this.transferAmount;
        plugin.getConfig().set("hopper.transfer_amount", this.transferAmount);
        plugin.saveConfigAsync();
    }

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
        // AUDIT FIX S14: khong de dead state - dong bo ConfigManager field.
        plugin.getConfigManager().hopperEnabled = enabled;
    }

    /** Reload from config after a /dh reload. */
    public void reload() {
        ConfigManager cfg = plugin.getConfigManager();
        this.transferTicks  = cfg.transferTicks;
        this.transferAmount = cfg.transferAmount;
        this.enabled        = cfg.hopperEnabled;
    }
}
