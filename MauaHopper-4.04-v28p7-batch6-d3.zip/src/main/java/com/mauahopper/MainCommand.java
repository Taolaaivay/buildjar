package com.mauahopper;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

public class MainCommand implements CommandExecutor, TabCompleter {

    private final MauaHopper plugin;

    public MainCommand(MauaHopper plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 0) {
            sendHelp(sender);
            return true;
        }

        return switch (args[0].toLowerCase(Locale.ROOT)) {
            case "reload" -> handleReload(sender, args);
            case "speed"  -> handleSpeed(sender, args);
            case "amount" -> handleAmount(sender, args);
            case "stats"  -> handleStats(sender, args);
            case "toggle" -> handleToggle(sender, args);
            case "status" -> handleStatus(sender, args);
            default -> { sendHelp(sender); yield true; }
        };
    }

    private boolean handleReload(CommandSender sender, String[] args) {
        if (!sender.hasPermission("mauahopper.reload")) { noPermission(sender); return true; }
        try {
            plugin.reloadConfiguration();
            sender.sendMessage(color(plugin.getConfigManager().getMessage("reload_success")));
        } catch (Exception | LinkageError e) { // p10: bat ca LinkageError/NoClassDefFoundError
            sender.sendMessage(color(plugin.getConfigManager().getMessage("reload_failed")));
            plugin.getLogger().warning("Reload that bai: " + e); // v67.18: thay printStackTrace
        }
        return true;
    }

    private boolean handleSpeed(CommandSender sender, String[] args) {
        if (!sender.hasPermission("mauahopper.speed")) { noPermission(sender); return true; }
        if (args.length < 2) { sender.sendMessage(color(plugin.getConfigManager().getMessage("usage_speed"))); return true; }
        try {
            int ticks = Integer.parseInt(args[1]);
            // p10: clamp ca 2 phia - gia tri cuc dai dua cooldown vao vung vo nghia
            if (ticks < 0 || ticks > 200) { sender.sendMessage(color(plugin.getConfigManager().getMessage("negative_not_allowed"))); return true; }
            plugin.getSpeedManager().setTransferTicks(ticks);
            sender.sendMessage(color(plugin.getConfigManager().getMessage("speed_changed", "ticks", ticks)));
        } catch (NumberFormatException e) {
            sender.sendMessage(color(plugin.getConfigManager().getMessage("invalid_number")));
        }
        return true;
    }

    private boolean handleAmount(CommandSender sender, String[] args) {
        if (!sender.hasPermission("mauahopper.amount")) { noPermission(sender); return true; }
        if (args.length < 2) { sender.sendMessage(color(plugin.getConfigManager().getMessage("usage_amount"))); return true; }
        try {
            int amount = Integer.parseInt(args[1]);
            // p10: clamp tren - >10 stack/tick khong con nghia
            if (amount < 1 || amount > 640) { sender.sendMessage(color(plugin.getConfigManager().getMessage("negative_not_allowed"))); return true; }
            plugin.getSpeedManager().setTransferAmount(amount);
            sender.sendMessage(color(plugin.getConfigManager().getMessage("amount_changed", "amount", amount)));
        } catch (NumberFormatException e) {
            sender.sendMessage(color(plugin.getConfigManager().getMessage("invalid_number")));
        }
        return true;
    }

    private boolean handleStats(CommandSender sender, String[] args) {
        if (!sender.hasPermission("mauahopper.stats")) { noPermission(sender); return true; }

        if (args.length >= 2 && args[1].equalsIgnoreCase("reset")) {
            if (!sender.hasPermission("mauahopper.stats.reset")) { noPermission(sender); return true; }
            plugin.getPerformanceOptimizer().resetStats();
            plugin.getDuplicationProtector().resetStats();
            plugin.getHopperTicker().resetSpecialBlockStats();
            sender.sendMessage(color(plugin.getConfigManager().getMessage("stats_reset")));
            return true;
        }

        ConfigManager        cfg    = plugin.getConfigManager();
        PerformanceOptimizer perf   = plugin.getPerformanceOptimizer();
        DuplicationProtector dupe   = plugin.getDuplicationProtector();
        HopperTicker         ticker = plugin.getHopperTicker();

        sender.sendMessage(color(plugin.getConfigManager().getMessage("stats_header")));
        sender.sendMessage(color(plugin.getConfigManager().getMessage("stats_active",           "count",  ticker.getReadyHopperCount())));
        sender.sendMessage(color(plugin.getConfigManager().getMessage("stats_registered",       "count",  ticker.getRegisteredHopperCount())));
        sender.sendMessage(color(plugin.getConfigManager().getMessage("stats_speed",            "ticks",  plugin.getSpeedManager().getTransferTicks())));
        sender.sendMessage(color(plugin.getConfigManager().getMessage("stats_amount",           "amount", plugin.getSpeedManager().getTransferAmount())));
        sender.sendMessage(color(plugin.getConfigManager().getMessage("stats_processed",        "total",  perf.getTotalItemsMoved())));
        sender.sendMessage(color(plugin.getConfigManager().getMessage("stats_transfers",        "total",  perf.getTotalTransfers())));
        sender.sendMessage(color(plugin.getConfigManager().getMessage("stats_live_items",       "count",  perf.getLiveItems())));
        sender.sendMessage(color(plugin.getConfigManager().getMessage("stats_live_transfers",   "count",  perf.getLiveTransfers())));
        sender.sendMessage(color(plugin.getConfigManager().getMessage("stats_blocked_dupes",    "count",  dupe.getBlockedDupes())));
        sender.sendMessage(color(plugin.getConfigManager().getMessage("stats_blocked_concurrent","count", dupe.getBlockedConcurrent())));
        sender.sendMessage(color(plugin.getConfigManager().getMessage("stats_composter_feeds",    "count", ticker.getComposterFeeds())));
        sender.sendMessage(color(plugin.getConfigManager().getMessage("stats_bonemeal_collected","count", ticker.getBonemealCollected())));
        sender.sendMessage(color(plugin.getConfigManager().getMessage("stats_cauldron_fills",    "count", ticker.getCauldronFills())));
        sender.sendMessage(color(plugin.getConfigManager().getMessage("stats_cauldron_drains",   "count", ticker.getCauldronDrains())));
        // PATCH v28p7-batch5-P3 (loi #14): truoc day hien thi duration tick
        // NOI BO cua plugin nhu the la MSPT cua server ("%.1f%% tick") - gay
        // hieu nham khi do hieu nang. Bay gio ghi ro "plugin" + them uoc
        // luong MSPT that cua server tu Bukkit.getTPS() (trung binh 1 phut).
        double[] tps = Bukkit.getTPS();
        double estMspt = tps[0] > 0 ? 1000.0 / tps[0] : -1;
        String msStr = estMspt > 0
                ? String.format("%.2fms (plugin - server ~%.1fms)", (double) perf.getLastTickMs(), estMspt)
                : String.format("%.2fms (plugin)", (double) perf.getLastTickMs());
        sender.sendMessage(color(plugin.getConfigManager().getMessage("stats_tick_ms", "ms", msStr)));
        return true;
    }

    private boolean handleToggle(CommandSender sender, String[] args) {
        if (!sender.hasPermission("mauahopper.toggle")) { noPermission(sender); return true; }

        ConfigManager cfg = plugin.getConfigManager();

        if (args.length == 3) {
            if (!sender.hasPermission("mauahopper.toggle.others")) { noPermission(sender); return true; }
            Player target = Bukkit.getPlayer(args[1]);
            if (target == null) { sender.sendMessage(color(plugin.getConfigManager().getMessage("player_not_found"))); return true; }
            if (!args[2].equalsIgnoreCase("on") && !args[2].equalsIgnoreCase("off")) {
                sender.sendMessage("\u00a7cDung: /mh toggle <player> <on|off>");
                return true;
            }
            boolean enable = args[2].equalsIgnoreCase("on");
            UUID uid = target.getUniqueId();
            if (enable) plugin.getPlayerToggleManager().enable(uid);
            else        plugin.getPlayerToggleManager().disable(uid);
            String key = enable ? "toggle_player_enabled" : "toggle_player_disabled";
            sender.sendMessage(color(plugin.getConfigManager().getMessage(key, "player", target.getName())));
            return true;
        }

        // p10 FIX: /mh toggle <player> (khong on/off) truoc day roi xuong
        // day toggle GLOBAL - gay hieu nham. Neu args[1] la ten player hop
        // le thi toggle player do.
        if (args.length == 2) {
            Player target = Bukkit.getPlayer(args[1]);
            if (target != null) {
                if (!sender.hasPermission("mauahopper.toggle.others")) { noPermission(sender); return true; }
                boolean now = plugin.getPlayerToggleManager().toggle(target.getUniqueId());
                String key = now ? "toggle_player_enabled" : "toggle_player_disabled";
                sender.sendMessage(color(plugin.getConfigManager().getMessage(key, "player", target.getName())));
                return true;
            }
        }

        // PATCH v28p7-batch6-d4 (loi #15): /mh toggle on|off truoc day
        // Bukkit.getPlayer("on") tra null -> roi xuong day TOGGLE GLOBAL
        // (hoac toggle ban than) - nguoi dung dinh bat/tat ai do lai vo tinh
        // DAO trang thai. Bay gio: global mode -> "on"/"off" = set ro rang
        // (khong dao), chuoi khong phai player -> hien usage. Player mode
        // -> "on"/"off" ap dung cho chinh sender.
        if (cfg.isGlobalToggleMode()) {
            if (args.length == 2) {
                if (args[1].equalsIgnoreCase("on") || args[1].equalsIgnoreCase("off")) {
                    boolean now = args[1].equalsIgnoreCase("on");
                    plugin.setActive(now);
                    sender.sendMessage(color(plugin.getConfigManager().getMessage(now ? "toggle_enabled" : "toggle_disabled")));
                    return true;
                }
                if (Bukkit.getPlayer(args[1]) == null) {
                    sender.sendMessage("\u00a7cDung: /mh toggle [player] [on|off]");
                    return true;
                }
            }
            boolean now = !plugin.isActive();
            plugin.setActive(now);
            sender.sendMessage(color(plugin.getConfigManager().getMessage(now ? "toggle_enabled" : "toggle_disabled")));
        } else {
            if (!(sender instanceof Player player)) {
                sender.sendMessage(color(plugin.getConfigManager().getMessage("player_only")));
                return true;
            }
            boolean now = plugin.getPlayerToggleManager().toggle(player.getUniqueId());
            sender.sendMessage(color(plugin.getConfigManager().getMessage(now ? "toggle_personal_enabled" : "toggle_personal_disabled")));
        }
        return true;
    }

    private boolean handleStatus(CommandSender sender, String[] args) {
        if (!sender.hasPermission("mauahopper.status")) { noPermission(sender); return true; }

        ConfigManager cfg   = plugin.getConfigManager();

        sender.sendMessage(color(plugin.getConfigManager().getMessage("status_header")));
        sender.sendMessage(color(plugin.getConfigManager().getMessage("status_enabled",     "status",   plugin.isActive() ? "&aBật" : "&cTắt")));
        sender.sendMessage(color(plugin.getConfigManager().getMessage("status_platform",    "platform", "Paper/Spigot")));
        sender.sendMessage(color(plugin.getConfigManager().getMessage("status_sync",        "mode",     "Xử lý theo lô")));
        sender.sendMessage(color(plugin.getConfigManager().getMessage("status_protection",  "mode",     cfg.protectionMode)));
        sender.sendMessage(color(plugin.getConfigManager().getMessage("status_toggle_mode", "mode",     cfg.toggleMode)));
        sender.sendMessage(color(plugin.getConfigManager().getMessage("status_worlds",      "mode",     plugin.getWorldManager().describeMode())));
        sender.sendMessage(color(plugin.getConfigManager().getMessage("status_live",
                "items",     plugin.getPerformanceOptimizer().getLiveItems(),
                "transfers", plugin.getPerformanceOptimizer().getLiveTransfers())));
        if (sender instanceof Player player) {
            boolean personal = plugin.getPlayerToggleManager().isEnabledFor(player.getUniqueId());
            sender.sendMessage(color(plugin.getConfigManager().getMessage("status_personal", "status", personal ? "&aBật" : "Inactive")));
        }
        return true;
    }

    private void sendHelp(CommandSender sender) {
        if (!sender.hasPermission("mauahopper.help")) { noPermission(sender); return; }
        sender.sendMessage(color(plugin.getConfigManager().getMessage("help_header")));
        sender.sendMessage(color(plugin.getConfigManager().getMessage("help_reload")));
        sender.sendMessage(color(plugin.getConfigManager().getMessage("help_speed")));
        sender.sendMessage(color(plugin.getConfigManager().getMessage("help_amount")));
        sender.sendMessage(color(plugin.getConfigManager().getMessage("help_stats")));
        sender.sendMessage(color(plugin.getConfigManager().getMessage("help_status")));
        if (plugin.getConfigManager().isGlobalToggleMode()) {
            sender.sendMessage(color(plugin.getConfigManager().getMessage("help_toggle")));
        } else {
            sender.sendMessage(color(plugin.getConfigManager().getMessage("help_toggle")));
            if (sender.hasPermission("mauahopper.toggle.others"))
                sender.sendMessage(color(plugin.getConfigManager().getMessage("help_toggle_player")));
        }
    }

    private void noPermission(CommandSender sender) {
        sender.sendMessage(color(plugin.getConfigManager().getMessage("no_permission")));
    }

    private static String color(String s) {
        return ChatColor.translateAlternateColorCodes('&', s);
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        List<String> completions = new ArrayList<>();
        if (args.length == 1) {
            List<String> subs = new java.util.ArrayList<>(Arrays.asList("reload", "speed", "amount", "stats", "toggle", "status"));
            // v4.16 FIX P2-12: chi goi y lenh ma nguoi choi co quyen dung
            if (!sender.hasPermission("mauahopper.reload")) subs.remove("reload");
            if (!sender.hasPermission("mauahopper.speed")) subs.remove("speed");
            if (!sender.hasPermission("mauahopper.amount")) subs.remove("amount");
            if (!sender.hasPermission("mauahopper.stats")) subs.remove("stats");
            // GREEN FIX: loc goi y theo quyen, khong lo subcommand khong duoc phep.
            if (!sender.hasPermission("mauahopper.toggle")) subs.remove("toggle");
            if (!sender.hasPermission("mauahopper.status")) subs.remove("status");
            String partial = args[0].toLowerCase(Locale.ROOT);
            subs.stream().filter(s -> s.startsWith(partial)).forEach(completions::add);
        } else if (args.length == 2 && args[0].equalsIgnoreCase("stats")) {
            if ("reset".startsWith(args[1].toLowerCase())) completions.add("reset");
        } else if (args.length == 2 && args[0].equalsIgnoreCase("toggle")) {
            Bukkit.getOnlinePlayers().stream()
                    .map(Player::getName)
                    .filter(n -> n.toLowerCase().startsWith(args[1].toLowerCase()))
                    .forEach(completions::add);
        } else if (args.length == 3 && args[0].equalsIgnoreCase("toggle")) {
            Arrays.asList("on", "off").stream()
                    .filter(v -> v.startsWith(args[2].toLowerCase()))
                    .forEach(completions::add);
        }
        return completions;
    }
}
