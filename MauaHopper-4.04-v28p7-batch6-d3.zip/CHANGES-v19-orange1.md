# MauaHopper 4.04-PATCHED-v19-orange1

Patch batch orange 1. Bao gom toan bo fix red1 v18 + cac fix cam chinh.

## Fix orange
- Paid save bypass debounce 2s bang savePaid().
- Vault refund phí nút Sell khi sell/deposit that bai.
- Rollback Vault fail markDirty().
- Cancel vanilla khi cầm upgrade item click vào Rương To đã tạo.
- AutoSell cap/xoay vong toi da 20 chests/lan.
- Search gioi han 100 ket qua.
- Minecart config tat thi khong xu ly cart cached.
- Immediate pickup ton trong world blacklist va blacklisted block.
- Crafter auto-retrigger throttle 100ms/crafter.
- Active chunk radius cap 96 block.
- ItemStacking idle scan quanh player, khong full-world.
- Inventory expand debounce 250ms/player.
- Item stacking radius clamp <=16.
- MobStacking gear cache trong tung mergeTick.
- Config default an toan hon: transfer_ticks=2, max_hoppers_per_tick=30, mspt_throttle_ms=35.

## Verify
- Brace/paren/bracket balance toan bo Java.
- Grep call-site cac ham/fix moi.

- Search cap 100 ket qua va config default an toan hon da ghi.

- Dispenser auto-burst init NMS va lay BlockState moi sau tung shot, khong dung snapshot stale.
