MauaHopper 4.04 - AUDIT FIX 2026-09-25
======================================

FIX 1 [DuplicationProtector.java] - verifyTransfer() viet lai hoan toan
  - Nhom item bang representative + ItemStack.isSimilar() tren 4 snapshot
    chung (accumulateDelta), thay vi Objects.hashCode(ItemMeta) khong on
    dinh + identityHashCode fallback (false-positive rollback lien tuc).
  - countByType() @Deprecated, reimplement theo representative.
  - Xoa ham signature() (khong con ai dung).
  - locKey(): null-check world, het NPE khi chunk unload.

FIX 2 [BigChestManager.java] - mat do 3 duong
  - compress(): chia block thanh stack <=64 truoc khi insert; phan khong
    vua roi ra dat. Truoc day blocks co the hang tram (>maxStackSize) bi
    validate() xoa sach khi dong GUI.
  - sellAll(): giu do da thu trong list, deposit() false -> hoan toan bo
    do ve rương + log severe. Truoc day pg[i]=null truoc, deposit() nuot
    exception = mat do vo hinh khi Vault loi.
  - deposit(): tra boolean, moi nhanh fail deu log ro rang.
  - Them removeMatching() (ho tro FIX 3).
  - open(): try/catch quanh openInventory, exception tu go viewer (het
    khoa rương "dang duoc su dung" toi restart).

FIX 3 [HopperTicker.java] - dupe vanilla -> Rương To
  - onInventoryMove: dem item tuong tu o nguon TRUOC/SAU removeItem; neu
    nguon khong tru duoc (virtual inventory AC...) -> removeMatching()
    hoan lai Rương To + canh bao. Them helper countSimilar().

FIX 4 [HopperTicker.java] - minecart pha lock
  - processMinecartTransfers: 2 nhanh (container tren + rương thuyen duoi)
    goi tryLockContainer trong if, khong con unlock vo dieu kien gop nham
    lock cua transfer dang giu.

CHUA FIX (nho, khong dupe)
  - Vanilla container-pull cua hopper minecart khong bi cancel -> chay
    song song plugin (chi nhanh hon chut, co rui ro khi bat verify_transfers)
  - compress()/insert() khi rương day: phan du roi ra dat (da an toan)

CHECK ROUND 2 (2026-09-25)
==========================
- countSimilar: doc ledger PDC TRUOC khi strip (truoc day doc sau remove,
  v luon null, chi dem surface).
- open(): bỏ "throw t" vi method khong khai bao throws (loi compile javac)
  -> chi rethrow RuntimeException/Error, checked exception log severe
  (viewer van duoc don sach, khong leak).
- Ket qua: 13/13 file cau truc ngoac OK, khong con "throw t;" sot lai.
  Chua build bang javac duoc (moi truong khong co JDK) - can mvn package.

FIX CHECK 4 (2026-09-25) - loi compile tu anh build cua user
==============================================================
Loi: "variable t is already defined in method open(...)" @BigChestManager:894
Nguyen nhan: trong open() da co bien "t" khai bao truoc, catch (Throwable t)
cua FIX CHECK 3 trung ten -> javac bao loi.
Sua: doi catch (Throwable t) -> catch (Throwable ex), noi dung giu nguyen.
Build lai bang mvn package sau khi thay file.

SHOP DEBUG (2026-09-25) - giai quyet "chests khong mua duoc"
============================================================
Them thong bao vao MOI nhanh return im lang cua luong mua rương:
- openShop: bao khi bigchest.enabled tat / shop.enabled tat / thieu
  section types: / tat ca loai shop-price -1.
- onShopClick: bao khi click vat pham khong phai rương (khong co PDC
  bigchest_upgrade) hoac loai khong ban truc tiep.
Cach dung: build, vo server go /chests, click thu - message do CHINH LA
nguyen nhan. Bao lai message do de fix dung cho.
Nghi pham thuong gap nhat: permission mauahopper.chests.shop (mac dinh
OP) - player thuong bi chan o cau "Ban khong co quyen mo shop".

TPS ROUND 2 (2026-09-25) - patch HopperTicker
=============================================
- A: bo query ChestBoat phia tren hopper khi block tren la Container.
- B: check rail bang static Set (het name().contains() alloc string).
- C: bo query ChestBoat phia duoi hopper khi block duoi khong phai AIR/WATER.
- D/E: tuong tu A/C cho minecart (tren/duoi).
- F: minecartPickupGround skip khi gio day + helper hasSpace().
- G: chunkKey tinh 1 lan cho 3 loi goi trong drainWorkQueue.
- H: vong lap minecart dung chung nowMs (da xac nhan khai bao line 399,
    an toan, khong loi compile).
Behavior giu nguyen: thuyen chi ton tai trong AIR/WATER hoac khi block
tren khong phai container. Regression test: chestboat tren/duoi hopper.

TPS ROUND 3 (2026-09-25)
========================
- markChunkHasItems: chunkKey tinh 1 lan cho 2 map (truoc 2 alloc/spawn).
- transferBatchBetweenInventories: gate snapshot(54+54 clone/transfer) bang
  verify_transfers - snapshot chi phuc vu verifyTransfer ma verifyTransfer
  no-op khi verify_transfers=false (MAC DINH) => chup roi bo di.
- MobStackingManager (round 2): cache player locations 1 lan/dot quet, skip
  world khong co nguoi truoc getLivingEntities().

TPS ROUND 4 (2026-09-26)
========================
- BigChestData: them cursor scanPage/scanIdx cho pullInto - hopper hut
  tu Rương To nhieu trang khong rescan 405 slot tu dau moi mon (scan vong
  tron, tu self-heal, chi doi THU TU lay khong doi ket qua so luong).
- pullInto/insertFrom: key(loc) tinh 1 lan cho chests.get + hasViewer.
- Harden: page length 0 khong lam scan index am.

TPS ROUND 5 (2026-09-26)
========================
- BigChestData.fullUntil: danh dau rương day 1 giay - hopper nhet vao
  rương day khong scan 405 slot x 2 pass moi tick. Tu clear khi pullInto
  lay duoc do (worst case doi 1s neu do duoc giai phong ma khong qua
  pullInto - autosell 5 phut, khong dang ke).

TPS ROUND 6 (2026-09-26) - phien ket thuc audit
================================================
- Kiem toan xong: refreshHologram la no-op (hologram tat), handler
  event-driven deu re, autosell 5 phut/save 60s khi dirty - khong phai
  van de.
- Hoist NamespacedKey "stack_amount" thanh STACK_KEY tinh (5 cho cap
  phat/key, goi rat thuong xuyen trong moi transfer).
AUDIT HOAN TAT: khong con diem nao dang sua voi rui ro thap. Buoc tiep
theo bat buoc la spark tren server that de dinh huong toi uu sau.

FIX SYNC (2026-09-26) - QUAN TRONG
====================================
Phat hien: patch TPS round 2 (boat gates A-E, rail Set, hasSpace, ckLoc)
va hoist STACK_KEY truoc day CHI nam trong bo nho, chua ghi dia -> zip
cu thieu het. Ngoai ra ban ghi dia dau tien bi loi "STACK_KEY = STACK_KEY"
(self-replace) = LOI COMPILE.
Da ghi day du lai vao dia, fix initializer, verify 11/11 patch co mat.
Zip duoc build lai TU DIA - nguoi dung phai build lai, khong dung zip cu.

DEAD CODE CLEANUP (2026-09-26)
==============================
Xoa 4 method private khong ai goi (verif: xuat hien dung 1 lan = dinh nghia,
khong phai EventHandler, khong phai method reference):
- BigChestManager.icon()
- DuplicationProtector.countItems()
- HopperTicker.isAdvancedChestsOwnedBlock() (isAdvancedChestsOwnedState
  van con 8 noi dung - giu lai)
- ItemStackingManager.isStacked()
GIU LAI public API khong ai goi noi bo (nguy co plugin ngoai dung):
MauaHopper.getMobStackingManager(), MauaHopper.openBigChestShop(),
SpeedManager.setEnabled().
File rac: khong co (.class/.bak/tmp). Private fields thua: khong co.
refreshHologram: no-op co chu dich (hologram feature tat) - giu.
SHOP DEBUG message: giu (can cho chan doan).
