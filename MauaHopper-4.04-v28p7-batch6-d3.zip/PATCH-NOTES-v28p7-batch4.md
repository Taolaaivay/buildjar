# PATCH-NOTES-v28p7-batch4 (2026-09-29) - Dot 4 (CUOI): vest sinh nhe

## A - spawnImmediateNextAt doi sang packed-long
HopperTicker.java :385, :392
- Map<String, Long> -> Map<Long, Long>, key = packChunkKey(loc). Truoc day
  MOI item spawn event build 1 string "world:x:z" (concat alloc) - farm mob
  hang nghin item/giay alloc lien tuc. HashMap<Long> lookup cung nhanh hon
  string hash. Call site (onItemSpawn :3552, onPlayerDrop :3622) khong doi.

## B - Crafter map giu Location key (danh gia lai, KHONG doi)
- Da can nhac doi crafterPulseCount/PulseAt/RetriggerNextAt sang packed-long
  nhung purge (:265-291) can World object de check block type, ma world chi
  luu duoi dang 15-bit hash KHONG dao nguoc duoc. Doi key se phai bo safety
  net check block type (piston keo crafter) - rui ro lon hon loi ich (chi 1
  Location alloc / craft, da bi throttle 100ms/crafer). GIU NGUYEN.

## C - Attract item giam 5 alloc con 1
ItemStackingManager.java :757-763
- nearest.getLocation().toVector().subtract(a.getLocation().toVector()):
  5 alloc cho moi item bi hut moi mergeTick. Toa do primitive entity, chi con
  1 Vector alloc (bat buoc cho setVelocity).

## D - Canh bao ten blacklist khong hop le
ConfigManager.java :278-282
- Material.matchMaterial tra null -> log warning co ten. Truoc day lang im,
  admin tuong blacklist dang hoat dong.

## Verify
- Brace balance 0 ca 3 file. spawnImmediateNextAt 6/6 dung key type moi,
  trySpawnImmediateGate 1+2 signature khong doi, toVector attract da sach.
