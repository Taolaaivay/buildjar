package com.mauahopper;

import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;

import java.util.EnumMap;
import java.util.List;
import java.util.Map;

/**
 * Reads and exposes all config.yml settings.
 * Caches values on load; call reload() after a config reload.
 */
public class ConfigManager {

    private final MauaHopper plugin;

    // hopper
    public boolean hopperEnabled;
    public int transferTicks;
    public int pullTicks;
    public int pushTicks;
    public int transferAmount;
    public int pullAmount;
    public int pushAmount;
    public int maxStackPerTransfer;
    public int maxItemsPerTick;
    public boolean smoothTransfers;
    public int smoothStackSize;
    public int minCascadeCooldownTicks;
    public int cascadeRounds;

    // batch_transfer by container type
    public boolean batchHopper;
    public boolean batchChest;
    public boolean batchTrappedChest;
    public boolean batchBarrel;
    public boolean batchDropper;
    public boolean batchDispenser;
    public boolean batchShulker;
    public boolean batchFurnace;
    public boolean batchBlastFurnace;
    public boolean batchSmoker;
    public boolean batchCrafter;

    // shulker
    public boolean shulkerAllowPulling;
    public boolean shulkerAllowPushing;

    // crafter
    public boolean crafterEnabled;
    public boolean crafterAutoRetrigger;
    public boolean furnaceRejectJunk;
    public boolean furnaceUseVanillaRouting; // v67.20: phan loai furnace theo vi tri dat nhu vanilla
    public int     crafterCraftsPerPulse;
    public int     minecartTransferAmount;
    public double  minecartSpeedMultiplier;
    public boolean dispenserFastEnabled;
    public int     dispenserFastInterval;
    public int     dispenserShotsPerPulse;
    // v66: auto burst (tu ban khong can redstone)
    public boolean dispenserAutoBurst;
    public int     dispenserAutoBurstTicks;
    public int     dispenserAutoBurstMaxPerTick;
    public boolean dispenserAutoRequirePlayer;
    public double  dispenserAutoPlayerRadius;
    public final java.util.Set<Material> dispenserFastItems = new java.util.HashSet<>();
    public int crafterItemsPerSlot;
    public int crafterFeedTicks;
    public int crafterPullAmount;
    public int crafterMaxFeedsPerTick;
    public int crafterTransferTicks;

    // PATCH 2026-09-27 (loi #17): da xoa field furnaceUseSpecialLogic -
    // HopperTicker hardcode logic dac biet tu v43, config key la key chet.

    // composter
    public boolean composterEnabled;
    public int composterMaxFeedsPerTick;
    public boolean composterAutoCollectBonemeal;
    public Map<Material, Float> composterChances = new EnumMap<>(Material.class);

    // cauldron (extension beyond vanilla hopper behavior — mirrors dispensers)
    public boolean cauldronEnabled;
    public int cauldronMaxFeedsPerTick;

    // pickup
    public boolean pickupEnabled;
    public boolean pickupInstant;
    // batch7: direct suction - hut truc tiep moi tick, khong phu thuoc event/hint
    public boolean directSuction;
    // batch7b: hut ca item tren mat dat xung quanh chan hopper (magnet)
    public boolean pickupSuckGround;
    // DEBUG: log tung gate pickup, chi bat khi can chuan doan (tu build nay)
    public boolean pickupDebugLog;
    // v67.27: true = ton trong pickupDelay 40 tick khi nem tay (choi kho);
    // false (mac dinh) = hut ngay nhu vanilla
    public boolean pickupRespectDelay;
    // v67.28: so tick giua cac lan quet pickup (1 = moi tick, hut ngay)
    public int pickupIntervalTicks;
    /** FIX TPS 2026-09-28: stagger quet pickup sweep - moi luot chi quet
     *  1/N so chunk (xoay vong). Mac dinh 2 = giam nua so AABB query/tick. */
    public int pickupScanStaggerTicks = 2;
    // v67.35: true = chi hut item DUNG tren mat hopper (dung vanilla);
    // false = hut theo ban kinh pickup_radius (cu, hut ca do ben canh)
    public boolean pickupSurfaceOnly;
    public double pickupRadiusHorizontal;
    public double pickupRadiusVertical;
    public boolean pickupRequireLineOfSight;
    public boolean pickupLockItemEntities;

    // minecart hopper
    public boolean minecartHopperEnabled;
    public double minecartPickupRadius;

    // dropper chain
    public boolean dropperChainEnabled;
    public int dropperChainTransferTicks;

    public int maxPerChunk;
    public boolean countSpecialBlocksInChunkLimit;
    public List<String> blacklistedBlocksForPickup;
    // PATCH 2026-09-29 (batch 3, loi #9): ban dang Material tu ten config
    // 1 lan luc load. Duong nong pickup check enum O(1) thay vi String.name()
    // alloc moi item moi pass; va thong nhat nguyen tac so khop EXACT giua
    // sweep path (truoc day contains String) va immediate path (truoc day
    // equalsIgnoreCase O(n)) - truoc day config viet thuong chi chan 1 duong.
    public final java.util.Set<org.bukkit.Material> blacklistedMaterialsForPickup =
            java.util.EnumSet.noneOf(org.bukkit.Material.class);

    // performance
    public int maxHoppersPerTick;
    public int maxMinecartsPerTick;
    public int slowChunkCooldownTicks; // v4.04: thay magic number 7 o slow mode
    public int idleCooldownTicks = 4; // v4.04n: nhip nghi cua hopper trong (cho do)
    public boolean workQueueEnabled = true; // v4.04s: kien truc work queue
    // PATCH 2026-09-27 (loi #1): khai bao lai field bi xoa nham o v4.16.
    // HopperTicker.scheduleHopperProcess doc qua cfgW.fullRefreshTicks.
    // Gia tri duoc set dung trong load() (clamp 20, default 40 = 2 giay).
    public int fullRefreshTicks = 40;
    public int maxDroppersPerTick = 50;     // v4.07: cap dropper chain/tick (giong hopper)
    public int idleFullHopperTicks;
    public int msptThrottleMs;
    public int minecartScanInterval;
    public double requirePlayerRadius; // v67: gate theo nguoi choi (block)
    public boolean respectPlayerToggle;  // v67.5: ton trong /mh toggle

    // toggle
    public String toggleMode;     // "global" or "per_player"
    public boolean toggleDefaultEnabled;

    // protection
    public String protectionMode;
    public boolean antiDuplication;
    public boolean antiItemLoss;
    public boolean rollbackOnDupe;
    public boolean logDupeAttempts;
    public boolean inventoryLocks;
    public boolean blockConcurrentContainerAccess;
    public boolean verifyTransfers;
    public boolean perHopperTransferLock;
    public boolean containerCooldown;

    // worlds
    public List<String> disabledWorlds;
    public List<String> enabledWorlds;

    public ConfigManager(MauaHopper plugin) {
        this.plugin = plugin;
        load();
    }

    public void load() {
        plugin.saveDefaultConfig();
        plugin.reloadConfig();
        FileConfiguration cfg = plugin.getConfig();

        hopperEnabled           = cfg.getBoolean("hopper.enabled", true);
        transferTicks           = cfg.getInt("hopper.transfer_ticks", 1); // v67.12: dung theo config mau
        pullTicks               = cfg.getInt("hopper.pull_ticks", 2);
        pushTicks               = cfg.getInt("hopper.push_ticks", 2);
        transferAmount          = cfg.getInt("hopper.transfer_amount", 8);
        pullAmount              = cfg.getInt("hopper.pull_amount", -1);
        pushAmount              = cfg.getInt("hopper.push_amount", -1);
        maxStackPerTransfer     = cfg.getInt("hopper.max_stack_per_transfer", 64);
        maxItemsPerTick         = cfg.getInt("hopper.max_items_per_tick", 8);
        smoothTransfers         = cfg.getBoolean("hopper.smooth_transfers", true);
        smoothStackSize         = cfg.getInt("hopper.smooth_stack_size", 8);
        minCascadeCooldownTicks = cfg.getInt("hopper.min_cascade_cooldown_ticks", 2);
        cascadeRounds           = Math.max(1, cfg.getInt("hopper.cascade_rounds", 2)); // v67.32: 0/am = hopper chet het - clamp

        for (String type : new String[]{"hopper","chest","trapped_chest","barrel",
                "dropper","dispenser","shulker","furnace","blast_furnace","smoker","crafter"}) {
            boolean val = cfg.getBoolean("hopper.batch_transfer." + type, true);
            switch (type) {
                case "hopper"        -> batchHopper       = val;
                case "chest"         -> batchChest        = val;
                case "trapped_chest" -> batchTrappedChest = val;
                case "barrel"        -> batchBarrel       = val;
                case "dropper"       -> batchDropper      = val;
                case "dispenser"     -> batchDispenser    = val;
                case "shulker"       -> batchShulker      = val;
                // v4.04 FIX: doc config that (truoc day hardcode false khien
                // batch_transfer.furnace/smoker/... trong config.yml VO HIEU).
                case "furnace"       -> batchFurnace      = cfg.getBoolean("hopper.batch_transfer.furnace", false);
                case "blast_furnace" -> batchBlastFurnace = cfg.getBoolean("hopper.batch_transfer.blast_furnace", false);
                case "smoker"        -> batchSmoker       = cfg.getBoolean("hopper.batch_transfer.smoker", false);
                case "crafter"       -> batchCrafter      = cfg.getBoolean("hopper.batch_transfer.crafter", false);
            }
        }

        shulkerAllowPulling = cfg.getBoolean("hopper.shulker.allow_pulling", true);
        shulkerAllowPushing = cfg.getBoolean("hopper.shulker.allow_pushing", true);

        crafterEnabled       = cfg.getBoolean("hopper.crafter.enabled", true);
        crafterAutoRetrigger = cfg.getBoolean("hopper.crafter.auto_retrigger", true);
        furnaceRejectJunk     = cfg.getBoolean("hopper.furnace.reject_junk", true);
        // v67.20: true = phan loai theo VI TRI dat nhu vanilla (tren dau -> input ke ca than;
        // ben hong -> fuel). false (mac dinh) = phan loai theo loai item (than luon vao fuel).
        furnaceUseVanillaRouting = cfg.getBoolean("hopper.furnace.use_vanilla_routing", false);
        // p9 FIX: Math.max(1,...) bien 0 thanh 1 - lam comment "0 = khong
        // gioi han" (p3h/batch6) khong bao gio dat duoc. Cho phep 0.
        crafterCraftsPerPulse  = Math.max(0, cfg.getInt("hopper.crafter.crafts_per_pulse", 0));
        minecartTransferAmount = cfg.getInt("hopper.minecart.transfer_amount", 8); // v66.4: default 8 item/luot (-1 = dung pull_amount)
        minecartSpeedMultiplier = Math.max(0.1, cfg.getDouble("hopper.minecart.speed_multiplier", 4.0));
        dispenserFastEnabled  = cfg.getBoolean("hopper.dispenser.fast_enabled", true);
        dispenserFastInterval = Math.max(1, cfg.getInt("hopper.dispenser.fast_interval_ticks", 1));
        dispenserShotsPerPulse  = Math.max(1, cfg.getInt("hopper.dispenser.shots_per_pulse", 8));
        dispenserAutoBurst          = cfg.getBoolean("hopper.dispenser.auto_burst", false); // v66.2: TAT mac dinh - dispenser can redstone nhu vanilla, burst nhanh theo shots_per_pulse
        dispenserAutoBurstTicks     = Math.max(0, cfg.getInt("hopper.dispenser.auto_burst_ticks", 2));
        dispenserAutoBurstMaxPerTick= Math.max(0, cfg.getInt("hopper.dispenser.max_per_tick", 20)); // p9: 0 = unlimited
        dispenserAutoRequirePlayer  = cfg.getBoolean("hopper.dispenser.require_player", true);
        dispenserAutoPlayerRadius   = Math.max(8.0, cfg.getDouble("hopper.dispenser.player_radius", 64.0));
        dispenserFastItems.clear();
        for (String name : cfg.getStringList("hopper.dispenser.fast_items")) {
            try {
                Material m = Material.matchMaterial(name.trim().toUpperCase());
                if (m != null) dispenserFastItems.add(m);
            } catch (Exception ex) {
                MauaHopper.fineSafe("Safe catch in ConfigManager", ex);
            }
        }
        // Mặc định chỉ BONE_MEAL nếu danh sách rỗng/không hợp lệ
        if (dispenserFastItems.isEmpty()) dispenserFastItems.add(Material.BONE_MEAL);
        crafterItemsPerSlot  = cfg.getInt("hopper.crafter.items_per_slot", 16); // v67.12: mac dinh dung theo config mau
        crafterFeedTicks     = cfg.getInt("hopper.crafter.feed_ticks", 0); // v67.12
        crafterPullAmount    = cfg.getInt("hopper.crafter.pull_amount", 8); // v67.12
        crafterMaxFeedsPerTick = Math.max(1, cfg.getInt("hopper.crafter.max_feeds_per_tick", 9)); // v67.12+v67.32
        crafterTransferTicks = cfg.getInt("hopper.crafter.transfer_ticks", 0);

        // PATCH 2026-09-27 (loi #17): khong con doc hopper.furnace.use_special_logic

        composterEnabled             = cfg.getBoolean("hopper.composter.enabled", true);
        composterMaxFeedsPerTick     = Math.max(1, cfg.getInt("hopper.composter.max_feeds_per_tick", 1)); // v67.32
        composterAutoCollectBonemeal = cfg.getBoolean("hopper.composter.auto_collect_bonemeal", true);
        composterChances             = loadComposterChances(cfg);

        cauldronEnabled          = cfg.getBoolean("hopper.cauldron.enabled", true);
        cauldronMaxFeedsPerTick  = Math.max(1, cfg.getInt("hopper.cauldron.max_feeds_per_tick", 1)); // v67.32

        pickupEnabled          = cfg.getBoolean("hopper.pickup.enabled", true);
        pickupInstant          = cfg.getBoolean("hopper.pickup.instant", true);
        directSuction            = cfg.getBoolean("hopper.pickup.direct_suction", true);
        pickupSuckGround         = cfg.getBoolean("hopper.pickup.suck_ground", false);
        pickupDebugLog         = cfg.getBoolean("hopper.pickup.debug_log", false);
        pickupRespectDelay     = cfg.getBoolean("hopper.pickup.respect_pickup_delay", false); // v67.27
        pickupIntervalTicks    = Math.max(1, cfg.getInt("hopper.pickup.interval_ticks", 1)); // v67.28
        pickupScanStaggerTicks = Math.max(1, cfg.getInt("hopper.pickup.scan_stagger_ticks", 2)); // FIX TPS 2026-09-28
        pickupSurfaceOnly      = cfg.getBoolean("hopper.pickup.surface-only", true); // v67.35
        pickupRadiusHorizontal = cfg.getDouble("hopper.pickup.radius_horizontal", 0.75);
        pickupRadiusVertical   = cfg.getDouble("hopper.pickup.radius_vertical", 0.5);
        pickupRequireLineOfSight = cfg.getBoolean("hopper.pickup.require_line_of_sight", false);
        pickupLockItemEntities = cfg.getBoolean("hopper.pickup.lock_item_entities", true);

        minecartHopperEnabled  = cfg.getBoolean("hopper.minecart_hopper.enabled", true);
        minecartPickupRadius   = Math.max(0.1, cfg.getDouble("hopper.minecart_hopper.pickup_radius", 1.5)); // v67.32: am = BoundingBox crash

        dropperChainEnabled       = cfg.getBoolean("hopper.dropper_chain.enabled", true);
        dropperChainTransferTicks = cfg.getInt("hopper.dropper_chain.transfer_ticks", 4);

        maxPerChunk               = cfg.getInt("hopper.max_per_chunk", 120);
        countSpecialBlocksInChunkLimit = cfg.getBoolean("hopper.count_special_blocks_in_chunk_limit", true);
        blacklistedBlocksForPickup = cfg.getStringList("hopper.blacklisted_blocks_for_pickup");
        blacklistedMaterialsForPickup.clear();
        for (String name : blacklistedBlocksForPickup) {
            org.bukkit.Material m = org.bukkit.Material.matchMaterial(name);
            // PATCH 2026-09-29 (batch 4, loi #D): canh bao ten khong hop le
            // (truoc day lang im -> admin tuong blacklist dang hoat dong).
            if (m != null) blacklistedMaterialsForPickup.add(m);
            else plugin.getLogger().warning("[Config] hopper.blacklisted_blocks_for_pickup - ten khong hop le: " + name);
        }

        maxHoppersPerTick   = cfg.getInt("performance.max_hoppers_per_tick", 150);
        // v4.04 FIX: giu dung nghia "am = khong gioi han" (Ticker da xu ly
        // <= 0 thanh Integer.MAX_VALUE). Math.max(1,...) cu vo hieu hoa luon.
        maxMinecartsPerTick = cfg.getInt("performance.max_minecarts_per_tick", 50);
        if (maxMinecartsPerTick == 0) maxMinecartsPerTick = 50;
        slowChunkCooldownTicks = Math.max(2, cfg.getInt("performance.slow_chunk_cooldown_ticks", 7)); // v4.04
        // v28p6 FIX (loi #5): cooldown < 2 tick bi bo decimate lam trong
        // thanh 2 tick (granularity cua decrementMap) - clamp min 2 cho
        // dung voi hanh vi thuc te thay vi im lang lech 1 tick.
        idleCooldownTicks = Math.max(2, cfg.getInt("performance.idle_cooldown_ticks", 4)); // v4.04n
        // FIX v4.04.2: doc ca 2 vi tri nhu respect_player_toggle - config.yml dat
        // cac key nay duoi "performance." chu khong phai "hopper." nen truoc
        // day nguoi dung sua performance.work_queue/full_refresh_ticks khong
        // co hieu luc.
        workQueueEnabled = cfg.getBoolean("performance.work_queue",
                cfg.getBoolean("hopper.work_queue", true)); // v4.04s + fix v4.04.2
        fullRefreshTicks = Math.max(20, cfg.getInt("performance.full_refresh_ticks",
                cfg.getInt("hopper.full_refresh_ticks", 40))); // v4.16: dong bo clamp 20, default 40 = 2 giay
        maxDroppersPerTick = Math.max(1, cfg.getInt("hopper.max_droppers_per_tick", 50)); // v4.07ioi han
        idleFullHopperTicks = cfg.getInt("performance.idle_full_hopper_ticks", 40);
        // FIX TPS: config de "45.0" (double) - getInt tra 0 = throttle TAT im lang.
        msptThrottleMs      = (int) cfg.getDouble("performance.mspt_throttle_ms", 0);
        minecartScanInterval = cfg.getInt("performance.minecart_scan_interval", 100);
        // v67: gate toan cuc - farm tu ngu khi khong co nguoi choi gan (0 = tat)
        requirePlayerRadius = Math.max(0.0, cfg.getDouble("performance.require_player_radius", 128.0));
        respectPlayerToggle = cfg.getBoolean("performance.respect_player_toggle",
                cfg.getBoolean("hopper.respect_player_toggle", true)); // v67.17: doc ca 2 vi tri (config cu tung huong dan dat o hopper.) // v67.5: ton trong /mh toggle cua tung nguoi choi

        toggleMode           = cfg.getString("toggle.mode", "global");
        toggleDefaultEnabled = cfg.getBoolean("toggle.default_enabled", true);

        // Apply protection presets before reading individual keys
        protectionMode = cfg.getString("protection.mode", "safe");
        applyProtectionPreset(protectionMode, cfg);

        disabledWorlds = cfg.getStringList("worlds.disabled_worlds");
        enabledWorlds  = cfg.getStringList("worlds.enabled_worlds");

        // PATCH v17: cache messages.* - getMessage() khong con doc config
        // (FileConfiguration) moi lan goi.
        messageCache.clear();
        ConfigurationSection msgs = cfg.getConfigurationSection("messages");
        if (msgs != null) {
            for (String mk : msgs.getKeys(true)) {
                if (msgs.isString(mk)) messageCache.put(mk, msgs.getString(mk));
            }
        }

        // v4.06: config sai kieu (am/0 qua lon) khong duoc phep lam vo transfer
        // hoac tao stack khong hop le. Sanitize o 1 cho duy nhat sau khi load.
        sanitize();
    }

    private final Map<String, String> messageCache = new java.util.HashMap<>();

    /** Clamp cac gia tri numeric quan trong. GIU nguyen cac sentinel -1 co nghia
     *  "dung transfer_amount" (pull_amount/push_amount/minecart.transfer_amount). */
    private void sanitize() {
        transferTicks  = Math.max(0, transferTicks);
        pullTicks      = Math.max(0, pullTicks);
        pushTicks      = Math.max(0, pushTicks);
        transferAmount = Math.max(1, transferAmount);
        if (pullAmount >= 0) pullAmount = Math.max(1, pullAmount);
        if (pushAmount >= 0) pushAmount = Math.max(1, pushAmount);
        maxStackPerTransfer = Math.max(1, Math.min(64, maxStackPerTransfer));
        maxItemsPerTick = Math.max(1, maxItemsPerTick);
        smoothStackSize = Math.max(1, Math.min(64, smoothStackSize));
        // v28p6 FIX (loi #5): cooldown < 2 tick vo nghia vi bo decimate
        // (decrementAllCooldowns chay 1 lan/2 tick, moi lan tru 2).
        if (minCascadeCooldownTicks == 1) minCascadeCooldownTicks = 2;
        minCascadeCooldownTicks = Math.max(0, minCascadeCooldownTicks);
        cascadeRounds = Math.max(1, cascadeRounds);

        crafterItemsPerSlot = Math.max(1, Math.min(64, crafterItemsPerSlot));
        crafterFeedTicks = Math.max(0, crafterFeedTicks);
        crafterPullAmount = Math.max(1, crafterPullAmount);
        crafterMaxFeedsPerTick = Math.max(1, crafterMaxFeedsPerTick);
        crafterTransferTicks = Math.max(0, crafterTransferTicks);
        if (minecartTransferAmount >= 0) minecartTransferAmount = Math.max(1, minecartTransferAmount);
        // PATCH v28p7-batch6-d1 (loi #3): sanitize() chay sau load() - ep
        // max(1) pha semantic crafts_per_pulse=0 (0 = KHONG GIOI HAN, load()
        // :226 cho phep 0). Luu y cac cho dung phai check > 0 (da dung dung
        // o tryRetriggerCrafter).
        crafterCraftsPerPulse = Math.max(0, crafterCraftsPerPulse);

        composterMaxFeedsPerTick = Math.max(1, composterMaxFeedsPerTick);
        cauldronMaxFeedsPerTick = Math.max(1, cauldronMaxFeedsPerTick);
        pickupIntervalTicks = Math.max(1, pickupIntervalTicks);
        pickupRadiusHorizontal = Math.max(0.0, pickupRadiusHorizontal);
        pickupRadiusVertical = Math.max(0.0, pickupRadiusVertical);

        // v28p6 FIX (loi #5): clamp min 2 - cooldown 1 tick bi granularity
        // bo decimate lam trong thanh 2 tick, config 1 khong co tac dung.
        dropperChainTransferTicks = Math.max(2, dropperChainTransferTicks);
        maxPerChunk = Math.max(0, maxPerChunk);
        idleFullHopperTicks = Math.max(1, idleFullHopperTicks);
        msptThrottleMs = Math.max(0, msptThrottleMs);
        // FIX v4.04.1: giu nguyen nghia "am = khong gioi han" (HopperTicker
        // xu ly <= 0 thanh Integer.MAX_VALUE). Chi clamp gia tri duong.
        if (maxMinecartsPerTick > 0) maxMinecartsPerTick = Math.max(1, maxMinecartsPerTick);
        requirePlayerRadius = Math.max(0.0, requirePlayerRadius);
        minecartScanInterval = Math.max(1, minecartScanInterval);
        minecartSpeedMultiplier = Math.max(0.1, minecartSpeedMultiplier);
        minecartPickupRadius = Math.max(0.1, minecartPickupRadius);
        dispenserAutoBurstTicks = Math.max(0, dispenserAutoBurstTicks);
        dispenserAutoBurstMaxPerTick = Math.max(1, dispenserAutoBurstMaxPerTick);
        dispenserAutoPlayerRadius = Math.max(8.0, dispenserAutoPlayerRadius);
    }

    /**
     * Parses hopper.composter.chances ONCE at (re)load time, so the hot path
     * in HopperTicker never touches the config/YAML — just a plain HashMap lookup.
     */
    private Map<Material, Float> loadComposterChances(FileConfiguration cfg) {
        Map<Material, Float> map = new EnumMap<>(Material.class);
        ConfigurationSection section = cfg.getConfigurationSection("hopper.composter.chances");
        // FIX v67.25: config THIEU section chances -> dung bang ti le VANILLA mac
        // dinh, composter khong bao gio "chet" vi config. Truoc day map rong =
        // composter tu choi moi item.
        if (section == null) {
            plugin.getLogger().info("[MauaHopper] composter.chances thieu trong config - dung ti le vanilla mac dinh.");
            addVanillaComposterChances(map);
            return map;
        }

        for (String key : section.getKeys(false)) {
            try {
                Material mat = Material.valueOf(key.toUpperCase());
                float raw = (float) section.getDouble(key);
                // FIX v67.10: config viet theo PHAN TRAM (30 = 30%) nhung code
                // dung nhu xac suat 0..1 -> Math.min(1f, 30f) = 1.0, composter
                // day chac chan sau dung 7 item (vanilla ~21 item). Chuyen
                // gia tri >1 ve thang phan tram, chap nhan ca 2 kieu viet.
                float chance = raw > 1f ? raw / 100f : raw;
                map.put(mat, Math.max(0f, Math.min(1f, chance)));
            } catch (IllegalArgumentException ex) {
                plugin.getLogger().warning("[MauaHopper] Không nhận ra vật liệu composter trong config, bỏ qua: " + key);
            }
        }
        return map;
    }

    /** Bang ti le day composter theo VANILLA 1.21 (dung khi config thieu). */
    private void addVanillaComposterChances(Map<Material, Float> map) {
        // BANG DAY DU theo wiki minecraft.fandom.com/wiki/Composter (v67.58)
        // 30%
        put(map, 0.30f, "BEETROOT_SEEDS", "WHEAT_SEEDS", "PUMPKIN_SEEDS", "MELON_SEEDS",
                "OAK_SAPLING", "BIRCH_SAPLING", "SPRUCE_SAPLING", "JUNGLE_SAPLING",
                "ACACIA_SAPLING", "DARK_OAK_SAPLING", "MANGROVE_PROPAGULE", "CHERRY_SAPLING",
                // PATCH 2026-09-27 (loi #5): BAMBOO_SAPLING khong ton tai trong Material enum
                "OAK_LEAVES", "BIRCH_LEAVES", "SPRUCE_LEAVES",
                "JUNGLE_LEAVES", "ACACIA_LEAVES", "DARK_OAK_LEAVES", "MANGROVE_LEAVES",
                "CHERRY_LEAVES", "AZALEA_LEAVES", "FLOWERING_AZALEA_LEAVES",
                // PATCH 2026-09-27 (loi #4+#5): xoa GRASS (ten cu cua
                // SHORT_GRASS, khong con trong enum 1.21), BAMBOO_SAPLING va
                // AZALEA_BUSH (khong ton tai - bi catch nuot thanh dead code)
                "SHORT_GRASS", "FERN", "SEAGRASS",
                "MOSS_CARPET", "PINK_PETALS", "HANGING_ROOTS", "MANGROVE_ROOTS",
                "SMALL_DRIPLEAF", "DRIED_KELP", "KELP", "GLOW_BERRIES", "SWEET_BERRIES",
                "PITCHER_POD", "TORCHFLOWER_SEEDS");
        // 50%
        put(map, 0.50f, "CACTUS", "DRIED_KELP_BLOCK", "MELON_SLICE", "SUGAR_CANE",
                "TALL_GRASS", "LARGE_FERN", "VINE", "TWISTING_VINES", "WEEPING_VINES",
                "NETHER_SPROUTS", "GLOW_LICHEN");
        // 65%
        put(map, 0.65f, "WHEAT", "CARROT", "POTATO", "BEETROOT", "APPLE", "MELON",
                "PUMPKIN", "CARVED_PUMPKIN", "COCOA_BEANS",
                "BROWN_MUSHROOM", "RED_MUSHROOM",
                // PATCH 2026-09-27 (loi #4): MUSHROOM_STEM chuyen ve nhom 85%
                // cho dung vanilla (truoc day trung 2 nhom)
                "CRIMSON_FUNGUS", "WARPED_FUNGUS", "CRIMSON_ROOTS", "WARPED_ROOTS",
                "NETHER_WART", "LILY_PAD", "SEA_PICKLE", "SHROOMLIGHT", "SPORE_BLOSSOM",
                "AZALEA", "BIG_DRIPLEAF",
                // PATCH 2026-09-27 (loi #4): MOSS_BLOCK, FLOWERING_AZALEA,
                // TORCHFLOWER, MUSHROOM_STEM theo VANILLA deu la 85% - truoc
                // day nam nhom 65% (hoac trung 2 nhom, map.put ghi de theo
                // thu tu lam sai ti le am tham).
                "DANDELION", "POPPY", "BLUE_ORCHID", "ALLIUM", "AZURE_BLUET",
                "RED_TULIP", "ORANGE_TULIP", "WHITE_TULIP", "PINK_TULIP", "OXEYE_DAISY",
                "CORNFLOWER", "LILY_OF_THE_VALLEY"); // FIX v4.04.1: PINK_PETALS o nhom 30%
        // 85%
        put(map, 0.85f, "BREAD", "BAKED_POTATO", "COOKIE",
                "HAY_BLOCK", "NETHER_WART_BLOCK", "WARPED_WART_BLOCK",
                // PATCH 2026-09-27 (loi #4): MUSHROOM_STEM vanilla = 85%
                // (comment v4.17 cu ghi nham 65%), them MOSS_BLOCK (vanilla 85%)
                "RED_MUSHROOM_BLOCK", "BROWN_MUSHROOM_BLOCK", "MUSHROOM_STEM", "MOSS_BLOCK",
                "FLOWERING_AZALEA", "PITCHER_PLANT", "TORCHFLOWER");
        // 100%
        put(map, 1.00f, "CAKE", "PUMPKIN_PIE");
    }

    private void put(Map<Material, Float> map, float chance, String... names) {
        for (String n : names) {
            try {
                map.put(Material.valueOf(n), chance);
            } catch (IllegalArgumentException ignored) {
            }
        }
    }

    /** v28p6 FIX (loi #34): preset chi la DEFAULT - key nao nguoi dung tu
     *  dat trong config (protection.*) phai duoc ton trong o MOI mode, khong
     *  chi mode default. Cu: mode safe/balanced/performance hardcode gan het
     *  cac key, cau hinh rieng bi nuot im lang (vi du tat
     *  per_hopper_transfer_lock o mode safe khong co tac dung). */
    private static boolean boolOr(FileConfiguration cfg, String key, boolean presetDefault) {
        return cfg.isSet(key) ? cfg.getBoolean(key) : presetDefault;
    }

    private void applyProtectionPreset(String mode, FileConfiguration cfg) {
        switch (mode.toLowerCase()) {
            case "safe" -> {
                antiDuplication                = boolOr(cfg, "protection.anti_duplication", true);
                antiItemLoss                   = boolOr(cfg, "protection.anti_item_loss", true);
                rollbackOnDupe                 = boolOr(cfg, "protection.rollback_on_dupe", true);
                inventoryLocks                 = boolOr(cfg, "protection.inventory_locks", true);
                blockConcurrentContainerAccess = boolOr(cfg, "protection.block_concurrent_container_access", true);
                perHopperTransferLock          = boolOr(cfg, "protection.per_hopper_transfer_lock", true);
                containerCooldown              = boolOr(cfg, "protection.container_cooldown", false);
                verifyTransfers                = boolOr(cfg, "protection.verify_transfers", false);
                logDupeAttempts                = boolOr(cfg, "protection.log_dupe_attempts", false);
            }
            case "balanced" -> {
                antiDuplication                = boolOr(cfg, "protection.anti_duplication", true);
                antiItemLoss                   = boolOr(cfg, "protection.anti_item_loss", true);
                rollbackOnDupe                 = boolOr(cfg, "protection.rollback_on_dupe", true);
                inventoryLocks                 = boolOr(cfg, "protection.inventory_locks", true);
                blockConcurrentContainerAccess = boolOr(cfg, "protection.block_concurrent_container_access", false);
                perHopperTransferLock          = boolOr(cfg, "protection.per_hopper_transfer_lock", true);
                containerCooldown              = boolOr(cfg, "protection.container_cooldown", false);
                verifyTransfers                = boolOr(cfg, "protection.verify_transfers", false);
                logDupeAttempts                = boolOr(cfg, "protection.log_dupe_attempts", false);
            }
            case "performance" -> {
                antiDuplication                = boolOr(cfg, "protection.anti_duplication", false);
                antiItemLoss                   = boolOr(cfg, "protection.anti_item_loss", false);
                rollbackOnDupe                 = boolOr(cfg, "protection.rollback_on_dupe", false);
                inventoryLocks                 = boolOr(cfg, "protection.inventory_locks", true);
                blockConcurrentContainerAccess = boolOr(cfg, "protection.block_concurrent_container_access", false);
                perHopperTransferLock          = boolOr(cfg, "protection.per_hopper_transfer_lock", false);
                containerCooldown              = boolOr(cfg, "protection.container_cooldown", false);
                verifyTransfers                = boolOr(cfg, "protection.verify_transfers", false);
                logDupeAttempts                = boolOr(cfg, "protection.log_dupe_attempts", false);
            }
            default -> {
                // Read each key individually
                antiDuplication                = cfg.getBoolean("protection.anti_duplication", true);
                antiItemLoss                   = cfg.getBoolean("protection.anti_item_loss", true);
                rollbackOnDupe                 = cfg.getBoolean("protection.rollback_on_dupe", true);
                logDupeAttempts                = cfg.getBoolean("protection.log_dupe_attempts", false);
                inventoryLocks                 = cfg.getBoolean("protection.inventory_locks", true);
                blockConcurrentContainerAccess = cfg.getBoolean("protection.block_concurrent_container_access", true);
                verifyTransfers                = cfg.getBoolean("protection.verify_transfers", false);
                perHopperTransferLock          = cfg.getBoolean("protection.per_hopper_transfer_lock", true);
                containerCooldown              = cfg.getBoolean("protection.container_cooldown", false);
            }
        }
    }

    /** Returns a formatted message from messages.* with placeholder substitution. */
    public String getMessage(String key, Object... replacements) {
        // PATCH v17: doc tu cache (nap o load/reload); fallback config khi thieu.
        String raw = messageCache.get(key);
        if (raw == null) {
            raw = plugin.getConfig().getString("messages." + key, "&c[MauaHopper] Missing message: " + key);
        }
        String out = ChatColor.translateAlternateColorCodes('&', raw);
        // Simple positional replacement: {count}, {ticks}, {amount}, etc.
        // Replacements come in pairs: "placeholder", value
        for (int i = 0; i + 1 < replacements.length; i += 2) {
            out = out.replace("{" + replacements[i] + "}", String.valueOf(replacements[i + 1]));
        }
        return out;
    }



    public int getIdleFullHopperTicks() {
        return idleFullHopperTicks;
    }

    public boolean isGlobalToggleMode() {
        return "global".equalsIgnoreCase(toggleMode);
    }

    public int getEffectivePullAmount() {
        return pullAmount < 0 ? transferAmount : pullAmount;
    }

    public int getEffectivePushAmount() {
        return pushAmount < 0 ? transferAmount : pushAmount;
    }
}
